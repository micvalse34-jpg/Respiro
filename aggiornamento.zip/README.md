# FitPRO

App Android personale (Capacitor + React + Dexie). Versione 0.4.4: fase F2. Valutazione iniziale in 3 settimane e profilo «Equilibrio» dei 19 domini funzionali (D105–D107); libreria di 53 esercizi classificati, 36 schede complete (D092–D095), ricerca, segnalazioni ed esclusioni (D103); seduta libera con più esercizi della libreria (D098), timer di recupero a tutto schermo con recupero reale (D101, D111) e calibrazione della prima seduta con elastico (D102); progressione **proposta** solo per il Band Row (D078–D083). Schema 5, backup formato 8. **Non** contiene ancora il motore di allenamento completo, la valutazione iniziale (0.4.1) né il Safety Engine (F3). Il Persistence POC è documentato in `docs/POC_TEST_REPORT.md`.

**Per iniziare leggere `docs/GUIDA_SEMPLICE.md`.**

## Comandi

| Comando | Effetto |
| --- | --- |
| `npm ci` | Installa le dipendenze (versioni bloccate) |
| `npm test` | Test automatici (Vitest + fake-indexeddb, Node) |
| `npm run typecheck` | Controllo tipi TypeScript |
| `npm run build` | Build PWA in `dist/` |
| `npm run preview` | Anteprima locale della build |
| `npm run build:app` | Build per l'app Android e copia nel progetto `android/` (Capacitor) |

## Struttura

```
src/domain/      tipi e regole pure (attrezzatura, profilo, libreria, comparabilità, progressione), UUIDv7
src/data/        schema Dexie v1→v4, repository (sedute, seduta libera, libreria, attrezzatura, profilo, storico), backup/ripristino, diagnostica
src/data/libraryCatalog.ts, libraryContent.ts: catalogo dei 52 esercizi (classificazione) e contenuti delle schede con registro delle fonti
src/app/         interfaccia: Home, Allenamento, Libreria, Storico, Profilo (dati, attrezzatura, backup, strumenti)
tests/           test automatici POC, F1, slice, F2; verify-files.mjs (controllo dei file caricati; --clean cancella i file fuori posto)
docs/            guida, protocolli Pixel 7a (POC e F1), test report
android/         progetto Android generato da Capacitor; android/keystore = chiave di firma (NON cancellare)
.github/workflows/main.yml  costruzione automatica dell'APK su GitHub; applica aggiornamento.zip se presente (D100)
public/_headers  header HTTP (solo versione browser)
```

## Scelte tecniche nel POC

- **Dexie/IndexedDB** come implementazione unica (nessun adattatore SQLite: nessun vantaggio emerso, v. report §6).
- **Durabilità `strict`** su tutte le transazioni del DB principale (`chromeTransactionDurability`).
- **«Salvato» solo dopo il commit**: `runSave` emette `saved` esclusivamente alla risoluzione della transazione.
- **ID generati dal client** (UUIDv7) prima del primo tentativo: un nuovo tentativo non crea duplicati.
- **Nessuna chiusura automatica** delle sedute IN_PROGRESS: alla riapertura l'app chiede «Riprendi / Chiudi come parziale» (D6).
- **Backup** JSON con checksum SHA-256 su serializzazione canonica, validazione completa prima di scrivere, import atomico.
- **Aggiornamenti app** in modalità `prompt`: proposti solo senza sedute aperte.
