package app.fitpro.personal;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
