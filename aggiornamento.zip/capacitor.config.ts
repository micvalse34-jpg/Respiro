import type { CapacitorConfig } from '@capacitor/cli';

// ATTENZIONE: appId non va MAI cambiato. Per Android un appId diverso è un'altra app:
// i dati della precedente non verrebbero ritrovati.
const config: CapacitorConfig = {
  appId: 'app.fitpro.personal',
  appName: 'FitPRO',
  webDir: 'dist',
  android: { allowMixedContent: false },
};

export default config;
