# Fase F1 — Test report

**Data:** 23/11/2026 · **App:** 0.2.0 · **Schema dati:** 3 · **Formato backup:** 2 (legge anche il formato 1 del POC)
**Ambienti:** Node 22.23 + Vitest 2.1.9 + fake-indexeddb (automatici); Chromium 1243 headless, viewport 412×915, IndexedDB reale (prova end-to-end); **Pixel 7a, Android 17, WebView 158.0.8127.46, build b4 (commit d001106)**.

## 1. Conclusione

Il perimetro F1 (D067) è implementato: profilo versionato, censimento attrezzatura D068, archivio definitivo (schema 3), backup formato 2, pagina Storico, correzione DEF-03. 62/62 test automatici superati; migrazione reale POC → F1 con seduta aperta verificata in Chromium. Protocollo F1 sul Pixel 7a eseguito il 23/11/2026: tutti gli 11 test come previsto. **Gate F1 superato; fase chiusa.**

## 2. Definizione dei casi DM01–DM15 e stato

DM01–DM15 erano citati in `TEST_STATUS_VALIDATION_PLAN.md` senza contenuto: li definisco qui.

| ID | Verifica | Automatico | Browser reale | Pixel 7a |
| --- | --- | --- | --- | --- |
| DM01 | Salvataggio atomico della serie | PASSED (POC-02) | — | PASSED nel POC |
| DM02 | Nessuna serie confermata persa dopo chiusura forzata | — | — | PASSED nel POC; ripetizione breve: test 7 |
| DM03 | Nessun duplicato su nuovo tentativo | PASSED | — | PASSED nel POC |
| DM04 | Ripresa della seduta IN_PROGRESS | PASSED | PASSED | test 7 |
| DM05 | Regole di chiusura D058/D059 | PASSED | — | PASSED nel POC |
| DM06 | NULL preservati (RIR mancante ≠ 0) | PASSED | PASSED (Storico) | test 3 |
| DM07 | Migrazione v2→v3 con seduta aperta | PASSED | PASSED (build POC → build F1) | test 1–2 |
| DM08 | Export → import identico (hash) | PASSED | PASSED | test 8 |
| DM09 | File non validi rifiutati, DB invariato (11 POC + 5 nuovi + 1 formato incoerente) | PASSED | — | — |
| DM10 | Import su DB popolato solo con conferma; atomicità con guasti | PASSED | PASSED | test 8 |
| DM11 | Import dei backup del POC (formato 1) | PASSED | — | test 9 |
| DM12 | Profilo: versioni non distruttive, valori fuori intervallo rifiutati | PASSED | PASSED | test 4 |
| DM13 | Etichette uniche/immutabili; oggetti usati non eliminabili | PASSED | PASSED | test 5–6 |
| DM14 | Ordinamento completo, versionato, «da aggiornare» se cambiano gli elastici | PASSED | PASSED | test 5 |
| DM15 | Eliminazione dei soli dati di prova | PASSED | PASSED | test 10 |
| DEF-03 | Etichetta «app Android» nel report | PASSED (funzione) | non applicabile | test 1 |

Output completo: `test-results/vitest-2026-11-23-F1.txt`.

## 3. Difetti trovati durante la fase

| ID | Difetto | Dove | Correzione |
| --- | --- | --- | --- |
| DEF-03 | Report: «browser (scheda)» nell'app | Codice (dal POC) | Etichetta dedicata all'app nativa |
| DEF-04 | Caselle di spunta allargate a tutta riga dopo la modifica del layout dei campi | Interfaccia | Regola di larghezza limitata ai campi di testo |
| DEF-05 | Mesi con iniziale maiuscola nello Storico («Novembre») | Interfaccia | Maiuscola solo sulla prima lettera |
| — | Test «etichetta duplicata» instabile (1 fallimento su ~15): sceglieva a volte due accessori senza etichetta | **Test**, non codice | Il test ora sceglie due elastici; 15/15 esecuzioni superate |
| — | Formato backup 2 rendeva valido il caso POC-09 «versione di formato 2» | Test da adeguare | Caso sostituito da «formato 3» e «formato 1 su file di formato 2» |

## 4. Limiti

- fake-indexeddb e Chromium desktop non riproducono la WebView Android: la migrazione sul telefono (test 1) resta la verifica decisiva.
- La prova in Chromium usa la versione browser con service worker disattivato.
- Nessun test automatico dell'interfaccia (Testing Library non adottata, D048 PROPOSED): l'interfaccia è verificata con la prova end-to-end e con il protocollo.

## 5. Risultati sul Pixel 7a (23/11/2026)

Evidenze: report diagnostico del test 1 (20:08) e dichiarazione dell'utente «funziona tutto» per i test 2–11, come nel POC.

| Test | Evidenza | Esito |
| --- | --- | --- |
| 1 Migrazione reale 0.1 → 0.2, DEF-03 | `schemaVersion: 3`; `displayMode: "app Android (Capacitor)"`; `installId` e `installCreatedAt` (16:03) invariati rispetto al POC; 4 sedute e 48 serie come al test 10a del POC; giornale 28/28, nessuna serie persa; segnaposto del POC conservato come unico oggetto (dismesso) | PASSED |
| 2–11 | Dichiarato | PASSED |

Osservazioni: il report del test 1 è precedente ai test 4–10 (profilo e ordinamenti a 0), quindi documenta la migrazione, non il censimento; l'ultimo backup risultava del POC (16:29), il backup prima dell'aggiornamento non è evidenziato nel report. Il report del test 2 non è stato inviato: esito dichiarato.
