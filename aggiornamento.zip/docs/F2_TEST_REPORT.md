# F2 — Test report, versioni 0.4.0–0.4.4

**Data:** 24 novembre 2026 · **Perimetro:** D092, D093, D095, D098 (ondata 1). La valutazione iniziale (D096–D097) arriva con la 0.4.1.

## Stato dei test

| Area | Stato | Dettaglio |
| --- | --- | --- |
| Test automatici | PASSED 101/101 | 88 esistenti + 13 nuovi (`tests/f2.test.ts`); esito in `docs/test-results/vitest-2026-11-24-0.4.0.txt` |
| Controllo tipi e costruzione web | PASSED | `tsc --noEmit`, `vite build` |
| Prova end-to-end in Chromium (412 × 915) | PASSED | Kit, tappetino, Libreria, squat, split squat a lati, plank col cronometro, rematore con controllo di sicurezza, chiusura parziale, Storico, «provata»; nessun errore JavaScript |
| Ripresa e aggiunta dalla Libreria (Chromium) | PASSED | Ricarica con seduta aperta → Riprendi → «Aggiungi alla seduta in corso» |
| Aggiornamento 0.3.3 → 0.4.0 con seduta aperta (Chromium) | PASSED | Seduta Band Row aperta nella 0.3.3, ripresa nella 0.4.0 con il testo della versione 2 (quella registrata), serie aggiunta, chiusura e valutazione |
| Protocollo sul Pixel 7a | NOT EXECUTED | `docs/PROTOCOLLO_TEST_F2.md` |
| Revisione delle schede da parte dell'utente («provata») | NOT EXECUTED | 0/18 |

## Test automatici nuovi

| ID | Verifica |
| --- | --- |
| F2-LIB-1 | 52 esercizi, ID unici, classificazione coerente; EX011/EX022/EX038 assenti (varianti); 5 nuovi presenti |
| F2-LIB-2 | 18 schede complete: 2–3 indicazioni, preparazione, ≥ 2 errori, sicurezza, scopo, respirazione senza assoluti, fonti esistenti, ancoraggio coerente |
| F2-LIB-3 | Versioni della 0.3.3 identiche byte per byte (impronta SHA-256); rematore v3; schede in arrivo senza contenuto |
| F2-LIB-4 | Caricamento delle schede idempotente, senza riscrivere versioni presenti |
| F2-EQ | Disponibilità per attrezzatura (tappetino, fitball) |
| F2-TESTED | «Provata» / tolta / bozza su versione nuova; solo aggiunte al registro |
| F2-FREE-1 | Seduta con corpo libero, unilaterale e a tempo: prescrizioni di default, lati, NOT_PERFORMED per lato, nomi nello Storico, nessuna valutazione senza rematore |
| F2-FREE-2 | Rifiuti: scheda in arrivo, elastici su esercizio a corpo libero, porta su esercizio senza porta, tipo di elastico sbagliato, controllo di sicurezza, doppione, seconda seduta aperta |
| F2-FREE-3 | Rematore dentro una seduta con altri esercizi: esposizione e valutazione come nella slice |
| F2-FREE-4 | Configurazione proposta: rematore come la slice, altri l'ultima valida o l'elastico più morbido |
| F2-BK-1 | Backup formato 4: export → import identico (classificazione, tappetino, «provata») |
| F2-BK-2 | Backup formato 3 della 0.3.3: importato e completato con le schede nuove |
| F2-BK-3 | Classificazione alterata nel file: backup rifiutato |

Test esistenti modificati per effetto di decisioni approvate: formato del backup atteso 4 invece di 3 (`slice.test.ts`), formato «futuro» 5 invece di 4 (`backup.test.ts`), nomi italiani nello Storico (`f1.test.ts`).

## Difetti trovati e corretti durante la prova

| ID | Difetto | Correzione |
| --- | --- | --- |
| DEF-09 | Aggiungendo un esercizio già presente con un elastico mai usato, l'app chiedeva il controllo di sicurezza invece di segnalare il doppione | Controllo del doppione prima di tutto (test F2-FREE-2) |
| DEF-10 | Elenco della Libreria ridondante («ancoraggio per porta, porta a metà altezza») | Testo unico «ancoraggio alla porta a metà altezza» |
| DEF-11 | Testo della spinta al petto ambiguo sul lato della porta | Stesso criterio del rematore: porta che si apre allontanandosi da te |

## Limiti noti

- Le schede sono bozze scritte da Claude. Le fonti sono riferimenti generali di tecnica; misure pratiche come distanze e tempi sono convenzioni del progetto (fonte CONV).
- Durante il test di aggiornamento il browser ha servito una prima volta la versione vecchia dalla sua cache. Nell'app Android non succede, perché i file sono dentro l'APK. Va comunque verificato con il test 1 del protocollo.
- Schema del database invariato (4): nessun indice nuovo era necessario. Nella proposta avevo indicato «schema 5». La migrazione è quindi solo il caricamento delle nuove schede all'avvio.
- Consegna con `aggiornamento.zip` (D100): la logica di applicazione è stata provata in locale su una copia della 0.3.3. Questa prova copre la validazione dei percorsi, il rifiuto di `.github` e di `..`, la cartella iniziale da saltare e ELIMINA.txt. La prima esecuzione reale su GitHub (salvataggio e pubblicazione) resta da verificare: è il test 13 del protocollo.

## Versione 0.4.1 — recupero, calibrazione, segnalazioni, ricerca (24/11/2026)

**Perimetro:** D101–D104. Esito sul Pixel 7a della 0.4.0: installazione e aggiornamento riusciti (report del 24/11, stesso `installId`, 52 esercizi, 56 versioni, tappetino presente). Il metodo `aggiornamento.zip` ha funzionato al primo uso (build b24). Le «31 serie perse» del giornale diagnostico erano serie di prova eliminate dall'utente, non dati persi (DEF-12).

| Area | Stato | Dettaglio |
| --- | --- | --- |
| Test automatici | PASSED 109/109 | 101 precedenti + 8 nuovi (`tests/f2b.test.ts`); `docs/test-results/vitest-2026-11-24-0.4.1.txt` |
| Chromium end-to-end | PASSED | Ricerca, segnalazione, «Non propormelo», avviso in Libreria, spiegazione della distanza, consiglio di calibrazione, timer (+30 s, Salta), dato del recupero salvato con la serie |
| Notifica a schermo spento | NOT EXECUTED | Possibile solo sul telefono: test 6 di `PROTOCOLLO_TEST_041.md` |
| Protocollo sul Pixel 7a | NOT EXECUTED | `docs/PROTOCOLLO_TEST_041.md` |

| ID | Verifica automatica |
| --- | --- |
| F2B-REST-1 | Recupero per tipo di esercizio, +30 s con RIR 0–1, RIR mancante non trattato come 0, 15 s tra i lati, ogni esercizio del catalogo ha un tipo |
| F2B-REST-2 | Dato del recupero salvato con la serie, valori non validi rifiutati, backup formato 5 identico |
| F2B-CAL-1 | Consigli di calibrazione (porta: distanza; senza porta: elastico); nessun consiglio con fastidio, serie interrotta o corpo libero |
| F2B-CAL-2 | Calibrazione solo la prima volta con l'esercizio |
| F2B-FB-1/2 | Segnalazione → «Da rivedere», ritiro, testo per Claude; «Non propormelo» e ritorno |
| F2B-SEARCH | Ricerca per nome, muscolo, attrezzo, senza accenti e maiuscole |
| F2B-DIAG | Serie di prova eliminate tolte dal giornale diagnostico |

| ID | Difetto | Correzione |
| --- | --- | --- |
| DEF-12 | Il report diagnostico indicava come «perse» le serie di prova eliminate di proposito | Eliminando i dati di prova si ripulisce anche il giornale; le voci vecchie si azzerano da Strumenti |

Nuove dipendenze: `@capacitor/haptics` 8.0.2 e `@capacitor/local-notifications` 8.3.1 (ufficiali Capacitor, versioni di marzo e agosto 2026). Permessi Android nuovi: notifiche (chiesto all'utente), allarmi esatti (`USE_EXACT_ALARM`, concesso automaticamente), avvio dopo il riavvio e mantenimento attivo (dichiarati dal componente delle notifiche).

## Versione 0.4.2 — modello dei domini, valutazione, equilibrio (24/11/2026)

**Perimetro:** D105, D097 rivista, D106, D107 (EX056), D108 (fasi contate in sedute). Schema del database 5 (nuova tabella `domainTrials`), backup formato 6.

| Area | Stato | Dettaglio |
| --- | --- | --- |
| Test automatici | PASSED 123/123 | 109 precedenti + 14 nuovi (`tests/f2c.test.ts`), compresa la lunghezza dichiarata dei tubi |
| Esempio del documento D105 | PASSED | Mediana 3; priorità anca, caviglia, core laterale; asimmetria 29%; rapporto 0,95 in fascia |
| Migrazione 4 → 5 con seduta aperta | PASSED | Test automatico F2C-MIG |
| Chromium end-to-end | PASSED | Fasi chiuse fino al completamento della precedente, limite di 3 prove per visita, controllo minimo (stop e via libera), soglia per lato, scala con salita di livello, rapporto orizzontale, scala alla porta con posizione di riferimento, vista Equilibrio; nessun errore JavaScript. Ripetute anche le prove della 0.4.0 e della 0.4.1 |
| Protocollo sul Pixel 7a | NOT EXECUTED | `docs/PROTOCOLLO_TEST_042.md` |

| ID | Difetto trovato durante lo sviluppo | Correzione |
| --- | --- | --- |
| DEF-13 | Due decisioni registrate nello stesso millisecondo potevano essere lette in ordine sbagliato (es. «provata» e subito «segnala»): gli identificativi non erano crescenti dentro lo stesso millisecondo | UUIDv7 con contatore (RFC 9562 §6.2, metodo 1) e ordinamento stabile; test F2C-IDS |
| DEF-14 | Una scala mai superata (es. rematore mancato al livello 2) dava «livello 0» come se fosse misurato | Diventa una stima «al massimo livello N», con fiducia bassa, esclusa dalla mediana |
| DEF-15 | Una sola misura «limitata» o un'asimmetria non confermata risultavano «normali» invece di «da confermare» | Stato «Possibile ritardo» con motivo, come da D105 |

**Limiti noti**

- Le soglie di ginocchio al muro ed equilibrio sono ancora da verificare su fonti primarie (OI030).
- Gli aggiornamenti del profilo dalle sedute normali arrivano con il motore (F3): nella 0.4.2 il profilo usa solo le prove di valutazione.
- 10 esercizi usati nelle prove non hanno ancora la scheda completa (OI031, ondata 0.4.3): squat con elastico (livelli 3–5 della scala dello squat, settimana 1), affondo indietro, passi laterali, bird dog, plank laterale, 90/90, libro aperto, apertura su un fianco, adduzione con elastico, cinghia per il retro della coscia.
- Lunghezza a riposo dei tubi (115 cm, dichiarata dall'utente) registrata una volta all'avvio nei tubi del kit ancora senza lunghezza, con voce nel registro delle decisioni; gli anelli avevano già 60 cm di circonferenza (30 × 5 cm da piatti). Lunghezza dei tubi: serve alla misura facoltativa della tensione (D106).

## Versione 0.4.3 — seconda ondata di schede, prove di prova, intervallo del recupero (24/11/2026)

**Perimetro:** D095 (ondata 2), D110, D101 esteso. Backup formato 7. Esito 0.4.2 sul Pixel: costruzione, installazione, report e timer a schermo spento confermati dall'utente (prova simulata); la prova sul campo è rimandata al `PROTOCOLLO_CAMPO.md`.

| Area | Stato | Dettaglio |
| --- | --- | --- |
| Test automatici | PASSED 128/128 | 123 precedenti + 5 nuovi (`tests/f2d.test.ts`); 5 test esistenti spostati da EX002 (ora con scheda) a EX012 come esempio di scheda in arrivo |
| Qualità delle schede | PASSED | Le 36 schede rispettano le stesse regole automatiche (indicazioni, respirazione, fonti, ancoraggio); tutti gli esercizi della valutazione hanno la scheda (OI031) |
| Chromium end-to-end | PASSED | Prove 0.4.0–0.4.2 ripetute; eliminazione delle prove di valutazione; schede nuove; intervallo del recupero salvato |
| Prova sul campo | NOT EXECUTED | `docs/PROTOCOLLO_CAMPO.md`, che riunisce 0.4.1–0.4.3 |

**Difetto corretto (DEF-16):** il tempo di recupero oltre la fine del timer non veniva registrato, e chiudendo la barra con ✕ si perdeva il dato del recupero. Ora si salva l'intervallo reale tra le due registrazioni (campo `intervalS`), e ✕ nasconde la barra senza cancellare il dato.

## Versione 0.4.4 — timer di recupero a tutto schermo, recupero reale (24/11/2026)

**Perimetro:** D111 (richiesta dell'utente). Backup formato 8.

| Area | Stato | Dettaglio |
| --- | --- | --- |
| Test automatici | PASSED 131/131 | 128 precedenti + 3 nuovi: recupero misurato col tocco (30 s impostati, tocco a 50 s → 50), tocco anticipato, stima senza tocco mai negativa |
| Chromium end-to-end | PASSED | Timer a tutto schermo, +30 s, «Inizio la serie», recupero salvato come «TAP»; consiglio di calibrazione visibile dentro il timer; prove delle versioni precedenti ripetute |
| Schermo acceso durante il recupero | NOT EXECUTED | Dipende dal WebView del telefono: da verificare nella prova sul campo |
