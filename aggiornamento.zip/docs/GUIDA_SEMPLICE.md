# Guida semplice — aggiornare FitPRO

Serve il PC con il browser e il Pixel 7a. Sul PC non si installa nulla. Tempo: circa 20 minuti.

## Cosa cambia per te (versione 0.4.4)

**Timer di recupero a tutto schermo.** Dopo ogni serie registrata il recupero occupa tutto lo schermo, con numeri grandi leggibili da terra, e lo schermo resta acceso.

- **Fine del recupero:** lo sfondo diventa verde chiaro e il timer continua a contare il tempo in più («+0:20»).
- **Inizio la serie:** toccalo quando riparti, anche prima della fine. L'app registra il recupero reale: se il timer era di 30 secondi e tocchi a 50, registra 50.
- **Se ti dimentichi di toccarlo** e registri direttamente la serie, il recupero viene stimato (tempo trascorso meno la durata della serie) e segnato come «stimato».
- **Consigli e avvisi:** quelli di calibrazione («allontanati di 10–20 cm») e l'avviso di fastidio compaiono dentro il timer.
- **Riduci:** riporta il timer a una barra in basso, se vuoi rileggere la scheda.
- **+30 s:** aggiunge tempo prima della fine.

## Versione 0.4.3 (già installata)


**17 schede nuove** (36 su 53 in tutto): tutti gli esercizi usati nella valutazione ora hanno la scheda, più affondo laterale, stacco a una gamba, polpacci, rematore alto, face pull, flessori dell'anca, gatto e mucca. Leggile anche senza allenarti: se qualcosa non è chiaro, **Segnala un problema**.

**Timer di recupero più completo.** Oltre al recupero suggerito e ai +30 s, l'app registra il tempo reale tra una serie e la successiva: anche se resti fermo oltre la fine del timer, il tempo in più resta salvato. Quel tempo comprende anche l'esecuzione della serie: il motore lo terrà presente. Chiudere la barra con ✕ dopo la fine non cancella il dato.

**Prove di valutazione fatte per prova.** In fondo alla schermata Valutazione: **Elimina tutte le prove di valutazione**. Usalo prima di iniziare la valutazione vera: le prove simulate finirebbero nel profilo «Equilibrio». Le sedute di allenamento non vengono toccate.

## Versione 0.4.2 (già installata)


**Valutazione iniziale.** Dalla Home: «Valutazione ed equilibrio» → **Inizia la valutazione**. Sono 20 prove divise in 3 fasi, contate in sedute e non in settimane: al massimo 3 prove per volta (circa 10 minuti), meglio all'inizio di una seduta e da riposato. La fase successiva si apre quando hai finito quella prima. L'ordine dentro la fase è libero e ogni prova si può ripetere. Con 3 sedute a settimana servono 2–3 settimane, con 6 circa una.

- **Prima delle prove:** tre domande. Con un «sì» niente prove quel giorno; puoi comunque allenarti.
- **Prove a scala:** parti da un livello. Se lo superi, dopo 2 minuti provi quello sopra, al massimo 3 livelli per volta. Per superarlo servono le ripetizioni o i secondi indicati, con tecnica buona o accettabile, senza fastidio e, dove si chiede, con almeno 1 ripetizione ancora possibile (RIR 1 o più).
- **Elastici:** l'app ti dice quale usare (E1 = il più morbido nel tuo ordine). Per gli esercizi alla porta, la prima volta misuri la distanza a cui l'elastico è appena teso: l'app aggiunge 20 cm e quella diventa la tua posizione di riferimento.
- **Prove di mobilità ed equilibrio:** scrivi i cm o i secondi, oppure scegli la descrizione che corrisponde, per lato dove serve.
- **Fastidio:** interrompe la prova e la registra così com'è.

**Equilibrio.** La schermata mostra cosa l'app ha capito:

- **Domini:** livello (1–5) o classe (carente, limitata, adeguata) di ogni dominio, destra e sinistra, quanto è affidabile il dato.
- **Rapporti:** tirate contro spinte, catena posteriore contro anteriore.
- **«Dove insistere»:** al massimo 3 domini, ognuno con il suo motivo.

Un ritardo diventa priorità solo con **due prove concordi**; con una sola prova resta «da confermare». Le priorità guideranno le sedute quando arriverà il motore (F3).

**Nuovo esercizio.** Estensione della schiena da prono, per i muscoli lungo la colonna, che prima nessun esercizio allenava direttamente.

**Nota.** 10 esercizi usati nelle prove non hanno ancora la scheda completa, quasi tutti delle fasi 2 e 3 (in fase 1 solo lo squat con elastico, dal livello 3 della scala dello squat). La seconda ondata di schede (0.4.3) arriva prima delle fasi 2 e 3; nel frattempo ogni prova ha la sua descrizione.

## Versione 0.4.1 (già installata)


**Timer di recupero.** Dopo ogni serie registrata parte da solo, in una barra verde sopra la navigazione. La durata dipende dal tipo di esercizio:

| Tipo di esercizio | Recupero |
|---|---|
| Esercizi principali (squat, rematore, piegamenti…) | 1:30 (2:00 se l'ultima serie era molto dura: RIR 0–1) |
| Complementari (curl, alzate…) | 1:00 |
| Core | 0:45 |
| Mobilità ed equilibrio | 0:30 |
| Tra lato sinistro e destro | 0:15 |

- **+30 s:** aggiunge tempo.
- **Salta:** chiude il recupero.
- **Fine del recupero:** il telefono vibra e suona; a schermo spento arriva una notifica «Recupero finito». La prima volta Android ti chiede il permesso per le notifiche: rispondi **Consenti**, altrimenti a schermo spento non senti nulla.
- **Cosa viene registrato:** recupero suggerito, tempo aggiunto e tempo reale, salvati con la serie successiva. I +30 s servono al motore futuro come segnale (mai da soli).

**Prima volta con un esercizio con elastico.**

- **Distanza:** se la distanza dalla porta è vuota, l'app ti spiega come trovare la posizione di partenza.
- **Dopo ogni serie** ti dice se allontanarti o avvicinarti di 10–20 cm, oppure se cambiare elastico negli esercizi senza porta.
- **Dalla seconda volta** propone la configurazione che hai usato.

**Cerca.** Campo di ricerca nella Libreria e nella scelta dell'esercizio. Cerca per nome, muscolo («femorali») o attrezzo («fitball»), senza badare ad accenti e maiuscole.

**Se una scheda non va bene.** Nella scheda dell'esercizio, **Segnala un problema** → motivo e due righe. La scheda diventa «Da rivedere». In cima alla Libreria compare **Manda le segnalazioni a Claude**: si apre il menu Condividi, scegli dove incollarle o mandale a te stesso e incollale nella chat con Claude. Io correggo e la nuova versione torna «bozza».

**Non propormelo.** Per gli esercizi che non vuoi fare. Il motore delle sedute (F3) li salterà. Tu puoi sempre sceglierli a mano.

**Report diagnostico.** Le serie di prova eliminate non risultano più «perse». Per ripulire le voci vecchie: Profilo → Strumenti → **Azzera giornale di prova**.

## Versione 0.4.0 (già installata)


**Nuova sezione Libreria** (barra in basso): 52 esercizi divisi per gruppo (gambe, spinte, tirate, braccia e spalle, core, equilibrio, mobilità, fiato). Per ognuno vedi attrezzi, muscoli e obiettivo.

- **Schede pronte:** 18 hanno la scheda completa. Contiene a che cosa serve, preparazione, 2–3 indicazioni, respirazione, errori comuni, sicurezza, versione più facile e più difficile, fonti.
- **Schede in arrivo:** le altre 34 arrivano nelle prossime due versioni.
- **Filtro:** «Solo quelli che posso fare con la mia attrezzatura» nasconde gli esercizi per cui ti manca qualcosa.
- **Bozza e Provata:** ogni scheda nasce come **Bozza**. Dopo averla fatta almeno una volta, se si capisce e l'impostazione funziona a casa tua, tocca **Segna come provata**. Se qualcosa non torna, scrivimelo e correggo la scheda.

**Allenamento** (in basso si chiama ora «Allenati»):

- **Qualsiasi esercizio:** puoi allenarti con qualunque esercizio che ha la scheda pronta, anche più di uno nella stessa seduta (**+ Aggiungi un esercizio**). In alto scegli su quale esercizio stai registrando.
- **Esercizi su un lato solo** (es. split squat): registri lato sinistro e poi destro. L'app passa da sola al lato giusto.
- **Esercizi a tempo** (es. plank): c'è un cronometro. Allo stop i secondi finiscono nel campo, e puoi correggerli.
- **RIR:** viene chiesto solo dove ha senso. Non lo chiede per mobilità, plank ed equilibrio.
- **Elastici:** si impostano secondo l'esercizio. Porta con altezza e distanza (rematore, spinta al petto…), elastico sotto i piedi (spinta sopra la testa, stacco rumeno) o elastico ad anello.
- **Proposte di aumento:** restano solo per il rematore, con le stesse regole di prima.

**Dalla scheda all'allenamento:** dalla scheda di un esercizio, **Allenati con questo esercizio** apre subito la preparazione. Se hai una seduta aperta, il pulsante dice **Aggiungi alla seduta in corso**.

### Una cosa da fare subito: il tappetino

Profilo → Attrezzatura → **Aggiungi accessorio** → Tipo **Tappetino** → Aggiungi. Senza, la Libreria nasconde gli esercizi a terra e te lo ricorda.

## Prima di tutto: un backup dalla versione attuale

1. Apri FitPRO sul telefono → **Profilo → Backup** → **Salva backup** → salva su Drive.
2. Se hai una seduta di prova aperta, chiudila o lasciala pure: l'aggiornamento la conserva (è uno dei test).

## Parte 1 — Al PC: caricare l'aggiornamento su GitHub (un solo file)

Da questa versione Claude consegna **un solo file**, `aggiornamento.zip`, e GitHub lo spacchetta da solo (D100).

1. Su GitHub apri lo spazio `fitpro`, nella **cartella principale** (non entrare in nessuna cartella).
2. **Add file → Upload files** → trascina `aggiornamento.zip` così com'è (non aprirlo) → **Commit changes**.
3. Apri la scheda **Actions**: parte la costruzione. Mette ogni file al suo posto, cancella i file che non servono più, verifica tutto ed esegue i test. Solo se è tutto verde salva il risultato e pubblica l'APK, in circa 10 minuti.

Se la costruzione è rossa, il codice su GitHub resta quello di prima. Apri il passaggio rosso e mandami il testo: di solito basta un nuovo zip.

**Eccezione:** i file nella cartella `.github`, come `main.yml`, GitHub non permette di cambiarli con lo zip. Quando servirà, ti scriverò di modificarli a mano, con la matita, incollando un testo. Succede raramente.

## Parte 2 — Sul telefono: installare sopra la versione attuale

1. In Chrome sul Pixel: github.com → spazio `fitpro` → **Releases** → la build più recente → tocca **FitPRO-b….apk**.
2. Apri il file scaricato e scegli **Aggiorna** (non disinstallare mai la versione vecchia: i dati sono dentro l'app).
3. Apri FitPRO. Se avevi una seduta di prova aperta compare «Seduta non conclusa»: è normale.

Poi esegui i test di `PROTOCOLLO_CAMPO.md` (allenamento vero) (cartella `docs`, oppure nel messaggio di Claude).

## Il censimento degli elastici, in breve

1. Profilo → Attrezzatura → **Crea il kit**. L'app registra in un colpo le 20 voci della tua attrezzatura, con i colori e i valori scritti dal produttore. Le sacche di trasporto non vengono registrate. Indica poi quante palline da massaggio hai (tocca la voce e scrivi la quantità).
2. Attacca le etichette (nastro di carta e pennarello):
   - tubi: **E1** giallo, **E2** rosso, **E3** blu, **E4** verde, **E5** nero;
   - anelli: **E6** verde, **E7** blu, **E8** giallo, **E9** rosso, **E10** nero;
   - elastico a 8: **E11** nero.
3. Prova a mano tubi e anelli e tocca **Metti in ordine**: l'app propone l'ordine del produttore, tu lo confermi o lo correggi.

Perché le etichette: lo stesso colore non significa la stessa durezza tra tubi e anelli (il verde è il più morbido degli anelli ma il quarto dei tubi). Il codice evita confusioni nello storico.

I kg scritti dal produttore sono **valori nominali**: la forza reale cambia con quanto tiri l'elastico, la distanza e l'ancoraggio. L'app li conserva come informazione, ma non li userà come carico per decidere le progressioni.

## Regole che restano valide

- Aggiorna sempre installando **sopra**: mai disinstallare.
- Fai un backup almeno ogni 7 giorni e quando l'app te lo propone.
- Non cancellare mai lo spazio GitHub (contiene la chiave di firma) e scaricane ogni tanto una copia (*Code → Download ZIP*).
