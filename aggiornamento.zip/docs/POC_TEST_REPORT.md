# Persistence POC — Test report, rischio residuo e raccomandazione

**Data:** 23/11/2026 · **Build:** 0.1.0 · **Schema dati:** v2 · **Ambiente automatico:** Node 22.23, Vitest 2.1.9, Dexie 4.4.7, fake-indexeddb 6.2.8
**Stato complessivo:** parte automatica completata (39/39 test superati); parte su dispositivo **non ancora eseguita**. La raccomandazione sulla piattaforma è quindi provvisoria.

## 1. Conclusioni

1. La logica di persistenza soddisfa i requisiti verificabili fuori dal dispositivo: atomicità della serie, «salvato» solo dopo il commit, nessun duplicato sui nuovi tentativi, migrazione con seduta aperta, backup validato e import atomico che lascia i dati invariati in tutti gli 11 casi di file non valido e nei 2 guasti simulati a metà import.
2. I due rischi di perdita dati sono distinti e hanno stato diverso:
   - **perdita di una singola scrittura**: controlli implementati e verificati in Node; manca la conferma su Chrome Android (POC-03, POC-04);
   - **perdita dell'intero storage**: non eliminabile in PWA; è controllato solo dal backup esterno. Il dato decisivo è POC-15.
3. Nessun vantaggio concreto emerso per SQLite/WASM: lo spike non è stato avviato (§6).
4. I test hanno trovato **2 difetti reali** nel codice, corretti e coperti da test (§4).

## 2. Stato dei test

Stati: DESIGNED → IMPLEMENTED → EXECUTED → PASSED/FAILED. «Auto» = eseguito da me in Node con IndexedDB simulato; «Device» = protocollo Pixel 7a.

| ID | Test | Dove | Designed | Implemented | Executed | Esito |
| --- | --- | --- | --- | --- | --- | --- |
| POC-01 | CRUD, relazioni, lato, durata, RIR null ≠ 0, USER_ADDED | Auto | Sì | Sì | Sì | PASSED (5 test) |
| POC-02 | Atomicità della serie con guasto iniettato | Auto | Sì | Sì | Sì | PASSED |
| — | Idempotenza (stesso ID non duplica), plausibilità ADV06 | Auto | Sì | Sì | Sì | PASSED (2 test) |
| — | Punto di ripresa, chiusura alla riapertura, stati di chiusura, serie interrotta | Auto | Sì | Sì | Sì | PASSED (4 test) |
| — | «Salvato» mai emesso prima del commit | Auto | Sì | Sì | Sì | PASSED (2 test) |
| POC-03 | Nessuna serie confermata persa su 20 chiusure forzate | Device | Sì | Sì (giornale + diagnostica) | No | NOT EXECUTED |
| POC-04 | Latenza commit strict vs relaxed | Device | Sì | Sì | No | NOT EXECUTED |
| POC-05 | Ripresa dopo chiusura e riavvio | Device | Sì | Sì | No | NOT EXECUTED |
| POC-06 | Migrazione v1→v2 con seduta aperta | Auto + Device | Sì | Sì | Auto sì, Device no | Auto PASSED; Device NOT EXECUTED |
| POC-07 | Aggiornamento app a seduta aperta | Device | Sì | Sì (logica di rinvio) | No | NOT EXECUTED |
| POC-08 | Export → import su installazione pulita, hash identico | Auto + Device | Sì | Sì | Auto sì | Auto PASSED |
| POC-09 | 11 tipi di file non validi rifiutati, DB invariato | Auto | Sì | Sì | Sì | PASSED (11 test) |
| POC-10 | Import su DB popolato: conferma, atomicità con 2 guasti, seduta aperta, backup v1 | Auto | Sì | Sì | Sì | PASSED (6 test) |
| POC-11 | Offline, app installata e scheda | Device | Sì | Sì | No | NOT EXECUTED |
| POC-12 | Errore di quota simulato | Auto | Sì | Sì | Sì | PASSED |
| POC-13 | Backup reale (Drive/download) e ripristino | Device | Sì | Sì | No | NOT EXECUTED |
| POC-14 | Prestazioni 5 anni | Auto (indicativo) + Device | Sì | Sì | Auto sì | Auto PASSED (indicativo); Device NOT EXECUTED |
| POC-15 | Scenari di cancellazione storage | Device | Sì | Sì (rilevazione `installId`) | No | NOT EXECUTED (informativo) |
| POC-16 | `persist()` e quota | Device | Sì | Sì | No | NOT EXECUTED (informativo) |
| — | Promemoria backup a 7 giorni (D3) | Auto | Sì | Sì | Sì | PASSED (3 test) |

Output completo: `docs/test-results/vitest-2026-11-23.txt`.

**Prestazioni in Node (indicative, non rappresentano Chrome Android):**

| Dataset | Sedute | Serie | Query storico esercizio p95 | Export + hash |
| --- | --- | --- | --- | --- |
| 5 anni, 2,5 sedute/settimana | 650 | 7.800 | 12,4 ms | 165 ms |
| 5 anni, 7,5 sedute/settimana (×3) | 1.950 | 23.400 | 5,2 ms | 427 ms |

## 3. Limiti della verifica automatica

- **fake-indexeddb non riproduce la durabilità su disco di Chrome.** I test dimostrano la correttezza della logica transazionale, non che un commit `strict` sopravviva a una chiusura del processo: lo dimostrano solo POC-03/04.
- I guasti (errore a metà transazione, quota) sono **simulati** tramite hook Dexie, non provocati da un vero esaurimento di spazio.
- Nessun test automatico su browser reale: l'ambiente di sviluppo non consente il download dei browser per Playwright.
- POC-07 non ha test automatico: la logica di rinvio dipende dal ciclo di vita del service worker, verificabile solo su dispositivo.

## 4. Difetti trovati e corretti

| ID | Difetto | Effetto se non corretto | Correzione | Verifica |
| --- | --- | --- | --- | --- |
| DEF-01 | `uuidv7` falliva con timestamp non interi | Errore nella generazione di ID da tempi calcolati (es. dati importati o sintetici) | Arrotondamento del timestamp | Test POC-14 |
| DEF-02 | Seduta con sola serie interrotta chiusa come CANCELLED | Lavoro realmente eseguito classificato come «annullato»; distorsione dello storico | Le serie INTERRUPTED contano come lavoro eseguito → PARTIALLY_COMPLETED | Test dedicato |

Un terzo errore era nel test, non nel codice (soglia di serie attese calcolata male da me): corretto il test.

## 5. Valutazione del rischio residuo di perdita dati

Scala qualitativa: Gravità (G) 1–5, Probabilità (P) 1–5, Rilevabilità (R) 1–5 (5 = difficile da rilevare). Valori **provvisori**, da rivedere con gli esiti su dispositivo.

### Rischio A — perdita di una singola scrittura

| Causa | Controlli implementati | G | P | R | Stato |
| --- | --- | --- | --- | --- | --- |
| Commit «relaxed» non ancora su disco alla chiusura | Durabilità `strict` su tutto il DB principale | 2 | 1 | 4 | Da confermare (POC-03/04) |
| UI mostra «salvato» prima del commit | `runSave`: stato `saved` solo alla risoluzione della transazione | 3 | 1 | 2 | Verificato (Auto) |
| Chiusura a metà transazione | Transazione unica serie + seduta | 2 | 2 | 2 | Verificato (Auto) |
| Doppio tocco / nuovo tentativo | ID generato prima del primo tentativo; `already_saved` | 1 | 3 | 1 | Verificato (Auto) |
| Spazio esaurito | Errore esplicito, dati del modulo conservati, nessun «salvato» | 2 | 1 | 1 | Verificato (Auto, simulato) |

**Residuo atteso:** basso. Perdita massima teorica: la serie in corso di salvataggio, mai mostrata come salvata.

### Rischio B — perdita dell'intero storage

| Causa | Controlli | G | P | R | Note |
| --- | --- | --- | --- | --- | --- |
| Pulizia «Cookie e dati dei siti» in Chrome | Backup esterno; promemoria a 7 giorni; data ultimo backup sempre visibile | 5 | **dipende dalle tue abitudini** | 3 | Causa più probabile; non mitigabile in PWA |
| Disinstallazione della PWA | Come sopra | 5 | 2 | 3 | Comportamento da misurare (POC-15b) |
| Sfratto automatico per spazio | `persist()` riduce la probabilità se concesso | 5 | 1 | 3 | POC-16 |
| Perdita, furto o ripristino del telefono | Solo backup esterno | 5 | 1 | 1 | Riguarda anche Capacitor e app native |

Il rilevamento della cancellazione è debole: l'avviso «probabile cancellazione» compare solo se sopravvive il giornale in localStorage, che di norma viene cancellato insieme al database. In pratica l'utente se ne accorge vedendo lo storico vuoto.

**Residuo atteso:** la perdita massima coincide con i dati successivi all'ultimo backup esportato. Con promemoria rispettato: al più circa 7 giorni (2–3 sedute). Se i promemoria vengono ignorati, il residuo non ha limite superiore.

**Limite da conoscere:** l'app registra la data di **esportazione**, non può verificare che il file sia stato effettivamente salvato a destinazione.

## 6. Spike SQLite/WASM: non avviato

Criterio approvato: avviarlo solo davanti a un vantaggio concreto o a un problema che Dexie non risolve. Nessuno dei due è emerso:

- integrità referenziale: garantita dal repository e verificata all'import (POC-09 «relazione rotta»);
- migrazioni: gestite da Dexie con trasformazione dei dati (POC-06);
- prestazioni: margini ampi ai volumi attesi (§2);
- rischio di cancellazione: identico, perché OPFS appartiene allo stesso storage d'origine.

Lo spike andrebbe riconsiderato solo se POC-03 fallisse con Dexie in modalità `strict`.

## 7. Raccomandazione sulla piattaforma (provvisoria)

**Proseguire con la PWA**, a tre condizioni verificate su dispositivo:

1. POC-03, 05, 06, 11, 13 superati e POC-04 entro soglia;
2. POC-15b (disinstallazione) documentato;
3. tua accettazione esplicita del rischio B, sulla base delle tue abitudini con Chrome.

**Passare a Capacitor** se:
- usi abitualmente «Elimina dati di navigazione» con «Cookie e dati dei siti» (POC-15d), oppure
- non accetti che la protezione dello storico dipenda dal backup manuale.

Capacitor elimina il rischio legato alla pulizia di Chrome e consente backup su file o tramite il backup automatico di Android (funzionalità da verificare), ma non protegge da perdita o ripristino del telefono. Costi: APK firmato installato manualmente, nuova build per ogni aggiornamento, Android Studio. Grazie al repository pattern la migrazione riguarda lo strato dati, non il dominio: in quel caso preparerei una proposta formale.

## 8. Decisioni di cui ho bisogno

| ID | Decisione | Quando |
| --- | --- | --- |
| R1 | Esecuzione del protocollo Pixel 7a e invio dei report JSON | Ora |
| R2 | Usi la pulizia «Cookie e dati dei siti» di Chrome? Con che frequenza? | Ora: è il dato che più cambia la raccomandazione |
| R3 | Approvazione degli aggiornamenti documentali proposti (`PROPOSED_DOC_UPDATES.md`) | Dopo R1 |

## 9. Aggiornamento — variante app Android (Capacitor), 23/11/2026

**Decisione:** approvata la prova della variante Capacitor (R2: l'utente pulisce occasionalmente i dati dei siti in Chrome).

**Cosa cambia:** la stessa app web, con lo stesso Dexie e lo stesso codice di dominio, è impacchettata come APK. Lo storage è quello della WebView dell'app, privato e separato da Chrome.

| Elemento | Scelta | Stato |
| --- | --- | --- |
| Identificativo app | `app.fitpro.personal` — da non cambiare mai | Fissato |
| Backup | Scrittura in cache dell'app + menu Condividi di Android (il download del browser non funziona in WebView) | IMPLEMENTED, non eseguito su dispositivo |
| Service worker | Disattivato nella build app (`TARGET=app`); aggiornamenti tramite nuovo APK | IMPLEMENTED |
| Firma | Chiave PKCS12 RSA 3072 bit, validità 10.000 giorni, conservata nel repository privato | IMPLEMENTED — v. rischio sotto |
| Build | GitHub Actions: test → build web → `cap sync` → Gradle `assembleRelease` → Release privata | IMPLEMENTED, **NOT EXECUTED**: nel mio ambiente gli strumenti Android non sono scaricabili |
| Versione | `versionCode` = numero di esecuzione della pipeline, sempre crescente | IMPLEMENTED |

**Stato dei test:** i 39 test automatici restano PASSED (codice condiviso). Tutti i test su dispositivo sono riformulati per l'APK in `PROTOCOLLO_TEST_PIXEL7A.md` e sono NOT EXECUTED. Il test decisivo è il 10a: pulizia «Cookie e dati dei siti» in Chrome con dati dell'app che devono restare.

**Rischi nuovi introdotti dalla variante:**

| Rischio | Gravità | Mitigazione |
| --- | --- | --- |
| Perdita della chiave di firma → impossibile aggiornare senza disinstallare (dati sul telefono persi) | Alta | Chiave nel repository privato; copia periodica del repository; backup D054 per ripristinare dopo reinstallazione |
| Accesso al repository da parte di terzi → possibilità di firmare versioni false | Media | Repository privato, accesso solo dell'utente; autenticazione a due fattori GitHub raccomandata |
| Disinstallazione accidentale | Alta | Backup D054; la guida avverte di aggiornare sempre sopra la versione esistente |
| Prima build sulla pipeline non verificata | Bassa (blocca, non perde dati) | Correzione sulla base del log di errore |

## 10. Risultati su dispositivo — app Android, 23/11/2026

**Ambiente:** Google Pixel 7a, Android 17 (SDK 37, build CP4A.261105.040.A1), Android WebView 158.0.8127.46. App 0.1.0, build b1 → b2 (commit 707fa8e), schema dati v2. Installazione da APK firmato, scaricato dalla Release privata GitHub.

**Esito complessivo: tutti i test su dispositivo superati.** Le evidenze numeriche provengono dai report JSON di diagnostica; per i test 2 (giri interrotti), 4, 5, 7, 8 e 10b–d l'evidenza è la dichiarazione dell'utente «tutto ok» (esito come previsto dal protocollo).

| Test protocollo | ID | Evidenza | Criterio | Esito |
| --- | --- | --- | --- | --- |
| 1 Ambiente | — | Report 16:04 | Versioni rilevate | PASSED |
| 2 Serie confermate | POC-03 | Giornale: 23/23 trovate, 0 perse (16:14); 28/28 a fine sessione (16:38); nessun duplicato (dichiarato) | 0 perse, 0 duplicati | PASSED |
| 3 Latenza commit | POC-04 | strict p95: 15,4 / 6,3 / 7,3 ms; relaxed p95: 6,4 / 5,8 / 4,5 ms | strict p95 ≤ 100 ms | PASSED — costo della durabilità strict circa 1–2 ms in mediana |
| 4 Ripresa | POC-05 | Dichiarato | Punto corretto, anche dopo riavvio | PASSED |
| 5 Migrazione | POC-06 | Dichiarato `pass: true` | pass | PASSED |
| 6 Aggiornamento con seduta aperta | POC-07 | Build b1 → b2; `installId` invariato; dati presenti | Seduta integra dopo aggiornamento | PASSED |
| 7 Offline | POC-11 | Dichiarato | Funzionamento completo | PASSED |
| 8 Backup e ripristino | POC-13 | `lastExportAt` 16:29; `lastImport` presente; file rovinato rifiutato (dichiarato) | Ripristino ok, file corrotto rifiutato | PASSED |
| 9 Prestazioni 5 anni | POC-14 | Query storico p95 5 ms; riapertura 2 ms; export+hash 287 ms; generazione 2,1 s | ≤ 300 ms / ≤ 3000 ms | PASSED (1 esecuzione su 2 previste) |
| 10a Pulizia «Cookie e dati dei siti» in Chrome | POC-15 | `installId` invariato dalla creazione (16:03); 4 sedute, 48 serie, 28/28 serie del giornale | Dati dell'app conservati | PASSED |
| 10b Svuota cache app | POC-15 | Dichiarato | Dati conservati | PASSED |
| 10c Reinstallazione sopra | POC-15 | Dichiarato | Dati conservati | PASSED |
| 10d Cancella spazio di archiviazione | POC-15 | Dichiarato | Dati cancellati, ripristino da backup riuscito | PASSED |

**Osservazioni:**
- `persisted: false`: non rilevante per l'app Android, il cui storage non dipende dalle regole di Chrome (confermato da 10a).
- Difetto di diagnostica **DEF-03**: `displayMode` riporta «browser (scheda)» anche nell'app. Solo etichetta, nessun impatto sui dati. Da correggere.
- Test 2: i 2 giri chiusi durante «Salvataggio in corso…» non sono distinguibili nei dati; l'assenza di duplicati è dichiarata dall'utente.

## 11. Rischio residuo aggiornato e raccomandazione finale

| Rischio | Prima (PWA) | Ora (app Android) |
| --- | --- | --- |
| Perdita di una serie confermata | Da verificare | **Basso, verificato** (0 perse su 28, durabilità strict) |
| Cancellazione per pulizia di Chrome | Alto, per abitudine dell'utente | **Eliminato** (test 10a) |
| Disinstallazione o «Cancella spazio di archiviazione» | Presente | Presente: perdita limitata ai dati successivi all'ultimo backup (test 10d) |
| Perdita/ripristino del telefono | Presente | Presente: coperto solo dal backup |
| Perdita della chiave di firma | — | Nuovo: obbliga a reinstallare; dati recuperabili dal backup |

**Raccomandazione:** adottare definitivamente **app Android con Capacitor + Dexie** (D052) e chiudere il Persistence POC. SQLite/WASM non necessario (D046). Gli aggiornamenti documentali corrispondenti richiedono approvazione dell'utente.
