# Aggiornamenti documentali proposti — NON applicati

Nessun requisito o decisione approvata è stato modificato. Le voci marcate **richiede approvazione** sono comportamenti che il POC ha dovuto fissare per funzionare: sono isolati, marcati PROVISIONAL nel codice e reversibili.

## 1. Richiedono approvazione

| ID | Tema | Comportamento nel POC | Motivazione | Alternativa |
| --- | --- | --- | --- | --- |
| P-01 | Stato alla chiusura della seduta | Nessuna serie eseguita né interrotta → CANCELLED; tutte eseguite e nessuna interrotta → COMPLETED; altrimenti PARTIALLY_COMPLETED | 12 §7 elenca gli stati ma non la regola di attribuzione | CANCELLED solo su scelta esplicita dell'utente |
| P-02 | Serie NOT_PERFORMED | Create alla chiusura per ogni serie/lato prescritti e non registrati | Rende esplicita la differenza tra «non eseguita» e «dato mancante» (M2) | Calcolarle senza memorizzarle |
| P-03 | Motivo di chiusura | `closeReason`: FINISHED_BY_USER / CLOSED_ON_REOPEN | Tracciare la chiusura alla riapertura richiesta in D6 | Nessun campo |
| P-04 | Ripristino | Solo sostituzione integrale, atomica, con conferma su DB popolato; vietato con seduta aperta | Unione di storici: regole di conflitto non definite e rischio di duplicati | Import in unione (da progettare) |
| P-05 | Soglie di plausibilità | Ripetizioni > 60 o durata > 600 s richiedono conferma | ADV06 senza soglie | Soglie per esercizio |
| P-06 | Durabilità `strict` per tutte le transazioni | Applicata a tutto il DB principale | Più semplice e sicuro; costo da misurare (POC-04) | Solo per le scritture di serie |
| P-07 | Aggiornamenti app | Proposti solo senza sedute aperte; dopo chiusura completa dell'app il nuovo service worker può attivarsi (ciclo di vita standard), quindi la tutela della seduta si basa sulla compatibilità delle migrazioni | Requisito «gli aggiornamenti non compromettono la seduta» | Bloccare l'attivazione con logica custom: complessa e fragile |

## 2. Recepimento di decisioni già approvate (solo testo)

| Documento | Modifica |
| --- | --- |
| DECISION_LOG.md | Intestazione «ARCHIVIATO il 23/11/2026 — documento storico; stato corrente in DECISION_REGISTER» (D1/M1) |
| DECISION_REGISTER.md | Nuove voci: D053 Fonte unica (APPROVED); D054 Politica di backup D3 (APPROVED); D055 Estensioni schema M2 (APPROVED, senza soglia ABANDONED); D056 Riorientamento POC M6 (APPROVED); D045 Dexie → «IN VALIDATION (POC)»; D046 SQLite/WASM → «NOT PURSUED salvo esito POC-03» |
| 21_DATA_MODEL_END_TO_END.md | Campi SetPerformance `side`, `durationS`, `rpe`, `plausibility`, `tzOffsetMin`, `exerciseId`; stati PERFORMED/INTERRUPTED/NOT_PERFORMED; ExercisePrescription `origin`, `sidesPerSet`; WorkoutSession `closeReason`, `tzOffsetMin`; nessuno stato ABANDONED; alla riapertura l'utente sceglie riprendi/chiudi |
| 12_DATA_ARCHITECTURE.md §7 | Allineare gli stati della serie a 21 |
| ARCHITECTURE.md §5–§8 | Durabilità `strict`; backup JSON con checksum canonico; import validato e atomico; aggiornamento PWA in modalità prompt; hosting Cloudflare Pages + Access |
| OPEN_ISSUES.md | OI002 «IN VALIDATION — POC automatico completato, test su dispositivo pendenti»; OI004 «parzialmente risolto (backup/restore), quota e cancellazione storage in verifica»; OI012 «implementato nel POC, da verificare (POC-07)» |
| CHANGELOG.md | CH025 POC persistenza (TEST, MEDIUM); CH026 DEF-01; CH027 DEF-02 |
