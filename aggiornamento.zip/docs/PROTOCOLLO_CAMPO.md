# Prova sul campo — allenamento vero (versioni 0.4.1–0.4.4)

Da fare con un allenamento vero, quando hai tempo (es. venerdì): circa 60 minuti. Servono elastici, porta, tappetino, parete, metro e un appoggio stabile.

## Prima di iniziare (5 minuti)

1. **Backup** su Drive.
2. **Dati di prova:** Valutazione → **Elimina tutte le prove di valutazione**; Storico → segna come prova le sedute finte → **Elimina dati di prova**. Così il profilo parte pulito.
3. **Report completo:** controlla `app.version` 0.4.4 e `domainTrials` 0.

## Parte A — Seduta libera (30 minuti)

Scegli 4 esercizi: almeno uno con l'elastico alla porta **mai fatto prima** (es. rematore alto o Pallof press), uno su un lato solo (es. affondo indietro), uno a tempo (plank laterale) e uno a corpo libero.

| N. | Cosa osservi | Annota |
| --- | --- | --- |
| A1 | Prima volta con l'esercizio alla porta: la spiegazione per la distanza ti porta a una posizione sensata? | Distanza scelta, ripetizioni e RIR della prima serie |
| A2 | Dopo ogni serie il consiglio (allontanati, avvicinati, tienila) va nella direzione giusta? | Sì/no per ogni serie |
| A3 | Il recupero suggerito è giusto, corto o lungo? Ti sei trovato a usare +30 s o a restare oltre? Hai toccato «Inizio la serie» ogni volta, o te ne sei dimenticato? | Per tipo di esercizio |
| A4 | Il timer a tutto schermo si legge bene da terra? Senti l'avviso di fine recupero (suono e vibrazione)? I consigli di calibrazione dentro il timer si leggono? | Sì/no |
| A5 | Negli esercizi su un lato solo l'app passa correttamente da sinistro a destro? | Sì/no |
| A6 | Le schede si capiscono mentre fai l'esercizio? | Per le schede poco chiare: **Segnala un problema** |
| A7 | Registrare una serie richiede meno di 10 secondi? | Tempo indicativo |

## Parte B — Valutazione, fase 1 (20 minuti, al massimo 3 prove per volta)

| N. | Cosa osservi | Annota |
| --- | --- | --- |
| B1 | Le tre domande iniziali sono chiare e non fastidiose? | Sì/no |
| B2 | Ginocchio al muro: istruzioni chiare, misura facile con il metro? | cm sinistra e destra |
| B3 | Scala dei piegamenti: i livelli salgono in modo regolare o c'è un salto troppo grande? | Livelli superati e ripetizioni |
| B4 | Plank: il gradino di partenza (dead bug) ha senso? | Livello raggiunto |
| B5 | Dopo la fase 1 completa: la schermata Equilibrio corrisponde a come ti senti? Qualcosa ti sorprende? | Commento libero |
| B6 | **Difficoltà relativa:** un livello ti è sembrato molto più facile o più difficile del livello con lo stesso numero di un altro dominio? | È il dato per tarare il modello |

## Dopo

- **Segnalazioni:** Libreria → **Manda le segnalazioni a Claude**.
- **Report completo** e **backup** su Drive.
- **Mandami:** la tabella con le note, il testo delle segnalazioni e il report.
