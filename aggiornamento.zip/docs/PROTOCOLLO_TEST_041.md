# Test sul Pixel 7a — versione 0.4.1 (recupero, ricerca, segnalazioni)

Circa 20 minuti. Servono gli elastici e la porta. **Prima:** backup su Drive.

| N. | Cosa fai | Cosa deve succedere |
| --- | --- | --- |
| 1 | Installi la 0.4.1 sopra la 0.4.0, poi Profilo → Strumenti → Diagnostica → *Report completo* | `app.version: 0.4.1`, stesso `installId`, dati presenti |
| 2 | Profilo → Strumenti → **Azzera giornale di prova**, poi di nuovo *Report completo* | `killTestJournal`: `confirmed: 0`, `lost: []` |
| 3 | Libreria → scrivi «femorali», poi «fitball», poi «STACCO» | Elenchi corretti; la ricerca ignora gruppi e maiuscole |
| 4 | Allenati → scegli un esercizio a corpo libero → Inizia → registra una serie | Android chiede il permesso per le notifiche → **Consenti**; parte la barra del recupero con il tempo suggerito |
| 5 | Durante il recupero tocca **+30 s**, poi lascia finire con l'app aperta | Il tempo aumenta di 30 s; alla fine il telefono vibra e suona, la barra dice «Via!» |
| 6 | Registra un'altra serie, poi **spegni lo schermo** e aspetta la fine del recupero | Arriva la notifica «Recupero finito» con vibrazione, puntuale (entro pochi secondi) |
| 7 | Riaccendi, registra la serie dopo, poi tocca **Salta** sul nuovo recupero | La barra dice «Saltato» |
| 8 | Aggiungi un esercizio su un lato solo (es. split squat): lato sinistro | Recupero di 15 s, poi lato destro |
| 9 | Aggiungi un esercizio con elastico alla porta **mai fatto** (es. Pallof press), lascia vuota la distanza | Compare la spiegazione per trovare la posizione di partenza |
| 10 | Fai una serie facilissima (RIR 5+) | Sotto: «Troppo facile: allontanati di 10–20 cm» |
| 11 | Apri una scheda → **Segnala un problema** → motivo + nota → Invia | Scheda «Da rivedere»; in cima alla Libreria l'avviso con **Manda le segnalazioni a Claude** |
| 12 | Tocca **Manda le segnalazioni a Claude** | Si apre il menu Condividi con il testo delle segnalazioni |
| 13 | Nella stessa scheda: **Ritira la segnalazione**, poi **Non propormelo** | Torna «Bozza»; nell'elenco compare «Non proposto» |
| 14 | Chiudi la seduta, backup su Drive e ripristino dello stesso file | Sedute, recuperi, segnalazioni e «Non proposto» identici |

Mandami la tabella con sì/no e note, e il testo delle segnalazioni se ne hai fatte di vere. Dimmi anche:

- **Avviso:** se è abbastanza forte da sentirlo durante l'allenamento.
- **Durate:** se i recuperi suggeriti ti sembrano giusti.

| Test | Come previsto? | Note |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |
| 8 | | |
| 9 | | |
| 10 | | |
| 11 | | |
| 12 | | |
| 13 | | |
| 14 | | |
