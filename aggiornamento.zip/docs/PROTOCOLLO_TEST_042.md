# Test sul Pixel 7a — versione 0.4.2 (valutazione ed equilibrio)

Circa 30 minuti in più visite (al massimo 3 prove per volta). Servono gli elastici, la porta, il tappetino, un metro e una parete. **Prima:** backup su Drive.

| N. | Cosa fai | Cosa deve succedere |
| --- | --- | --- |
| 1 | Installi la 0.4.2 sopra la 0.4.1, poi *Report completo* | `app.version: 0.4.2`, `schemaVersion: 5`, tabella `domainTrials: 0`, stesso `installId`, dati presenti |
| 2 | Home → Inizia la valutazione | 20 prove in 3 fasi; le fasi 2 e 3 sono chiuse finché la fase 1 non è completa |
| 3 | Inizia la valutazione → una prova → rispondi «Sì» a una delle tre domande | «Oggi niente prove»; le prove non sono selezionabili fino alla riapertura dell'app |
| 4 | Chiudi e riapri l'app → Valutazione → **Ginocchio al muro**, tre «No» | Misuri sinistra e destra in cm; il risultato mostra la classe per lato |
| 5 | **Scala dei piegamenti**: fai il livello proposto, poi quello sopra se lo superi | Dopo un livello superato: recupero di 2 minuti e «Prova il livello N+1»; massimo 3 livelli; alla fine «Livello raggiunto oggi» |
| 6 | **Plank** con il cronometro | I secondi compaiono nel campo; RIR non richiesto |
| 7 | Dopo 3 prove nella stessa visita | «Per oggi bastano 3 prove»; le altre restano chiuse fino alla riapertura dell'app |
| 8 | Completa la fase 1 (in più visite), poi **Scala del rematore** e **Rematore contro spinta al petto** | Fase 2 aperta; posizione di riferimento = misura a elastico appena teso + 20 cm; l'app indica l'elastico del livello; il rapporto registra le ripetizioni dei due esercizi |
| 9 | Una prova con «Ho sentito fastidio» spuntato | La prova si interrompe e resta registrata, senza messaggi di allarme |
| 10 | Valutazione → **Vedi il profilo «Equilibrio»** | Livelli e classi delle prove fatte, fiducia «media», nessuna priorità confermata (serve una seconda prova), rapporto orizzontale calcolato |
| 11 | Libreria → cerca «prono» | Compare «Estensione della schiena da prono» con la scheda |
| 12 | Backup su Drive e ripristino dello stesso file | Prove e profilo identici |
| 13 | Report completo | `domainTrials` uguale al numero di prove registrate |

Dimmi anche:

- **Istruzioni:** quali istruzioni delle prove non sono chiare.
- **Difficoltà:** se un livello ti è sembrato molto più facile o più difficile degli altri. È il dato che serve per tarare l'equivalenza tra domini.

| Test | Come previsto? | Note |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |
| 8 | | |
| 9 | | |
| 10 | | |
| 11 | | |
| 12 | | |
| 13 | | |
