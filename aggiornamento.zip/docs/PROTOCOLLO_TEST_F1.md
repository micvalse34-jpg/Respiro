# Test sul Pixel 7a — fase F1 (versione 0.2)

Ogni test dice cosa fare e cosa deve succedere. Se succede altro, annotalo così com'è. Per i test con **Report** vai su Profilo → Strumenti → Diagnostica, tocca il pulsante indicato, poi **Condividi** e incollami il testo.

**Prima:** backup dalla versione attuale (Guida, «Prima di tutto»). Ideale: una seduta di prova aperta con 2 serie registrate.

| N. | Cosa fai | Cosa deve succedere | Copre |
| --- | --- | --- | --- |
| 1 | Installi la versione 0.2 sopra la 0.1 e apri l'app. Poi *Report completo* | Se avevi una seduta aperta: «Seduta non conclusa», con **Riprendi** ritrovi le serie. Nel report: `schemaVersion: 3`, `displayMode: "app Android (Capacitor)"`, `installId` uguale a prima | DM07 migrazione reale, DEF-03 |
| 2 | *Autotest migrazione v2→v3* | `"pass": true` | DM07 |
| 3 | Storico: la lista è vuota; spunti «Mostra anche le sedute di prova», apri una seduta | Compaiono le sedute del POC con le serie; «RIR non rilevato» dove non l'avevi inserito | Storico |
| 4 | Profilo → Dati personali: compili e salvi; cambi il peso e salvi di nuovo | «Salvato sul dispositivo»; sotto: «Versioni conservate: 2» | DM12 |
| 5 | Attrezzatura → **Crea il kit**; metti in ordine tubi e anelli; indica la quantità delle palline da massaggio | «Creati 20 oggetti»; Home: «Censimento completo» | DM13, DM14 |
| 6 | Attrezzatura → tubi → **Aggiungi** con codice **E3** | Messaggio «L'etichetta E3 è già assegnata», nulla salvato | DM13 |
| 7 | Strumenti → Inizia seduta di prova → registra 2 serie → chiudi l'app dalle recenti **appena** compare «Salvato» → riapri → Riprendi → chiudi la seduta | Le serie ci sono; nello Storico la seduta mostra «Elastici usati: E1 giallo» | DM02, DM04 |
| 8 | Backup → Salva backup su Drive → Ripristina lo stesso file (spunta «Sostituisci») | «Ripristino completato»; profilo, attrezzatura e Storico identici | DM08, DM10 |
| 9 | Backup → Ripristina il **vecchio** file salvato dalla versione 0.1 (poi ripristina di nuovo quello del test 8) | Il vecchio file viene accettato («backup della versione di prova») | DM11 |
| 10 | Storico → **Elimina le sedute di prova** → Sì, elimina | Storico vuoto; profilo e attrezzatura invariati | DM15 |
| 11 | Modalità aereo, chiudi e riapri, salva una modifica al profilo | Tutto funziona | Offline |

Alla fine: un backup finale su Drive, poi mandami la tabella compilata e i report dei test 1 e 2.

| Test | Come previsto? (sì/no) | Note |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |
| 8 | | |
| 9 | | |
| 10 | | |
| 11 | | |
