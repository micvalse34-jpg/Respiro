# Test sul Pixel 7a — libreria e seduta libera (versione 0.4.0)

Servono il tappetino, la porta con l'ancoraggio, gli elastici etichettati, un appoggio stabile (tavolo o ripiano) e una parete libera. Tempo: circa 40 minuti, anche in due volte.

Per il test 1: Profilo → Strumenti → Diagnostica → *Report completo* → **Condividi**, poi incollami il testo.

**Prima:** backup su Drive dalla versione attuale (0.3.3).

| N. | Cosa fai | Cosa deve succedere |
| --- | --- | --- |
| 1 | Installi la 0.4.0 sopra la 0.3.3 e fai *Report completo* | `app.version: 0.4.0`, `schemaVersion: 4`, `installId` uguale a prima; profilo, attrezzatura e sedute presenti |
| 2 | Aggiungi il tappetino, poi apri **Libreria** | In alto «52 esercizi · 18 schede pronte»; con il filtro attivo vedi anche gli esercizi a terra |
| 3 | Libreria → **Squat a corpo libero** → **Allenati con questo esercizio** → Inizia → 3 serie vere | Ogni serie si registra con RIR; «Salvato sul dispositivo» dopo ognuna |
| 4 | Nella stessa seduta: **+ Aggiungi un esercizio** → Split squat → 1 serie per lato | Dopo il lato sinistro l'app passa da sola al destro; in alto i due esercizi con il conteggio delle serie |
| 5 | Aggiungi **Plank sugli avambracci** → Avvia cronometro → tieni → Ferma → Registra | I secondi compaiono nel campo; il RIR non viene chiesto |
| 6 | Aggiungi il **Rematore con elastico** → 1–2 serie con l'elastico e la distanza di sempre | Configurazione proposta come prima (proposta accettata o ultima usata) |
| 7 | Durante una serie chiudi l'app dalle recenti, riapri → **Riprendi** | Ritrovi la seduta con tutti gli esercizi e le serie già registrate |
| 8 | **Chiudi seduta** prima di finire tutte le serie → Sì, chiudi | La seduta nello Storico è «parziale»; ogni esercizio ha il suo nome italiano e le serie mancanti risultano non eseguite |
| 9 | Libreria → Spinta sopra la testa con elastico → Allenati | Chiede solo l'elastico (niente porta né distanza); con un elastico mai usato chiede il controllo |
| 10 | Libreria → apri un esercizio che hai fatto → **Segna come provata** → torna all'elenco | Il segno «Bozza» diventa «Provata»; puoi toglierlo |
| 11 | Backup su Drive, poi ripristino dello stesso file | Sedute, segni «provata» e tappetino identici |
| 12 | Modalità aereo: una seduta con due esercizi | Tutto funziona |
| 13 | Su GitHub, dopo la costruzione verde: guarda la cartella principale | Non c'è più `aggiornamento.zip` né i circa 60 file fuori posto; nella cronologia c'è il salvataggio «Aggiornamento 0.4.0 applicato da aggiornamento.zip» |

Le schede sono una **bozza**: leggile mentre fai l'esercizio. Per ognuna che provi dimmi se c'è un'indicazione poco chiara, sbagliata per casa tua o superflua.

Mandami la tabella con sì/no e le note, il report del test 1 e un giudizio sincero su tre cose:

- **Tempo:** quanto ci metti a registrare una serie (obiettivo: meno di 10 secondi).
- **Lettura:** leggibilità con il telefono appoggiato a terra.
- **Esercizi:** come si cambia esercizio durante la seduta.

| Test | Come previsto? | Note |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |
| 8 | | |
| 9 | | |
| 10 | | |
| 11 | | |
| 12 | | |
| 13 | | |
