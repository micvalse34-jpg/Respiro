# Test sul Pixel 7a — versione app Android

Ogni test dice **cosa fare**, **cosa deve succedere** e **cosa annotare**. Se succede qualcosa di diverso, annotalo così com'è: è un'informazione utile, non un errore tuo.

**Prima di iniziare:** app installata seguendo `GUIDA_SEMPLICE.md`. I test con ⚠️ cancellano dati: falli per ultimi e prima salva un backup.

**Come mi mandi i risultati:** quasi tutti i test si fanno dalla scheda **Diagnostica** dell'app. Ogni pulsante produce un testo: tocca **Condividi** e mandalo a te stesso (email o Drive), poi incollalo qui in chat. In più, compila la tabella in fondo.

## Test 1 — Dati del telefono
**Fai:** Diagnostica → *Report completo* → Condividi.
**Deve succedere:** nel testo compaiono modello, versione Android (`osVersion`) e versione del motore web (`webViewVersion`).
**Annota:** niente, basta il testo.

## Test 2 — Le serie salvate non si perdono (il più importante, circa 20 minuti)
**Fai:**
1. Diagnostica → *Azzera giornale di prova*.
2. Scheda Seduta → *Inizia seduta di prova*.
3. Ripeti 20 volte: tocca *Registra serie*; **appena** compare la scritta verde «Salvato sul dispositivo», chiudi l'app di colpo:
   - le volte dispari: apri le app recenti (scorri dal basso e tieni premuto) e trascina via FitPRO;
   - le volte pari: *Impostazioni → App → FitPRO → Forza interruzione*.
   Riapri FitPRO e scegli **Riprendi**.
4. In 2 di questi 20 giri chiudi invece **mentre** c'è scritto «Salvataggio in corso…».
5. Diagnostica → *Giornale serie confermate* → Condividi.

**Deve succedere:** nel testo, `lost` è vuoto (`[]`). Nessuna serie compare due volte. Le 2 serie chiuse durante il salvataggio possono mancare: è corretto, non erano state confermate.

## Test 3 — Velocità di salvataggio
**Fai:** Diagnostica → *Latenza commit strict/relaxed*, 3 volte, condividi ogni risultato.
**Deve succedere:** il valore `strict.p95Ms` è al massimo 100 (millisecondi).

## Test 4 — Riprendere una seduta
**Fai:**
1. Seduta aperta con almeno 3 serie. Chiudi l'app dalle recenti e riaprila: compare «Seduta non conclusa». Scegli **Riprendi**.
2. **Spegni e riaccendi il telefono**, riapri l'app, scegli **Riprendi**.
3. Su un'altra seduta scegli invece **Chiudi come parziale**.

**Deve succedere:** l'app propone l'esercizio, la serie e il lato giusti (il primo non ancora registrato), entro un paio di secondi. Con «Chiudi come parziale» le serie registrate restano.

## Test 5 — Cambio di versione dei dati
**Fai:** Diagnostica → *Autotest migrazione* → Condividi.
**Deve succedere:** `"pass": true`.

## Test 6 — Aggiornare l'app durante una seduta
**Fai:**
1. Apri una seduta e registra 2 serie. Lascia la seduta aperta.
2. Scrivimi «pronto per il test 6»: ti preparo una nuova versione. Caricala, scarica il nuovo APK e installalo **sopra** quello esistente (Guida, «Aggiornamenti futuri»).
3. Riapri l'app.

**Deve succedere:** compare «Seduta non conclusa». Con **Riprendi** ritrovi le 2 serie e puoi registrarne altre. Nel Report completo, `app.build` mostra il nuovo numero.

## Test 7 — Senza internet
**Fai:** attiva la modalità aereo, chiudi e riapri l'app, fai una seduta breve e chiudila.
**Deve succedere:** tutto funziona normalmente.

## Test 8 — Backup e ripristino
**Fai:**
1. Scheda Backup → *Salva backup* → scegli **Drive** e salva.
2. Torna all'app: in alto la data dell'ultimo backup deve essere aggiornata.
3. Scheda Backup → *Ripristina* → scegli il file appena salvato da Drive. Prima **senza** spuntare «Sostituisci i dati attuali»: il pulsante deve restare grigio. Poi spunta e ripristina.
4. File rovinato: al PC apri il file di backup con il Blocco note, cancella le ultime righe, salva, rimettilo su Drive e prova a ripristinarlo.

**Deve succedere:** al punto 3 il ripristino riesce; al punto 4 compare «File rifiutato, nessuna modifica ai dati» e i dati restano quelli di prima.

## Test 9 — Velocità con 5 anni di dati
**Fai:** Diagnostica → *Prestazioni 5 anni*, 2 volte, condividi. Ci vogliono alcuni secondi.
**Deve succedere:** `historyQueryP95Ms` al massimo 300 e `reopenMs` al massimo 3000.

## Test 10 — Il motivo per cui siamo passati all'app ⚠️
Prima di ogni punto: *Salva backup* e Diagnostica → *Report completo* → Condividi. Dopo ogni punto: riapri FitPRO → *Report completo* → Condividi.

| Punto | Cosa fai | Cosa ci aspettiamo |
| --- | --- | --- |
| a | In **Chrome**: ⋮ → *Elimina dati di navigazione* → spunta «Cookie e dati dei siti», periodo «Sempre» → elimina | **I dati di FitPRO restano.** È il test decisivo |
| b | *Impostazioni → App → FitPRO → Spazio di archiviazione → Svuota cache* | I dati restano |
| c | Installa di nuovo lo stesso APK sopra quello esistente | I dati restano |
| d | *Impostazioni → App → FitPRO → Spazio di archiviazione → Cancella spazio di archiviazione* | I dati si cancellano (previsto): ripristina dal backup e verifica che tornino |

## Tabella da compilare

| Test | Data | Risultato come previsto? (sì/no) | Note: cosa hai visto |
| --- | --- | --- | --- |
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |
| 6 | | | |
| 7 | | | |
| 8 | | | |
| 9 | | | |
| 10a | | | |
| 10b | | | |
| 10c | | | |
| 10d | | | |

Corrispondenza con il report tecnico: 2 = POC-03, 3 = POC-04, 4 = POC-05, 5 = POC-06, 6 = POC-07, 7 = POC-11, 8 = POC-13, 9 = POC-14, 10 = POC-15.
