# Test sul Pixel 7a — rematore con elastico (versione 0.3)

Servono la porta con l'ancoraggio e gli elastici a tubo etichettati. Per il test 1 vai su Profilo → Strumenti → Diagnostica, tocca *Report completo*, poi **Condividi** e incollami il testo.

**Prima:** backup su Drive dalla versione attuale.

| N. | Cosa fai | Cosa deve succedere |
| --- | --- | --- |
| 1 | Installi la 0.3 sopra la 0.2 e fai *Report completo* | `schemaVersion: 4`, `app.version: 0.3.0`, `installId` uguale a prima, profilo e attrezzatura presenti |
| 2 | Allenamento: senza spuntare il controllo di sicurezza | Il pulsante Inizia non compare |
| 3 | Seduta 1 con l'elastico che usi davvero: 3 serie vere, valori reali | A fine seduta: «Valutazione» con il motivo; la seduta è nello Storico con elastici, ancoraggio e distanza |
| 4 | Durante una serie chiudi l'app dalle recenti appena compare «Salvato», riapri, **Riprendi** | Ritrovi la seduta al punto giusto |
| 5 | In una serie spunta «Ho sentito fastidio o dolore» | Messaggio prudente; a fine seduta «Nessun aumento oggi» |
| 6 | In una serie tocca **Cambia** e modifica la distanza | Le serie seguenti riportano la nuova distanza nello Storico; a fine seduta nessuna proposta (seduta non confrontabile) |
| 7 | Backup su Drive, poi ripristino dello stesso file | Sedute, proposte e decisioni identiche |
| 8 | Modalità aereo: una seduta completa | Tutto funziona |

La proposta vera arriverà solo dopo due sedute all'obiettivo con la stessa configurazione: non forzarla con valori finti. Se ci arrivi durante le prove, descrivimi cosa ti propone e cosa scegli.

Mandami la tabella con sì/no e le note, il report del test 1 e un giudizio sincero: tempi di registrazione di una serie (obiettivo: meno di 10 secondi), leggibilità con il telefono appoggiato, testi poco chiari.

| Test | Come previsto? | Note |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |
| 8 | | |

## Dopo l'aggiornamento 0.3.1 (pulizia dei dati casuali)

1. Storico → apri ogni seduta libera inserita a caso → **Segna come seduta di prova** → Sì.
2. In fondo allo Storico → **Elimina le sedute di prova** → Sì, elimina.
3. Allenamento: alla prima seduta vera il controllo di elastici e ancoraggio va spuntato; nelle sedute successive della settimana no.

## Dopo l'aggiornamento 0.3.2

| N. | Cosa fai | Cosa deve succedere |
| --- | --- | --- |
| B1 | Storico → apri una seduta → tasto indietro | Torni all'elenco, l'app resta aperta |
| B2 | Profilo → Attrezzatura → apri un elastico → indietro, poi ancora indietro | Prima torni all'elenco dell'attrezzatura, poi alla Home |
| B3 | Dalla Home → indietro | L'app va in secondo piano; riaprendola ritrovi la Home |
| B4 | Storico → «Seleziona sedute inserite per prova» → spunta le 4 sedute → «Segna come prova (4)» → in fondo «Elimina le sedute di prova» | Storico vuoto |
