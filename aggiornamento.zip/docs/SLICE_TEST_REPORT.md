# Vertical slice Band Row — Test report

**Data:** 23/11/2026 · **App:** 0.3.0 · **Schema dati:** 4 · **Formato backup:** 3 (legge 1 e 2) · **Regola di progressione:** band-row-1
**Ambienti:** Node 22.23 + Vitest 2.1.9 + fake-indexeddb; Chromium 1243 headless 412×915 con IndexedDB reale. **Pixel 7a:** protocollo eseguito con la build b7 (0.3.0); correzioni in 0.3.1.

## Esito

82/82 test automatici superati (62 precedenti + 20 nuovi). In Chromium: migrazione reale dalla build F1 consegnata (schema 3 → 4) con kit e ordinamento esistenti; due sedute 3 × 15 RIR 2 → proposta +10 cm; rifiuto «non ho spazio» → proposta E1 → E2 a 80 cm; accettazione → configurazione precompilata alla seduta successiva; Storico con proposte e decisioni; nessun errore JavaScript.

## Copertura

| Area | Test | Stato |
| --- | --- | --- |
| D079 comparabilità A/B/C/D, cambio configurazione a metà seduta | 2 puri + 1 su DB | PASSED |
| D080 regola di proposta: una sola seduta, classe B, RIR mancante, 14 ripetizioni, RIR 1, tecnica scarsa, serie interrotta | 5 | PASSED |
| D081 ordine dei passi, rifiuti per spazio e per salto, combinazione solo oltre E5, ordine dei tubi mancante | 3 | PASSED |
| D082 fastidio: blocco della proposta, segnalazione dopo 2 sedute su 3 | 2 | PASSED |
| Rifiuto di elastico danneggiato e configurazione incompleta | 1 | PASSED |
| Contenuti: versione 2 in bozza, versione 1 invariata | 1 | PASSED |
| Migrazione v3→v4 con seduta aperta; backup formato 3 identico; import formato 2; formato 2 con schema 4 rifiutato | 4 | PASSED |
| Flusso completo su DB con proposta, alternativa, accettazione, idempotenza | 1 | PASSED |

## Scostamento da approvare (D081-bis)

Con i tubi dell'utente le combinazioni hanno gli stessi valori nominali del tubo successivo (E1 + E2 = 13,7 kg nominali = E3). Una combinazione non è quindi un passo più piccolo: l'app propone la combinazione solo oltre E5. Se l'utente rifiuta il cambio elastico perché il salto è troppo grande, non propone alternative e ripropone il cambio alla conferma successiva.

## Limiti

- Soglie PROVISIONAL (D039): 3 × 15, RIR ≥ 2, 2 sedute, ±10 cm, passo +10 cm.
- Contenuti tecnici in bozza (D011 aperta); messaggi su fastidio da revisione professionale (D042).
- Nessuna regressione automatica, nessuna variante più difficile: fuori perimetro.
- Interfaccia verificata solo in Chromium desktop, non nella WebView del Pixel.

## Risultati sul Pixel 7a (0.3.0, build b7, 23/11/2026)

Report del test 1: `schemaVersion: 4`, `installId` invariato dal POC, giornale 31/31, backup alle 20:56. Test 2–8 dichiarati come previsto. **Valori inseriti a caso** (nessun allenamento reale): verificato il funzionamento, non la regola di progressione su dati veri. Usabilità giudicata buona dall'utente.

## Versione 0.3.1 — correzioni dopo il riscontro

| ID | Modifica | Verifica |
| --- | --- | --- |
| D085 | «Segna come seduta di prova» nel dettaglio di una seduta libera: esce dalla progressione, le sue proposte non restano in attesa, eliminabile con i dati di prova | Test automatico + Chromium (aggiornamento 0.3.0 → 0.3.1 con 2 sedute e proposta in attesa) |
| D086 | Controllo di elastici e ancoraggio da spuntare solo alla prima seduta, dopo 7 giorni o con un elastico mai usato | Test automatico + Chromium |
| D087 | Esito in una riga («Proposta: allontanati di 10 cm»), spiegazione sotto «Perché» | Chromium |

84/84 test automatici superati; nessun errore JavaScript nella prova end-to-end.

## Versione 0.3.2 — riscontri dell'utente

| ID | Problema / richiesta | Correzione | Verifica |
| --- | --- | --- | --- |
| DEF-06 | Il tasto «indietro» di Android chiudeva l'app | Indietro chiude la vista interna aperta (dettaglio, modulo, conferma), poi torna alla Home; dalla Home l'app va in secondo piano. La scelta «Seduta non conclusa» non si salta. Plugin `@capacitor/app` 8.1.2 | Test automatici della logica; **verifica sul Pixel necessaria** (il tasto fisico non è simulabile in Chromium) |
| D085 | Pulizia di più sedute una alla volta poco pratica | Storico → «Seleziona sedute inserite per prova» → spunta → «Segna come prova (N)», tutto o niente | Test automatico |

87/87 test automatici superati.

## Versione 0.3.3 — caricamento incompleto scoperto sul telefono

| ID | Problema | Causa radice | Correzione | Verifica di efficacia |
| --- | --- | --- | --- | --- |
| DEF-07 | Sul telefono l'app indicava 0.3.2 ma mostrava il comportamento della 0.3.0 | Una parte dei file era stata caricata su GitHub nella cartella principale invece che in `src/app`, `docs`, `tests`; `package.json` (con il numero di versione) era invece nel posto giusto. La costruzione non se ne accorgeva: i file fuori posto vengono ignorati e i test vecchi passavano | Controllo automatico prima dei test: impronta di ogni file del programma in `tests/files-manifest.json`; se un file manca o è vecchio, nessun APK. Zip consegnati senza cartella esterna; guida con divieto di «choose your files» | Prova locale: albero corretto → verde; file spostato nella cartella principale → rosso con elenco dei file |
| DEF-08 | «Ultimo backup … (oggi)» la mattina dopo | Calcolo per blocchi di 24 ore | Giorni di calendario: «oggi», «ieri», «N giorni fa» | Test automatico |
| — | Versione installata non visibile senza report | — | Versione e build in fondo a Profilo | — |

88/88 test automatici superati.

**Ricorrenza (24/11):** il ricaricamento della 0.3.3 trascinando le cartelle intere ha di nuovo messo i file nella cartella principale, e la verifica non è partita perché anche il file della costruzione automatica era finito fuori posto. Azione correttiva rafforzata: consegna in cartelle numerate, una per cartella di destinazione su GitHub, con file sciolti da caricare **dentro** la cartella già aperta su GitHub. Il caricamento non dipende più dal trascinamento di cartelle. Verificatore spostato in `tests/` (cartella già esistente); documentazione esclusa dalla verifica perché non influisce sull'app.
