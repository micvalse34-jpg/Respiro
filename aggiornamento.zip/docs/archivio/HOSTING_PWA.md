> **Archiviato il 23/11/2026:** non serve per l'app Android (Capacitor). Resta valido solo se si tornasse alla versione browser (PWA).

# Configurazione repository, hosting e distribuzione

**Raccomandazione:** repository **GitHub privato** + **Cloudflare Pages** collegato al repository + **Cloudflare Access** per limitare l'URL al tuo indirizzo email.

Le condizioni dei piani gratuiti indicate sotto sono quelle a me note: vanno verificate al momento dell'attivazione.

## 1. Cosa resta riservato e cosa no

| Elemento | Dove sta | Chi può vederlo |
| --- | --- | --- |
| Codice sorgente | Repository GitHub privato | Solo tu (e i servizi che autorizzi, es. Cloudflare in lettura per la build) |
| App compilata (HTML/JS/CSS) | Cloudflare Pages | Chiunque abbia l'URL, **salvo** protezione con Cloudflare Access |
| Dati di allenamento | IndexedDB del Pixel 7a | Solo il dispositivo. Nessun backend, nessuna API |
| File di backup | Dove scegli tu al momento dell'esportazione (es. Drive) | Secondo le regole della destinazione scelta |

Un'app web compilata è leggibile da chi la scarica: la riservatezza del codice si ottiene limitando chi può scaricarla (Access), non nascondendolo.

**Garanzie sui dati:** l'app non effettua richieste di rete verso terzi; la CSP in `public/_headers` limita le connessioni allo stesso dominio (`connect-src 'self'`), che serve solo file statici. Cloudflare registra le normali richieste HTTP (IP, percorso), non i dati di allenamento, che non lasciano il dispositivo.

## 2. Passi

1. **GitHub:** crea un repository privato `fitpro`, poi dalla cartella del progetto:
   ```bash
   git remote add origin git@github.com:<utente>/fitpro.git
   git push -u origin main
   ```
2. **Cloudflare Pages:** *Workers & Pages → Create → Pages → Connect to Git*, autorizza solo il repository `fitpro`.
   - Build command: `npm ci && npm run build`
   - Output directory: `dist`
   - Variabile d'ambiente: `NODE_VERSION = 22`
   - L'etichetta di build (`BUILD_LABEL`) è presa automaticamente dal commit (`CF_PAGES_COMMIT_SHA`): serve al test di aggiornamento POC-07.
3. **Cloudflare Access (consigliato):** *Zero Trust → Access → Applications → Self-hosted*, dominio `*.pages.dev` del progetto, policy *Allow* con il tuo indirizzo email (codice monouso via email).
4. **Verifica:** apri l'URL dal Pixel 7a con Chrome, autenticati, installa l'app (menu ⋮ → *Installa app*).

## 3. Interazioni da verificare durante il POC

| Punto | Rischio | Mitigazione già presente | Verifica |
| --- | --- | --- | --- |
| Manifest dietro Access | Installazione impossibile se il manifest è richiesto senza credenziali | `crossorigin="use-credentials"` sul manifest | Protocollo §2 |
| Sessione Access scaduta | Gli aggiornamenti non vengono scaricati | L'app installata continua a funzionare offline dalla cache | Protocollo POC-07 |
| Anteprime di branch | Ogni branch genera un URL pubblico | Proteggere con Access anche `*.<progetto>.pages.dev` o disattivare le preview | Configurazione |

## 4. Alternative scartate

| Alternativa | Motivo |
| --- | --- |
| GitHub Pages | Con il piano gratuito richiede repository pubblico; il sito è comunque pubblico |
| Netlify | Repository privato supportato, ma la protezione con password è a pagamento |
| Server locale | Una PWA si installa solo da HTTPS: richiede certificati e un server sempre raggiungibile |
