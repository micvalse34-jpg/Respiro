import { useCallback, useEffect, useRef, useState } from 'react';
import { popBack, useBack } from './back';
import { minimizeApp, onAndroidBack } from '../platform';
import { useRegisterSW } from 'virtual:pwa-register/react';
import { closeSession, getOpenSessions, seedKnowledge, fillDeclaredTubeLength } from '../data/repository';
import { backupAgeDays, getMeta, isPopulated, needsBackupReminder, setMeta } from '../data/backup';
import { journalRead } from '../data/journal';
import { nowIso, uuidv7 } from '../domain/ids';
import type { WorkoutSession } from '../domain/types';
import { db } from './db';
import { fmtDateTime } from './format';
import { HomeScreen } from './HomeScreen';
import { HistoryScreen } from './HistoryScreen';
import { LibraryScreen } from './LibraryScreen';
import { AssessmentScreen } from './AssessmentScreen';
import { BalanceScreen } from './BalanceScreen';
import { ProfileArea, type ProfileTab } from './ProfileArea';
import { WorkoutScreen } from './WorkoutScreen';

export type Screen = 'home' | 'allenamento' | 'libreria' | 'storico' | 'profilo' | 'valutazione' | 'equilibrio';
export interface Nav { go: (screen: Screen, tab?: ProfileTab) => void; train: (exerciseId: string) => void }

interface Boot { ready: boolean; error: string | null; reopened: WorkoutSession[]; lossSuspect: number | null }

export function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [profileTab, setProfileTab] = useState<ProfileTab>('dati');
  const [boot, setBoot] = useState<Boot>({ ready: false, error: null, reopened: [], lossSuspect: null });
  const [lastExportAt, setLastExportAt] = useState<string | null>(null);
  const [hasData, setHasData] = useState(false);
  const [hasOpenSession, setHasOpenSession] = useState(false);
  const [trainExercise, setTrainExercise] = useState<string | null>(null); // esercizio scelto dalla Libreria
  const [version, setVersion] = useState(0); // incrementato a ogni modifica dei dati: le schermate si ricaricano
  const { needRefresh: [needRefresh], updateServiceWorker } = useRegisterSW();
  const screenRef = useRef<Screen>('home');
  screenRef.current = screen;

  // Tasto indietro: vista interna → Home → app in secondo piano (mai chiusura).
  useEffect(() => {
    let off: (() => void) | null = null;
    onAndroidBack(() => {
      if (popBack()) return;
      if (screenRef.current !== 'home') { setScreen('home'); window.scrollTo(0, 0); return; }
      void minimizeApp();
    }).then((f) => { off = f; });
    return () => { off?.(); };
  }, []);

  const refresh = useCallback(async () => {
    setLastExportAt(await getMeta<string>(db, 'lastExportAt'));
    setHasData(await isPopulated(db));
    setHasOpenSession((await getOpenSessions(db)).length > 0);
    setVersion((v) => v + 1);
  }, []);

  useEffect(() => {
    (async () => {
      try {
        await db.open();
        const installId = await getMeta<string>(db, 'installId');
        let lossSuspect: number | null = null;
        if (!installId) {
          // Database nuovo: se il giornale riporta serie confermate, lo storage è stato probabilmente cancellato.
          const j = journalRead().length;
          if (j > 0) lossSuspect = j;
          await setMeta(db, 'installId', uuidv7());
          await setMeta(db, 'installCreatedAt', nowIso());
        }
        await seedKnowledge(db);
        await fillDeclaredTubeLength(db); // dato dichiarato dall'utente, una volta sola
        const open = await getOpenSessions(db);
        setBoot({ ready: true, error: null, reopened: open, lossSuspect });
        await refresh();
      } catch (e) {
        setBoot({ ready: false, error: (e as Error).message, reopened: [], lossSuspect: null });
      }
    })();
  }, [refresh]);

  const nav: Nav = {
    go: (s, tab) => { setScreen(s); if (tab) setProfileTab(tab); window.scrollTo(0, 0); },
    train: (id) => { setTrainExercise(id); setScreen('allenamento'); window.scrollTo(0, 0); },
  };

  if (boot.error) return <main className="shell"><p className="alert alert-error">Il database non si apre: {boot.error}. I dati non sono stati modificati. Chiudi l'app e riaprila; se il problema resta, mandami questo messaggio.</p></main>;
  if (!boot.ready) return <main className="shell"><p className="muted">Apertura dei dati…</p></main>;

  const reminder = needsBackupReminder(lastExportAt, hasData);
  const age = backupAgeDays(lastExportAt);

  return (
    <>
      <main className="shell">
        <header className="top">
          <h1>FitPRO</h1>
          <button className={reminder ? 'backup-age warn' : 'backup-age'} onClick={() => nav.go('profilo', 'backup')}>
            Ultimo backup: {fmtDateTime(lastExportAt)}{age !== null ? ` (${age === 0 ? 'oggi' : age === 1 ? 'ieri' : `${age} giorni fa`})` : ''}
          </button>
        </header>

        {boot.lossSuspect !== null && (
          <p className="alert alert-error">Il database risulta nuovo ma il giornale di prova riporta {boot.lossSuspect} serie confermate: probabile cancellazione dei dati. Ripristina l'ultimo backup da Profilo → Backup.</p>
        )}
        {needRefresh && (hasOpenSession
          ? <p className="alert">Aggiornamento dell'app pronto: verrà proposto a seduta chiusa.</p>
          : <p className="alert">Aggiornamento dell'app disponibile. <button className="link" onClick={() => updateServiceWorker(true)}>Aggiorna</button></p>)}
        {boot.reopened.length > 0 && (
          <ReopenDialog session={boot.reopened[0]!} onDone={async () => { setBoot({ ...boot, reopened: [] }); await refresh(); }}
            onResume={() => { const free = boot.reopened[0]!.sessionType === 'FREE'; setBoot({ ...boot, reopened: [] }); if (free) nav.go('allenamento'); else nav.go('profilo', 'strumenti'); }} />
        )}

        {screen === 'home' && <HomeScreen key={version} nav={nav} reminder={reminder} hasOpenSession={hasOpenSession} />}
        {screen === 'allenamento' && <WorkoutScreen version={version} onChange={refresh} onTools={() => nav.go('profilo', 'strumenti')} initialExercise={trainExercise} onInitialUsed={() => setTrainExercise(null)} />}
        {screen === 'libreria' && <LibraryScreen version={version} hasOpenSession={hasOpenSession} onTrain={nav.train} onChange={refresh} />}
        {screen === 'storico' && <HistoryScreen version={version} onChange={refresh} />}
        {screen === 'valutazione' && <AssessmentScreen version={version} onChange={refresh} onBalance={() => nav.go('equilibrio')} />}
        {screen === 'equilibrio' && <BalanceScreen version={version} onAssessment={() => nav.go('valutazione')} />}
        {screen === 'profilo' && <ProfileArea tab={profileTab} onTab={setProfileTab} onChange={refresh} hasOpenSession={hasOpenSession} version={version} />}
      </main>

      <nav className="bottom-nav" aria-label="Sezioni principali">
        {([['home', 'Home'], ['allenamento', 'Allenati'], ['libreria', 'Libreria'], ['storico', 'Storico'], ['profilo', 'Profilo']] as [Screen, string][]).map(([s, label]) => (
          <button key={s} aria-current={screen === s ? 'page' : undefined} onClick={() => nav.go(s)}>{label}</button>
        ))}
      </nav>
    </>
  );
}

function ReopenDialog({ session, onDone, onResume }: { session: WorkoutSession; onDone: () => void; onResume: () => void }) {
  const [busy, setBusy] = useState(false);
  useBack(true, () => undefined); // la scelta Riprendi/Chiudi è obbligatoria: «indietro» non la salta

  return (
    <section className="dialog" role="dialog" aria-labelledby="reopen-title">
      <h2 id="reopen-title">Seduta non conclusa</h2>
      <p>Iniziata il {fmtDateTime(session.startedAt)}. Le serie già registrate restano salvate in entrambi i casi.</p>
      <div className="row">
        <button className="primary" disabled={busy} onClick={onResume}>Riprendi</button>
        <button disabled={busy} onClick={async () => { setBusy(true); await closeSession(db, session.id, 'CLOSED_ON_REOPEN'); onDone(); }}>Chiudi come parziale</button>
      </div>
    </section>
  );
}
