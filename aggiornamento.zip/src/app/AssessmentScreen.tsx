// Valutazione iniziale in 3 fasi contate in sedute (D097 rivista, D108): piano delle prove, controllo minimo (D096), esecuzione delle prove.
import { useEffect, useRef, useState } from 'react';
import { assessmentProgress, bandForStep, deleteAssessmentTrials, GATE_QUESTIONS, lastReference, recordGate, recordLadderAttempt, recordRatioH, recordThreshold, startLevel, type ProbeStatus } from '../data/assessmentRepo';
import { orderedBands } from '../data/freeSessionRepo';
import { currentVersion } from '../data/knowledge';
import { catalogEntry } from '../data/libraryCatalog';
import { CLASS_NAMES, domainDef, ladder, PROBES_PER_VISIT, REFERENCE_OFFSET_CM, threshold, type DomainId, type Ladder, type MobilityClass, type Probe } from '../domain/domains';
import type { DomainTrial, EquipmentItem, Side } from '../domain/types';
import { db } from './db';
import { useBack } from './back';
import { ExerciseCard } from './ExerciseCard';
import { fmtDateTime } from './format';

type Gate = { runId: string; allowed: boolean } | null;
const SIDE_NAME: Record<Side, string> = { LEFT: 'Lato sinistro', RIGHT: 'Lato destro', BILATERAL: '' };
const TECH: [DomainTrial['technique'], string][] = [['GOOD', 'Buona'], ['ACCEPTABLE', 'Accettabile'], ['POOR', 'Scarsa']];
const RIR_OPTIONS: [number | null, string][] = [[0, '0'], [1, '1'], [2, '2'], [3, '3'], [4, '4'], [5, '5+'], [null, 'Non so']];

export function AssessmentScreen({ version, onChange, onBalance }: { version: number; onChange: () => Promise<void>; onBalance: () => void }) {
  const [progress, setProgress] = useState<ProbeStatus[] | null>(null);
  const [gate, setGate] = useState<Gate>(null);
  const [active, setActive] = useState<Probe | null>(null);
  const [pending, setPending] = useState<Probe | null>(null); // prova scelta in attesa del controllo minimo
  const [doneThisVisit, setDoneThisVisit] = useState<string[]>([]); // prove completate da quando hai aperto l'app (D108)
  const [confirmDelete, setConfirmDelete] = useState(false);
  const load = async () => setProgress(await assessmentProgress(db));
  useEffect(() => { load(); }, [version]);
  useBack(active !== null || pending !== null, () => { setActive(null); setPending(null); });
  if (!progress) return null;

  const start = (p: Probe) => { if (gate?.allowed) setActive(p); else setPending(p); };
  if (pending && !gate) return <GateView onDone={(g) => { setGate(g); if (g.allowed) { setActive(pending); } setPending(null); }} onCancel={() => setPending(null)} />;
  if (active && gate?.allowed) return <ProbeRunner probe={active} runId={gate.runId} onDone={async () => { setDoneThisVisit((d) => (d.includes(active.id) ? d : [...d, active.id])); setActive(null); await load(); await onChange(); }} />;

  const done = progress.filter((p) => p.done).length;
  const phaseDone = (f: number) => progress.filter((p) => p.probe.phase === f).every((p) => p.done);
  const currentPhase = ([1, 2, 3] as const).find((f) => !phaseDone(f)) ?? null;
  const unlocked = (f: number) => f === 1 || phaseDone(f - 1);
  const enough = doneThisVisit.length >= PROBES_PER_VISIT;
  return (
    <section className="screen">
      <h2 className="screen-title">Valutazione iniziale</h2>
      <p className="small muted">{done} prove su {progress.length}. Al massimo {PROBES_PER_VISIT} prove per volta, meglio all'inizio di una seduta e da riposato. La fase successiva si apre quando hai finito quella prima: il ritmo lo decidi tu.</p>
      {gate && !gate.allowed && <p className="alert small">Oggi niente prove: riprova un altro giorno. Puoi comunque allenarti normalmente.</p>}
      {enough && <p className="alert small">Per oggi bastano {PROBES_PER_VISIT} prove: le prossime alla prossima seduta.</p>}
      {done > 0 && <button onClick={onBalance}>Vedi il profilo «Equilibrio»</button>}
      {([1, 2, 3] as const).map((f) => (
        <div key={f} className={`card${f === currentPhase ? ' card-accent' : ''}`}>
          <h3>Fase {f}{f === currentPhase ? ' · adesso' : !unlocked(f) ? ' · si apre dopo la fase ' + (f - 1) : ''}</h3>
          <ul className="list">
            {progress.filter((p) => p.probe.phase === f).map((p) => (
              <li key={p.probe.id}>
                <button className="list-item" disabled={(!!gate && !gate.allowed) || !unlocked(f) || (enough && !doneThisVisit.includes(p.probe.id))} onClick={() => start(p.probe)}>
                  <span className="li-head"><strong>{p.probe.name}</strong>{p.done ? <span className="chip chip-status-tested">Fatta</span> : <span className="chip">Da fare</span>}</span>
                  <span className="li-sub">{p.done ? `Ultima volta ${fmtDateTime(p.lastAt)} · tocca per ripeterla` : probeHint(p.probe)}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      ))}
      {done > 0 && (
        <div className="card">
          <h3>Prove fatte per provare l'app</h3>
          {!confirmDelete ? (
            <><p className="small">Se finora hai solo simulato, elimina tutte le prove prima di iniziare la valutazione vera: altrimenti entrano nel profilo «Equilibrio».</p>
              <button onClick={() => setConfirmDelete(true)}>Elimina tutte le prove di valutazione</button></>
          ) : (
            <><p className="small">Verranno eliminate tutte le {progress.length ? 'prove registrate' : 'prove'}: il profilo «Equilibrio» tornerà vuoto. Le sedute di allenamento non vengono toccate.</p>
              <div className="row">
                <button className="danger" onClick={async () => { await deleteAssessmentTrials(db); setConfirmDelete(false); setDoneThisVisit([]); await load(); await onChange(); }}>Sì, elimina</button>
                <button onClick={() => setConfirmDelete(false)}>Annulla</button>
              </div></>
          )}
        </div>
      )}
    </section>
  );
}

function probeHint(p: Probe): string {
  if (p.kind === 'THRESHOLD') return domainDef(p.ref as DomainId).perSide ? 'Misura per lato' : 'Una misura';
  if (p.kind === 'RATIO_H') return 'Rematore e spinta al petto, stesso elastico e stessa distanza';
  const l = ladder(p.ref);
  return `Scala di 5 livelli${l.perSide ? ', per lato' : ''}`;
}

function GateView({ onDone, onCancel }: { onDone: (g: { runId: string; allowed: boolean }) => void; onCancel: () => void }) {
  const [answers, setAnswers] = useState<(boolean | null)[]>(GATE_QUESTIONS.map(() => null));
  const ready = answers.every((a) => a !== null);
  return (
    <section className="screen">
      <h2 className="screen-title">Prima delle prove</h2>
      <div className="card">
        {GATE_QUESTIONS.map((q, i) => (
          <div key={q} className="gate-q">
            <p>{q}</p>
            <div className="chips">
              {[false, true].map((v) => <button key={String(v)} className="pick" aria-pressed={answers[i] === v} onClick={() => setAnswers(answers.map((a, j) => (j === i ? v : a)))}>{v ? 'Sì' : 'No'}</button>)}
            </div>
          </div>
        ))}
        <div className="row">
          <button className="primary" disabled={!ready} onClick={async () => onDone(await recordGate(db, answers as boolean[]))}>Continua</button>
          <button onClick={onCancel}>Annulla</button>
        </div>
      </div>
    </section>
  );
}

function ProbeRunner({ probe, runId, onDone }: { probe: Probe; runId: string; onDone: () => Promise<void> }) {
  return (
    <section className="screen">
      <button className="back" onClick={() => void onDone()}>‹ Valutazione</button>
      <h2 className="screen-title">{probe.name}</h2>
      {probe.kind === 'THRESHOLD' && <ThresholdRunner probe={probe} runId={runId} onDone={onDone} />}
      {probe.kind === 'LADDER' && <LadderRunner probe={probe} runId={runId} onDone={onDone} />}
      {probe.kind === 'RATIO_H' && <RatioRunner probe={probe} runId={runId} onDone={onDone} />}
    </section>
  );
}

function ExerciseHint({ exerciseId }: { exerciseId: string }) {
  const v = currentVersion(exerciseId); const c = catalogEntry(exerciseId);
  if (!v?.content || !c) return null;
  return <details className="small"><summary>Come si fa: {c.displayName}</summary><ExerciseCard version={v} meta={c.meta} mode="compact" status="DRAFT" /></details>;
}

/** Cronometro semplice: allo stop riporta i secondi interi. */
function Stopwatch({ onStop, max }: { onStop: (s: number) => void; max?: number }) {
  const [start, setStart] = useState<number | null>(null);
  const [now, setNow] = useState(0);
  const timer = useRef<number | null>(null);
  useEffect(() => () => { if (timer.current) window.clearInterval(timer.current); }, []);
  const elapsed = start ? Math.floor((now - start) / 1000) : 0;
  useEffect(() => { if (start && max && elapsed >= max) stop(); }, [elapsed]);
  function stop() { if (timer.current) window.clearInterval(timer.current); timer.current = null; setStart(null); onStop(max ? Math.min(elapsed, max) : elapsed); }
  if (start === null) return <button onClick={() => { const t = Date.now(); setStart(t); setNow(t); timer.current = window.setInterval(() => setNow(Date.now()), 250); }}>Avvia cronometro</button>;
  return <button className="primary stopwatch" onClick={stop}>Ferma · {elapsed} s</button>;
}

function Num({ label, value, onChange, step = 1 }: { label: string; value: number; onChange: (v: number) => void; step?: number }) {
  return (
    <div className="stepper">
      <button aria-label={`${label}: meno`} onClick={() => onChange(Math.max(0, value - step))}>−</button>
      <label>{label}<input inputMode="numeric" value={value} onChange={(e) => onChange(Number(e.target.value.replace(/\D/g, '')) || 0)} /></label>
      <button aria-label={`${label}: più`} onClick={() => onChange(value + step)}>+</button>
    </div>
  );
}

function ThresholdRunner({ probe, runId, onDone }: { probe: Probe; runId: string; onDone: () => Promise<void> }) {
  const d = domainDef(probe.ref as DomainId);
  const th = threshold(d.id);
  const sides: Side[] = d.perSide ? ['LEFT', 'RIGHT'] : ['BILATERAL'];
  const [i, setI] = useState(0);
  const [value, setValue] = useState(th.input.kind === 'NUMBER' && th.input.unit === 'cm' ? 8 : 0);
  const [choice, setChoice] = useState<MobilityClass | null>(null);
  const [discomfort, setDiscomfort] = useState(false);
  const [results, setResults] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const side = sides[i];
  const save = async () => {
    setError(null);
    try {
      const t = await recordThreshold(db, { runId, probeId: probe.id, domainId: d.id, side: side!, value: th.input.kind === 'NUMBER' ? value : null, choice, discomfort });
      setResults([...results, `${SIDE_NAME[side!] || 'Risultato'}: ${CLASS_NAMES[t.mobilityClass!]}${t.valueCm !== null ? ` (${t.valueCm} cm)` : t.seconds !== null ? ` (${t.seconds} s)` : ''}`]);
      setI(i + 1); setChoice(null); setDiscomfort(false);
    } catch (e) { setError((e as Error).message); }
  };
  return (
    <>
      <ExerciseHint exerciseId={th.exerciseId} />
      <div className="card"><p>{th.instruction}</p></div>
      {side ? (
        <div className="card card-accent">
          {side !== 'BILATERAL' && <h3>{SIDE_NAME[side]}</h3>}
          {th.input.kind === 'NUMBER' ? (
            <>
              <Num label={th.input.unit === 'cm' ? 'Centimetri' : 'Secondi'} value={value} onChange={setValue} />
              {th.input.unit === 's' && <Stopwatch max={th.input.max} onStop={setValue} />}
            </>
          ) : (
            <div className="chips column">{(Object.entries(th.input.options) as [MobilityClass, string][]).map(([k, label]) => <button key={k} className="pick" aria-pressed={choice === k} onClick={() => setChoice(k)}>{label}</button>)}</div>
          )}
          <label className="check"><input type="checkbox" checked={discomfort} onChange={(e) => setDiscomfort(e.target.checked)} /> Ho sentito fastidio o dolore</label>
          {error && <p className="save error" role="alert">{error}</p>}
          <button className="primary big" disabled={th.input.kind === 'CHOICE' && !choice} onClick={save}>Registra</button>
        </div>
      ) : (
        <div className="card"><p className="done">Prova registrata.</p><ul className="small">{results.map((r) => <li key={r}>{r}</li>)}</ul><button className="primary" onClick={() => void onDone()}>Torna alla valutazione</button></div>
      )}
      {side && results.length > 0 && <ul className="small">{results.map((r) => <li key={r}>{r}</li>)}</ul>}
    </>
  );
}

function LadderRunner({ probe, runId, onDone }: { probe: Probe; runId: string; onDone: () => Promise<void> }) {
  const l: Ladder = ladder(probe.ref);
  const sides: Side[] = l.perSide ? ['LEFT', 'RIGHT'] : ['BILATERAL'];
  const door = l.steps.some((s) => s.band?.door);
  const [level, setLevel] = useState<number | null>(null);
  const [sideIdx, setSideIdx] = useState(0);
  const [tries, setTries] = useState(0);              // gradini tentati in questa prova (massimo 3)
  const [stepResults, setStepResults] = useState<boolean[]>([]); // esiti dei lati sul gradino corrente
  const [log, setLog] = useState<string[]>([]);
  const [reached, setReached] = useState<number | null>(null);
  const [phase, setPhase] = useState<'REF' | 'STEP' | 'NEXT' | 'END'>(door ? 'REF' : 'STEP');
  const [endNote, setEndNote] = useState<string | null>(null);
  const [refMeasured, setRefMeasured] = useState(0);
  const [referenceCm, setReferenceCm] = useState<number | null>(null);
  const [band, setBand] = useState<EquipmentItem | null>(null);
  const [reps, setReps] = useState(10); const [seconds, setSeconds] = useState(0);
  const [rir, setRir] = useState<number | null | undefined>(undefined);
  const [tech, setTech] = useState<DomainTrial['technique']>(null);
  const [discomfort, setDiscomfort] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [restUntil, setRestUntil] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => { (async () => {
    setLevel(await startLevel(db, l.id, sides[0]!));
    const r = await lastReference(db, l.id); if (r !== null) setRefMeasured(Math.max(0, r - REFERENCE_OFFSET_CM));
  })(); }, []);
  const step = level !== null ? l.steps.find((s) => s.level === level)! : null;
  useEffect(() => { if (step) { bandForStep(db, step).then(setBand); if (step.reps) setReps(step.reps); } }, [level]);
  useEffect(() => { if (!restUntil) return; const t = window.setInterval(() => setNow(Date.now()), 500); return () => window.clearInterval(t); }, [restUntil]);
  if (level === null || !step) return null;
  const side = sides[sideIdx]!;
  const useRir = l.useRir && step.reps !== undefined;
  const reset = () => { setRir(undefined); setTech(null); setDiscomfort(false); setSeconds(0); setError(null); };

  const save = async () => {
    setError(null);
    try {
      const t = await recordLadderAttempt(db, {
        runId, probeId: probe.id, ladderId: l.id, level, side, reps: step.reps !== undefined ? reps : null, seconds: step.seconds !== undefined ? seconds : null,
        rir: useRir ? rir ?? null : null, technique: tech, discomfort, bandIds: band ? [band.id] : [], referenceCm: step.band?.door ? referenceCm : null,
      });
      const entry = `Livello ${level}${side !== 'BILATERAL' ? `, ${SIDE_NAME[side].toLowerCase()}` : ''}: ${t.passed ? 'superato' : 'non superato'}`;
      setLog([...log, entry]); reset();
      if (discomfort) { setEndNote('Prova interrotta per il fastidio segnalato: è registrata così, senza giudizi.'); setReached(stepResults.length === 0 && t.passed ? level : reached); setPhase('END'); return; }
      const results = [...stepResults, !!t.passed];
      if (sideIdx + 1 < sides.length) { setStepResults(results); setSideIdx(sideIdx + 1); return; }
      const all = results.every(Boolean);
      const nextTries = tries + 1;
      setTries(nextTries); setStepResults([]); setSideIdx(0);
      if (all) setReached(level);
      if (all && level < 5 && nextTries < 3) { setRestUntil(Date.now() + 120_000); setNow(Date.now()); setPhase('NEXT'); }
      else { setEndNote(all ? (level === 5 ? 'Hai superato il livello più alto della scala.' : 'Bastano 3 tentativi per oggi.') : null); setPhase('END'); }
    } catch (e) { setError((e as Error).message); }
  };

  if (phase === 'REF') return (
    <div className="card card-accent">
      <h3>Posizione di riferimento</h3>
      <p className="small">Con l'elastico agganciato alla porta, mettiti dove è appena teso con le braccia distese e misura la distanza dalla porta. La posizione di riferimento per tutta la scala sarà {REFERENCE_OFFSET_CM} cm più indietro: così i livelli dipendono dall'elastico, non dalla tua corporatura.</p>
      <Num label="Elastico appena teso (cm)" value={refMeasured} onChange={setRefMeasured} step={5} />
      <p className="small">Posizione di riferimento: <strong>{refMeasured + REFERENCE_OFFSET_CM} cm</strong> dalla porta.</p>
      <button className="primary big" disabled={refMeasured <= 0} onClick={() => { setReferenceCm(refMeasured + REFERENCE_OFFSET_CM); setPhase('STEP'); }}>Inizia la scala</button>
    </div>
  );
  if (phase === 'END') return (
    <div className="card">
      <p className="done">{reached !== null ? `Livello raggiunto oggi: ${reached}` : 'Oggi nessun livello superato: la prossima volta si parte un gradino più in basso.'}</p>
      {endNote && <p className="small">{endNote}</p>}
      <ul className="small">{log.map((x, i) => <li key={i}>{x}</li>)}</ul>
      <button className="primary" onClick={() => void onDone()}>Torna alla valutazione</button>
    </div>
  );
  if (phase === 'NEXT') {
    const left = Math.max(0, Math.ceil(((restUntil ?? 0) - now) / 1000));
    return (
      <div className="card card-accent">
        <p className="done">Livello {level} superato.</p>
        <p className="small">{left > 0 ? `Recupera ancora ${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}, poi prova il livello ${level + 1}.` : `Pronto per il livello ${level + 1}.`}</p>
        <div className="row">
          <button className="primary" onClick={() => { setLevel(level + 1); setRestUntil(null); setPhase('STEP'); }}>Prova il livello {level + 1}</button>
          <button onClick={() => { setEndNote(null); setPhase('END'); }}>Basta così</button>
        </div>
      </div>
    );
  }
  return (
    <>
      <ExerciseHint exerciseId={step.exerciseId} />
      <div className="card card-accent">
        <div className="li-head"><h3>Livello {level}{side !== 'BILATERAL' ? ` · ${SIDE_NAME[side]}` : ''}</h3><span className="small muted">tentativo {tries + 1} di 3</span></div>
        <p><strong>{step.label}</strong></p>
        <p className="small">Obiettivo: {step.reps !== undefined ? `${step.reps} ripetizioni` : `${step.seconds} secondi`} con buona tecnica{useRir ? ', con almeno 1 ripetizione ancora possibile' : ''}.{l.perSide ? '' : step.label.includes('per lato') ? ' Conta il lato più debole.' : ''}</p>
        {step.band && <p className="small">Elastico: {band ? <strong>{band.physicalLabel ?? ''} {band.color ?? ''}</strong> : <span className="todo">manca: metti in ordine gli elastici in Profilo → Attrezzatura</span>}{step.band.door && referenceCm !== null ? ` · ${referenceCm} cm dalla porta` : ''}</p>}
        {step.reps !== undefined ? <Num label="Ripetizioni fatte" value={reps} onChange={setReps} /> : <><Num label="Secondi" value={seconds} onChange={setSeconds} step={5} /><Stopwatch onStop={setSeconds} /></>}
        {useRir && <><p className="small muted">Quante ripetizioni avresti potuto fare ancora (RIR)?</p><div className="chips">{RIR_OPTIONS.map(([v, lb]) => <button key={lb} className="pick" aria-pressed={rir === v} onClick={() => setRir(v)}>{lb}</button>)}</div></>}
        <p className="small muted">Tecnica</p>
        <div className="chips">{TECH.map(([v, lb]) => <button key={lb} className="pick" aria-pressed={tech === v} onClick={() => setTech(v)}>{lb}</button>)}</div>
        <label className="check"><input type="checkbox" checked={discomfort} onChange={(e) => setDiscomfort(e.target.checked)} /> Ho sentito fastidio o dolore</label>
        {error && <p className="save error" role="alert">{error}</p>}
        <button className="primary big" disabled={!tech || (useRir && rir === undefined) || (!!step.band && !band)} onClick={save}>Registra</button>
      </div>
      {log.length > 0 && <ul className="small">{log.map((x, i) => <li key={i}>{x}</li>)}</ul>}
    </>
  );
}

function RatioRunner({ probe, runId, onDone }: { probe: Probe; runId: string; onDone: () => Promise<void> }) {
  const [tubes, setTubes] = useState<EquipmentItem[]>([]);
  const [bandId, setBandId] = useState<string | null>(null);
  const [distance, setDistance] = useState(0);
  const [row, setRow] = useState(12); const [press, setPress] = useState(12);
  const [discomfort, setDiscomfort] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);
  useEffect(() => { (async () => {
    const t = await orderedBands(db, 'RESISTANCE_BAND'); setTubes(t); setBandId(t[1]?.id ?? t[0]?.id ?? null);
    const r = await lastReference(db, 'T-OR'); if (r !== null) setDistance(r);
  })(); }, []);
  if (saved) return <div className="card"><p className="done">{saved}</p><button className="primary" onClick={() => void onDone()}>Torna alla valutazione</button></div>;
  return (
    <>
      <div className="card"><p className="small">Stesso elastico e stessa distanza dalla porta per i due esercizi, con 3 minuti di recupero tra l'uno e l'altro. Scegli un elastico con cui fai circa 10–20 ripetizioni. Per ognuno fai il massimo delle ripetizioni con buona tecnica e fermati quando la tecnica peggiora.</p></div>
      <ExerciseHint exerciseId="ex-021" />
      <ExerciseHint exerciseId="ex-018" />
      <div className="card card-accent">
        <p className="small muted">Elastico</p>
        <div className="chips">{tubes.map((t) => <button key={t.id} className="pick" aria-pressed={bandId === t.id} onClick={() => setBandId(t.id)}><span className="tag">{t.physicalLabel}</span> {t.color}</button>)}</div>
        <Num label="Distanza dalla porta (cm)" value={distance} onChange={setDistance} step={5} />
        <Num label="Rematore: ripetizioni" value={row} onChange={setRow} />
        <Num label="Spinta al petto: ripetizioni" value={press} onChange={setPress} />
        <label className="check"><input type="checkbox" checked={discomfort} onChange={(e) => setDiscomfort(e.target.checked)} /> Ho sentito fastidio o dolore</label>
        {error && <p className="save error" role="alert">{error}</p>}
        <button className="primary big" disabled={!bandId || distance <= 0} onClick={async () => {
          setError(null);
          try { await recordRatioH(db, { runId, probeId: probe.id, rowReps: row, pressReps: press, bandIds: [bandId!], distanceCm: distance, discomfort }); setSaved(`Registrato: ${row} ripetizioni di rematore contro ${press} di spinta al petto.`); }
          catch (e) { setError((e as Error).message); }
        }}>Registra</button>
      </div>
    </>
  );
}
