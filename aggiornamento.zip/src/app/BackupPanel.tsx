import { useEffect, useState } from 'react';
import { exportBackup, importBackup, isPopulated, setMeta, validateBackup, type ValidationReport } from '../data/backup';
import { exportTextFile, isNativeApp } from '../platform';
import { db } from './db';
import { fmtDateTime } from './format';

export function BackupPanel({ onChange, hasOpenSession, version }: { onChange: () => Promise<void>; hasOpenSession: boolean; version: number }) {
  const [msg, setMsg] = useState<string | null>(null);
  const [report, setReport] = useState<ValidationReport | null>(null);
  const [confirm, setConfirm] = useState(false);
  const [populated, setPopulated] = useState(false);
  useEffect(() => { isPopulated(db).then(setPopulated); }, [version]);

  const doExport = async (mode: 'download' | 'share') => {
    const b = await exportBackup(db, `${__APP_VERSION__}+${__BUILD_LABEL__}`);
    const text = JSON.stringify(b);
    const name = `fitpro-backup-${b.exportedAt.slice(0, 19).replace(/[:T]/g, '-')}.json`;
    try {
      await exportTextFile(name, text, mode);
      await setMeta(db, 'lastExportAt', b.exportedAt);
      setMsg(`Backup creato: ${b.counts.sessions ?? 0} sedute, ${b.counts.sets ?? 0} serie, ${b.counts.equipmentItems ?? 0} oggetti di attrezzatura, ${b.counts.profileVersions ?? 0} versioni del profilo. Controlla che il file sia arrivato a destinazione (es. su Drive).`);
      await onChange();
    } catch (e) { setMsg(`Backup annullato o non riuscito: ${(e as Error).message}`); }
  };

  const c = report?.summary.counts ?? {};
  return (
    <div className="panel">
      <h3>Salva un backup</h3>
      <p className="small">Il backup è un file con tutti i tuoi dati: profilo, attrezzatura, ordinamenti e sedute. Salvalo fuori dal telefono (Drive, email). L'app registra quando lo crei, ma non può verificare dove lo salvi.</p>
      <div className="row">
        <button className="primary" onClick={() => doExport('share')}>Salva backup (Drive, File…)</button>
        {!isNativeApp() && <button onClick={() => doExport('download')}>Scarica</button>}
      </div>

      <h3>Ripristina da un backup</h3>
      <p className="small">Il ripristino sostituisce tutti i dati attuali con quelli del file. Il file viene controllato per intero prima di toccare qualsiasi dato: se non è valido, non cambia nulla. Si possono ripristinare anche i backup fatti con la versione di prova.</p>
      {hasOpenSession && <p className="alert alert-warn">Chiudi la seduta in corso prima di ripristinare.</p>}
      <input type="file" accept="application/json,.json" disabled={hasOpenSession} onChange={async (e) => {
        const f = e.target.files?.[0]; if (!f) return;
        setReport(await validateBackup(await f.text())); setConfirm(false); setMsg(null);
      }} />
      {report && (report.ok ? (
        <div className="report ok">
          <p>File valido, creato il {fmtDateTime(report.summary.exportedAt)}: {c.sessions ?? 0} sedute, {c.sets ?? 0} serie, {c.equipmentItems ?? 0} oggetti di attrezzatura, {c.profileVersions ?? 0} versioni del profilo.{report.summary.schemaVersion !== null && report.summary.schemaVersion < 3 ? ' È un backup della versione di prova: verrà adattato automaticamente.' : ''}</p>
          {populated && (<>
            <p className="alert alert-warn">I dati attuali verranno sostituiti. Se ti servono, salva prima un backup dei dati attuali.</p>
            <label className="check"><input type="checkbox" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} /> Sostituisci i dati attuali</label>
          </>)}
          <button className="primary" disabled={populated && !confirm} onClick={async () => {
            try { await importBackup(db, report, { confirmReplace: confirm }); setMsg('Ripristino completato.'); setReport(null); await onChange(); }
            catch (e) { setMsg(`Ripristino non eseguito, dati attuali invariati: ${(e as Error).message}`); }
          }}>Ripristina</button>
        </div>
      ) : (
        <div className="report bad"><p>File rifiutato, nessuna modifica ai dati:</p><ul>{report.errors.slice(0, 10).map((x, i) => <li key={i}>{x}</li>)}</ul></div>
      ))}
      {msg && <p className="alert" role="status">{msg}</p>}
    </div>
  );
}
