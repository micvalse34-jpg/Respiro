// Profilo «Equilibrio» (D105): livelli e classi per dominio, rapporti, priorità con il loro motivo.
import { useEffect, useState } from 'react';
import { getProfile } from '../data/assessmentRepo';
import { CLASS_NAMES, DOMAINS } from '../domain/domains';
import { CONFIDENCE_NAMES, STATE_NAMES, type DomainProfile, type Profile } from '../domain/domainProfile';
import { db } from './db';

const GROUPS = ['FORZA', 'CORE', 'MOBILITÀ', 'EQUILIBRIO', 'FIATO'] as const;
const GROUP_TITLE: Record<(typeof GROUPS)[number], string> = { FORZA: 'Forza', CORE: 'Core', MOBILITÀ: 'Mobilità', EQUILIBRIO: 'Equilibrio', FIATO: 'Fiato' };

function Dots({ level }: { level: number }) {
  return <span className="dots" aria-label={`Livello ${level} su 5`}>{[1, 2, 3, 4, 5].map((i) => <span key={i} className={i <= level ? 'on' : ''} />)}</span>;
}

function Row({ d }: { d: DomainProfile }) {
  const def = DOMAINS.find((x) => x.id === d.id)!;
  const has = (x?: { level?: number | null; cls?: unknown }) => x != null && (x.level != null || x.cls != null);
  const sideText = def.perSide && (has(d.sides.LEFT) || has(d.sides.RIGHT))
    ? ` · S ${d.sides.LEFT?.level ?? (d.sides.LEFT?.cls ? CLASS_NAMES[d.sides.LEFT.cls] : '—')}, D ${d.sides.RIGHT?.level ?? (d.sides.RIGHT?.cls ? CLASS_NAMES[d.sides.RIGHT.cls] : '—')}` : '';
  return (
    <li className={`domain-row state-${d.state.toLowerCase()}`}>
      <div className="li-head">
        <strong>{d.name}</strong>
        <span className="chip">{STATE_NAMES[d.state]}</span>
      </div>
      <div className="small">
        {d.level !== null && d.estimated ? <>stima: al massimo livello {d.level}</> : d.level !== null ? <><Dots level={d.level} /> livello {d.level}</> : d.cls ? <>{CLASS_NAMES[d.cls]}</> : def.kind === 'TREND' ? 'Si segue con le sedute di fiato' : 'Non ancora misurato'}
        {sideText}{d.level !== null || d.cls ? ` · fiducia ${CONFIDENCE_NAMES[d.confidence]}` : ''}
      </div>
      {d.reasons.length > 0 && <div className="small muted">{d.reasons.join(' · ')}</div>}
    </li>
  );
}

export function BalanceScreen({ version, onAssessment }: { version: number; onAssessment: () => void }) {
  const [p, setP] = useState<Profile | null>(null);
  useEffect(() => { getProfile(db).then(setP); }, [version]);
  if (!p) return null;
  const byId = new Map(p.domains.map((d) => [d.id, d]));
  const measured = p.domains.filter((d) => d.state !== 'UNKNOWN').length;
  return (
    <section className="screen">
      <h2 className="screen-title">Equilibrio</h2>
      <p className="small muted">{measured} domini su {p.domains.length - 1} misurati{p.median !== null ? ` · livello di riferimento (mediana) ${p.median}` : ''}. Le priorità guideranno le sedute quando arriverà il motore (F3).</p>
      {measured < p.domains.length - 1 && <button onClick={onAssessment}>Continua la valutazione</button>}
      <div className="card card-accent">
        <h3>Dove insistere</h3>
        {p.priorities.length ? (
          <ol>{p.priorities.map((id) => <li key={id}><strong>{byId.get(id)!.name}</strong>: <span className="small">{byId.get(id)!.reasons.join(' · ')}</span></li>)}</ol>
        ) : <p className="small">Nessuna priorità confermata: servono almeno due prove concordi per dominio.</p>}
        {p.domains.some((d) => d.state === 'POSSIBLE') && <p className="small muted">Da confermare: {p.domains.filter((d) => d.state === 'POSSIBLE').map((d) => d.name.toLowerCase()).join(', ')}.</p>}
      </div>
      {GROUPS.map((g) => (
        <div key={g} className="card">
          <h3>{GROUP_TITLE[g]}</h3>
          <ul className="list plain">{DOMAINS.filter((d) => d.group === g).map((d) => <Row key={d.id} d={byId.get(d.id)!} />)}</ul>
        </div>
      ))}
      <div className="card">
        <h3>Rapporti</h3>
        <ul className="list plain">{p.ratios.map((r) => (
          <li key={r.id} className={r.outOfBand ? 'domain-row state-priority' : 'domain-row'}>
            <div className="li-head"><strong>{r.name}</strong>{r.value !== null && <span className="chip">{r.id === 'H' ? r.value.toFixed(2).replace('.', ',') : r.value > 0 ? `+${r.value}` : r.value}</span>}</div>
            <div className="small">{r.text}{r.outOfBand ? ' · fuori fascia' : ''}</div>
          </li>
        ))}</ul>
      </div>
      <p className="small muted">{p.ruleNote}.</p>
    </section>
  );
}
