import { useEffect, useState } from 'react';
import {
  addEquipment, addStarterKit, currentOrderings, deleteEquipment, listEquipment, orderingIsCurrent, rankOf, saveOrdering,
  setEquipmentStatus, suggestLabel, updateEquipment, type EquipmentInput,
} from '../data/equipmentRepo';
import { INTEGRITY_NAMES, isElastic, labelNumber, normalizeLabel, TYPE_NAMES } from '../domain/equipment';
import { numberOrNull, textOrNull } from '../domain/profile';
import { ACCESSORY_TYPES, ELASTIC_TYPES, type BandOrdering, type ElasticType, type EquipmentItem, type EquipmentType, type Integrity } from '../domain/types';
import { db } from './db';
import { useBack } from './back';
import { fmtDateTime, plural } from './format';

type Editing = { mode: 'new'; type: EquipmentType } | { mode: 'edit'; item: EquipmentItem } | { mode: 'order'; type: ElasticType } | null;

export function EquipmentScreen({ onChange }: { onChange: () => Promise<void> }) {
  const [items, setItems] = useState<EquipmentItem[] | null>(null);
  const [orderings, setOrderings] = useState<Partial<Record<ElasticType, BandOrdering>>>({});
  const [showRetired, setShowRetired] = useState(false);
  const [editing, setEditing] = useState<Editing>(null);
  const [notice, setNotice] = useState<string | null>(null);
  useBack(editing !== null, () => setEditing(null));

  const load = async () => { setItems(await listEquipment(db, true)); setOrderings(await currentOrderings(db)); };
  useEffect(() => { load(); }, []);
  const done = async (message: string | null) => { setEditing(null); setNotice(message); await load(); await onChange(); window.scrollTo(0, 0); };
  if (!items) return null;

  const active = items.filter((i) => i.status === 'ACTIVE');
  const retired = items.filter((i) => i.status === 'RETIRED');

  if (editing?.mode === 'new' || editing?.mode === 'edit') return <ItemForm editing={editing} onDone={done} onCancel={() => setEditing(null)} />;
  if (editing?.mode === 'order') {
    const ofType = active.filter((i) => i.type === editing.type);
    return <OrderEditor type={editing.type} items={ofType} current={orderings[editing.type]} onDone={done} onCancel={() => setEditing(null)} />;
  }

  return (
    <div className="panel">
      {notice && <p className="alert" role="status">{notice}</p>}
      <details className="method" open={active.length === 0}>
        <summary>Come si fa il censimento</summary>
        <ol>
          <li>Attacca a ogni elastico un'etichetta con un codice: E1, E2, E3… (nastro di carta e pennarello vanno benissimo). Il codice resta per sempre a quell'elastico.</li>
          <li>Registra qui ogni elastico con il suo codice e il colore. Se sulla confezione c'è una resistenza indicata, copiala così com'è: l'app non la converte in kg.</li>
          <li>Metti in ordine gli elastici dello stesso tipo dal più morbido al più duro, provandoli a mano. Basta la tua sensazione.</li>
        </ol>
      </details>

      {active.length === 0 && (
        <div className="card card-accent">
          <h3>Parti dalla tua attrezzatura</h3>
          <p>Crea in un colpo il kit Odoland (colori e valori scritti dal produttore), fitball 65 cm, palla Pilates 25 cm, 2 mattoncini e cinghia yoga, foam roller, 2 palline peanut (8 e 12 cm) e pallina a riccio 9 cm. Poi attacca le etichette agli elastici con questi codici:</p>
          <table className="kit">
            <tbody>
              <tr><th scope="row">Tubi</th><td>E1 giallo, E2 rosso, E3 blu, E4 verde, E5 nero</td></tr>
              <tr><th scope="row">Anelli</th><td>E6 verde, E7 blu, E8 giallo, E9 rosso, E10 nero</td></tr>
              <tr><th scope="row">A 8</th><td>E11 nero</td></tr>
            </tbody>
          </table>
          <p className="small">Attenzione: lo stesso colore non indica la stessa durezza tra tubi e anelli (il verde è il più morbido tra gli anelli, il quarto tra i tubi). Per questo l'app usa il codice, non il colore.</p>
          <button className="primary" onClick={async () => { try { const n = await addStarterKit(db); await done(`Creati ${n} oggetti. Ora metti in ordine tubi e anelli provandoli a mano.`); } catch (e) { setNotice((e as Error).message); } }}>Crea il kit</button>
        </div>
      )}

      {ELASTIC_TYPES.map((t) => {
        const ofType = active.filter((i) => i.type === t);
        const o = orderings[t];
        const ordered = orderingIsCurrent(o, ofType);
        const list = ordered ? [...ofType].sort((a, b) => rankOf(a.id, o, ofType)! - rankOf(b.id, o, ofType)!) : ofType;
        return (
          <section key={t} className="card">
            <h3>{TYPE_NAMES[t].many}</h3>
            {ofType.length >= 2 && (ordered
              ? <p className="small done">In ordine dal più morbido al più duro (dichiarato il {fmtDateTime(o!.declaredAt)}).</p>
              : <p className="small todo">{o ? 'Ordine da aggiornare: gli elastici sono cambiati.' : 'Ordine dal più morbido al più duro non ancora indicato.'}</p>)}
            {list.length === 0 ? <p className="muted small">Nessuno.</p> : (
              <ul className="items">
                {list.map((i) => (
                  <li key={i.id}>
                    <button className="item" onClick={() => setEditing({ mode: 'edit', item: i })}>
                      <span className="tag">{i.physicalLabel}</span>
                      <span className="item-text">
                        <span>{i.color ?? <em className="todo">colore da inserire</em>}{i.declaredResistance ? `, «${i.declaredResistance}»` : ''}</span>
                        <span className="small muted">{ordered ? `${rankOf(i.id, o, ofType)}° dal più morbido` : ''}{i.integrity && i.integrity !== 'OK' ? `${ordered ? ', ' : ''}${INTEGRITY_NAMES[i.integrity].toLowerCase()}` : ''}</span>
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <div className="row">
              <button onClick={() => setEditing({ mode: 'new', type: t })}>Aggiungi</button>
              {ofType.length >= 2 && <button className={ordered ? '' : 'primary'} onClick={() => setEditing({ mode: 'order', type: t })}>{ordered ? 'Cambia ordine' : 'Metti in ordine'}</button>}
            </div>
          </section>
        );
      })}

      <section className="card">
        <h3>Accessori</h3>
        {active.filter((i) => !isElastic(i.type)).length === 0 ? <p className="muted small">Nessuno.</p> : (
          <ul className="items">
            {active.filter((i) => !isElastic(i.type)).map((i) => (
              <li key={i.id}>
                <button className="item" onClick={() => setEditing({ mode: 'edit', item: i })}>
                  <span className="item-text">
                    <span>{TYPE_NAMES[i.type].one}{i.quantity === null ? '' : i.quantity > 1 ? ` ×${i.quantity}` : ''}{i.description ? `: ${i.description}` : ''}</span>
                    {i.quantity === null && <span className="small todo">quantità da indicare</span>}
                    {i.integrity && i.integrity !== 'OK' && <span className="small muted">{INTEGRITY_NAMES[i.integrity].toLowerCase()}</span>}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}
        <button onClick={() => setEditing({ mode: 'new', type: 'HANDLE' })}>Aggiungi accessorio</button>
      </section>

      {retired.length > 0 && (
        <section className="card card-quiet">
          <label className="check"><input type="checkbox" checked={showRetired} onChange={(e) => setShowRetired(e.target.checked)} /> Mostra oggetti dismessi ({retired.length})</label>
          {showRetired && (
            <ul className="items">
              {retired.map((i) => (
                <li key={i.id}>
                  <button className="item" onClick={() => setEditing({ mode: 'edit', item: i })}>
                    {i.physicalLabel && <span className="tag tag-off">{i.physicalLabel}</span>}
                    <span className="item-text"><span>{TYPE_NAMES[i.type].one}{i.color ? `, ${i.color}` : ''}{i.description ? `: ${i.description}` : ''}</span>
                      <span className="small muted">dismesso il {fmtDateTime(i.retiredAt)}</span></span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}
    </div>
  );
}

interface Form { type: EquipmentType; label: string; color: string; declaredResistance: string; restLengthCm: string; brandModel: string; integrity: string; quantity: string; description: string; notes: string }

function ItemForm({ editing, onDone, onCancel }: { editing: { mode: 'new'; type: EquipmentType } | { mode: 'edit'; item: EquipmentItem }; onDone: (m: string | null) => Promise<void>; onCancel: () => void }) {
  const item = editing.mode === 'edit' ? editing.item : null;
  const [f, setF] = useState<Form>({
    type: item?.type ?? (editing.mode === 'new' ? editing.type : 'OTHER'), label: item?.physicalLabel ?? '', color: item?.color ?? '',
    declaredResistance: item?.declaredResistance ?? '', restLengthCm: item?.restLengthCm?.toString().replace('.', ',') ?? '', brandModel: item?.brandModel ?? '',
    integrity: item?.integrity ?? '', quantity: item ? (item.quantity === null ? '' : String(item.quantity)) : '1', description: item?.description ?? '', notes: item?.notes ?? '',
  });
  const [error, setError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  useBack(confirmDelete, () => setConfirmDelete(false));
  const elastic = isElastic(f.type);
  useEffect(() => { if (!item && elastic) suggestLabel(db).then((l) => setF((x) => (x.label ? x : { ...x, label: l }))); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const set = (k: keyof Form) => (e: { target: { value: string } }) => { setF({ ...f, [k]: e.target.value }); setError(null); };
  const name = item ? `${TYPE_NAMES[item.type].one}${item.physicalLabel ? ` ${item.physicalLabel}` : ''}` : `Nuovo: ${TYPE_NAMES[f.type].one.toLowerCase()}`;

  const run = async (fn: () => Promise<unknown>, message: string) => {
    try { await fn(); await onDone(message); } catch (e) { setError((e as Error).message); }
  };
  const save = () => {
    const fields = {
      description: textOrNull(f.description), color: textOrNull(f.color), brandModel: textOrNull(f.brandModel),
      declaredResistance: textOrNull(f.declaredResistance), restLengthCm: numberOrNull(f.restLengthCm),
      integrity: (f.integrity || null) as Integrity | null, quantity: elastic ? 1 : numberOrNull(f.quantity), notes: textOrNull(f.notes),
    };
    if (fields.quantity !== null && Number.isNaN(fields.quantity)) { setError('Quantità: inserire un numero intero o lasciare vuoto.'); return; }
    if (fields.restLengthCm !== null && Number.isNaN(fields.restLengthCm)) { setError('Lunghezza: inserire un numero in centimetri.'); return; }
    if (item) return run(() => updateEquipment(db, item.id, fields), `${name}: modifiche salvate.`);
    const input: EquipmentInput = { type: f.type, physicalLabel: elastic ? f.label : null, ...fields };
    return run(() => addEquipment(db, input), `${TYPE_NAMES[f.type].one}${elastic ? ` ${normalizeLabel(f.label) ?? ''}` : ''} aggiunto.`);
  };

  return (
    <div className="panel">
      <button className="back" onClick={onCancel}>Torna all'attrezzatura</button>
      <h3>{name}</h3>
      {!item && !elastic && (
        <label>Tipo<select value={f.type} onChange={set('type')}>{ACCESSORY_TYPES.map((t) => <option key={t} value={t}>{TYPE_NAMES[t].one}</option>)}</select></label>
      )}
      {elastic && !item && <label>Codice dell'etichetta<input value={f.label} onChange={set('label')} autoCapitalize="characters" /></label>}
      {elastic && item && <p className="muted small">Il codice {item.physicalLabel} non si può cambiare: lo storico lo usa per riconoscere questo elastico.</p>}
      {elastic && <label>Colore<input value={f.color} onChange={set('color')} placeholder="es. giallo" /></label>}
      {elastic && <label>Resistenza scritta sul prodotto o sulla confezione<input value={f.declaredResistance} onChange={set('declaredResistance')} placeholder="copiala così com'è, es. «9,1 kg», «Light»" /></label>}
      {!elastic && <label>Quantità (vuoto = non indicata)<input inputMode="numeric" value={f.quantity} onChange={set('quantity')} /></label>}
      {!elastic && <label>Descrizione<input value={f.description} onChange={set('description')} placeholder="facoltativa" /></label>}
      <div className="grid">
        {elastic && <label>Lunghezza a riposo (cm)<input inputMode="decimal" value={f.restLengthCm} onChange={set('restLengthCm')} placeholder="facoltativa" /></label>}
        <label>Stato
          <select value={f.integrity} onChange={set('integrity')}>
            <option value="">Non verificato</option>
            {(Object.keys(INTEGRITY_NAMES) as Integrity[]).map((k) => <option key={k} value={k}>{INTEGRITY_NAMES[k]}</option>)}
          </select>
        </label>
      </div>
      {f.integrity === 'DAMAGED' && <p className="alert alert-warn">Un elastico o un accessorio danneggiato può cedere durante l'uso. Segui le indicazioni del produttore; quando l'app proporrà le sedute non lo userà.</p>}
      <label>Marca e modello<input value={f.brandModel} onChange={set('brandModel')} placeholder="facoltativi" /></label>
      <label>Note<textarea rows={2} value={f.notes} onChange={set('notes')} /></label>
      {error && <p className="save error" role="alert">{error}</p>}
      <div className="row">
        <button className="primary" onClick={save}>{item ? 'Salva modifiche' : 'Aggiungi'}</button>
        <button onClick={onCancel}>Annulla</button>
      </div>
      {item && (
        <div className="card card-quiet">
          {item.status === 'ACTIVE'
            ? <><p className="small">Non lo usi più (rotto, perso, regalato)? Segnalo come dismesso: sparisce dagli elenchi ma resta nello storico delle sedute in cui l'hai usato.</p>
                <button onClick={() => run(() => setEquipmentStatus(db, item.id, 'RETIRED'), `${name} segnato come dismesso.`)}>Segna come dismesso</button></>
            : <button onClick={() => run(() => setEquipmentStatus(db, item.id, 'ACTIVE'), `${name} di nuovo in uso.`)}>Rimetti in uso</button>}
          <p className="small">Eliminare definitivamente è possibile solo per un oggetto inserito per errore e mai usato.</p>
          {!confirmDelete ? <button onClick={() => setConfirmDelete(true)}>Elimina</button> : (
            <div className="row">
              <button className="danger" onClick={() => run(() => deleteEquipment(db, item.id), `${name} eliminato.`)}>Sì, elimina</button>
              <button onClick={() => setConfirmDelete(false)}>Annulla</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function OrderEditor({ type, items, current, onDone, onCancel }: { type: ElasticType; items: EquipmentItem[]; current: BandOrdering | undefined; onDone: (m: string | null) => Promise<void>; onCancel: () => void }) {
  const initial = orderingIsCurrent(current, items) ? current!.orderedIds : [...items].sort((a, b) => labelNumber(a.physicalLabel) - labelNumber(b.physicalLabel)).map((i) => i.id);
  const [order, setOrder] = useState<string[]>(initial);
  const [error, setError] = useState<string | null>(null);
  const byId = new Map(items.map((i) => [i.id, i]));
  const move = (idx: number, d: -1 | 1) => { const o = [...order]; [o[idx], o[idx + d]] = [o[idx + d]!, o[idx]!]; setOrder(o); };
  return (
    <div className="panel">
      <button className="back" onClick={onCancel}>Torna all'attrezzatura</button>
      <h3>{TYPE_NAMES[type].many}: dal più morbido al più duro</h3>
      {!orderingIsCurrent(current, items) && <p className="small">L'ordine proposto segue i valori del produttore. Confermalo o correggilo dopo averli provati.</p>}
      <p className="small">Prova ogni elastico tirandolo più o meno della stessa lunghezza e sposta in alto i più morbidi. È una valutazione a sensazione: va bene così, e puoi cambiarla quando vuoi (l'ordine precedente resta registrato).</p>
      <ol className="order">
        {order.map((id, idx) => {
          const i = byId.get(id)!;
          return (
            <li key={id}>
              <span className="tag">{i.physicalLabel}</span>
              <span className="item-text">{i.color ?? 'colore non indicato'}{idx === 0 ? ' (il più morbido)' : idx === order.length - 1 ? ' (il più duro)' : ''}</span>
              <button aria-label={`Sposta ${i.physicalLabel} verso i più morbidi`} disabled={idx === 0} onClick={() => move(idx, -1)}>Su</button>
              <button aria-label={`Sposta ${i.physicalLabel} verso i più duri`} disabled={idx === order.length - 1} onClick={() => move(idx, 1)}>Giù</button>
            </li>
          );
        })}
      </ol>
      {error && <p className="save error" role="alert">{error}</p>}
      <div className="row">
        <button className="primary" onClick={async () => { try { await saveOrdering(db, type, order); await onDone(`Ordine salvato: ${order.map((id) => byId.get(id)!.physicalLabel).join(', ')}.`); } catch (e) { setError((e as Error).message); } }}>Salva ordine</button>
        <button onClick={onCancel}>Annulla</button>
      </div>
      <p className="muted small">{plural(items.length, 'elastico', 'elastici')} in uso di questo tipo.</p>
    </div>
  );
}
