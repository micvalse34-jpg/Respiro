// Scheda dell'esercizio. «compact»: durante la seduta (indicazioni e respirazione sempre visibili, il resto a un tocco, 10 §1).
// «full»: nella Libreria, con tutte le sezioni.
import { TYPE_NAMES } from '../domain/equipment';
import { ANCHOR_LABEL, GROUP_NAMES, JOINT_NAMES, MUSCLE_NAMES, NEED_NAMES, targetText, type ExerciseMeta } from '../domain/library';
import type { ExerciseVersion } from '../domain/types';
import { SOURCES } from '../data/libraryContent';
import { CARD_STATUS_NAMES, type CardStatus } from '../data/libraryRepo';

export function StatusChip({ status }: { status: CardStatus }) {
  return <span className={`chip chip-status-${status.toLowerCase()}`}>{CARD_STATUS_NAMES[status]}</span>;
}

export function equipmentText(meta: ExerciseMeta): string {
  const parts = meta.equipment.filter((t) => t !== 'HANDLE' && t !== 'DOOR_ANCHOR').map((t) => TYPE_NAMES[t].one.toLowerCase());
  if (meta.anchor) parts.push(`ancoraggio alla porta ${ANCHOR_LABEL[meta.anchor]}`);
  meta.needs.forEach((n) => parts.push(NEED_NAMES[n].split(' (')[0]!));
  return parts.length ? parts.join(', ') : 'corpo libero';
}

const List = ({ items }: { items: string[] }) => <ul className="small">{items.map((x) => <li key={x}>{x}</li>)}</ul>;

export function ExerciseCard({ version, meta, mode, status }: { version: ExerciseVersion; meta: ExerciseMeta; mode: 'compact' | 'full'; status: CardStatus }) {
  const c = version.content;
  if (!c) return <div className="card card-quiet"><p className="small muted">La scheda di questo esercizio arriverà con una delle prossime versioni.</p></div>;
  const muscles = [...meta.primary.map((m) => MUSCLE_NAMES[m]), ...meta.secondary.map((m) => `${MUSCLE_NAMES[m]} (in parte)`)];
  const joints = meta.joints.map((j) => JOINT_NAMES[j]);
  return (
    <div className="card exercise-card">
      <div className="li-head"><h3>{c.displayName}</h3>{status !== 'TESTED' && <StatusChip status={status} />}</div>
      {mode === 'full' && c.purpose && <p>{c.purpose}</p>}
      {mode === 'full' && <p className="small muted">{GROUP_NAMES[meta.group]} · {targetText(meta)} · {equipmentText(meta)}</p>}
      <ul className="cues">{c.cues.map((x) => <li key={x}>{x}</li>)}</ul>
      {version.breathing && <p className="breath"><strong>Respirazione:</strong> {version.breathing}</p>}
      {mode === 'compact' ? (
        <details>
          <summary>Preparazione, errori e sicurezza</summary>
          <Sections c={c} />
        </details>
      ) : (
        <>
          <Sections c={c} />
          {(muscles.length > 0 || joints.length > 0) && <><p className="small"><strong>Che cosa lavora</strong></p><p className="small">{[...muscles, ...joints].join(', ')}.</p></>}
          {c.sources && c.sources.length > 0 && (
            <details><summary className="small">Fonti</summary><List items={c.sources.map((s) => SOURCES[s] ?? s)} /></details>
          )}
        </>
      )}
    </div>
  );
}

function Sections({ c }: { c: NonNullable<ExerciseVersion['content']> }) {
  return (
    <>
      <p className="small"><strong>Preparazione</strong></p><List items={c.setup} />
      <p className="small"><strong>Errori comuni</strong></p><List items={c.commonErrors} />
      {(c.safetyChecks.length > 0 || (c.stopIf?.length ?? 0) > 0) && <><p className="small"><strong>Sicurezza</strong></p><List items={[...c.safetyChecks, ...(c.stopIf ?? [])]} /></>}
      {c.easier && c.easier.length > 0 && <><p className="small"><strong>Più facile</strong></p><List items={c.easier} /></>}
      {c.harder && c.harder.length > 0 && <><p className="small"><strong>Più difficile</strong></p><List items={c.harder} /></>}
      {c.variants && c.variants.length > 0 && <><p className="small"><strong>Varianti</strong></p><List items={c.variants.map((v) => `${v.name}: ${v.description}`)} /></>}
    </>
  );
}
