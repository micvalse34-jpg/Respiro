// Scelta dell'esercizio e impostazione prima di iniziare (elastici, ancoraggio, distanza secondo l'esercizio).
import { useEffect, useMemo, useState } from 'react';
import { initialConfig, orderedBands, safetyCheckRequired, snapshotOf } from '../data/freeSessionRepo';
import type { LibraryItem } from '../data/libraryRepo';
import { ANCHOR_NAMES } from '../domain/comparability';
import { TYPE_NAMES } from '../domain/equipment';
import { GROUP_NAMES, targetText, type ExerciseMeta, type LibraryGroup } from '../domain/library';
import { matches, searchText } from '../domain/search';
import type { ConfigurationSnapshot, EquipmentItem } from '../domain/types';
import { db } from './db';
import { StatusChip } from './ExerciseCard';

export type Labeler = (id: string) => string;

export const cfgText = (c: ConfigurationSnapshot | null, label: Labeler): string => {
  if (!c) return 'senza elastici';
  const bands = c.bandIds.map(label).join(' + ') || 'nessun elastico';
  if (c.anchor === null && c.distanceCm === null) return bands;
  return `${bands}, ${ANCHOR_NAMES[c.anchor ?? ''] ?? 'ancoraggio non indicato'}, ${c.distanceCm ?? '—'} cm dalla porta`;
};

/** Elenco degli esercizi allenabili (scheda pronta), per gruppo. Gli esercizi senza attrezzatura sufficiente sono indicati e non selezionabili. */
export function ExercisePicker({ items, exclude, onPick, onCancel, title }: { items: LibraryItem[]; exclude: string[]; onPick: (id: string) => void; onCancel?: () => void; title: string }) {
  const ready = items.filter((i) => i.status !== 'IN_PREPARATION' && !exclude.includes(i.entry.id));
  const groups = [...new Set(ready.map((i) => i.entry.meta.group))] as LibraryGroup[];
  const [group, setGroup] = useState<LibraryGroup | 'ALL'>('ALL');
  const [query, setQuery] = useState('');
  const searching = query.trim().length > 0;
  const shown = ready.filter((i) => (searching ? matches(query, searchText(i.entry)) : group === 'ALL' || i.entry.meta.group === group))
    .sort((a, b) => Number(a.missing.length > 0) - Number(b.missing.length > 0) || a.entry.displayName.localeCompare(b.entry.displayName, 'it'));
  return (
    <div className="card">
      <div className="li-head"><h3>{title}</h3>{onCancel && <button className="link" onClick={onCancel}>Annulla</button>}</div>
      <input className="search" type="search" placeholder="Cerca: nome, muscolo, attrezzo…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Cerca un esercizio" />
      {!searching && (
        <div className="chips scroll-x">
          <button className="pick" aria-pressed={group === 'ALL'} onClick={() => setGroup('ALL')}>Tutti</button>
          {groups.map((g) => <button key={g} className="pick" aria-pressed={group === g} onClick={() => setGroup(g)}>{GROUP_NAMES[g]}</button>)}
        </div>
      )}
      <ul className="list">
        {shown.map((i) => (
          <li key={i.entry.id}>
            <button className="list-item" disabled={i.missing.length > 0} onClick={() => onPick(i.entry.id)}>
              <span className="li-head"><strong>{i.entry.displayName}</strong><StatusChip status={i.status} /></span>
              <span className="li-sub">{i.missing.length ? `Manca: ${i.missing.map((t) => TYPE_NAMES[t].one.toLowerCase()).join(', ')}` : targetText(i.entry.meta)}</span>
            </button>
          </li>
        ))}
      </ul>
      {shown.length === 0 && <p className="small muted">{searching ? 'Nessun esercizio pronto trovato.' : 'Nessun esercizio pronto in questo gruppo.'}</p>}
    </div>
  );
}

/**
 * Impostazione dell'esercizio. Il controllo di elastici e ancoraggio (D086) compare quando serve
 * e viene richiesto anche se la scelta degli elastici lo rende necessario solo al momento di iniziare.
 */
export function SetupForm({ exerciseId, meta, label, submitLabel, onSubmit, onCancel, initial }: {
  exerciseId: string; meta: ExerciseMeta; label: Labeler; submitLabel: string;
  onSubmit: (cfg: ConfigurationSnapshot | null, safetyConfirmed: boolean) => Promise<void>; onCancel?: () => void; initial?: ConfigurationSnapshot | null;
}) {
  const [bandsAvail, setBandsAvail] = useState<EquipmentItem[]>([]);
  const [bands, setBands] = useState<string[]>([]);
  const [anchor, setAnchor] = useState<string>(meta.anchor ?? 'DOOR_MID');
  const [distance, setDistance] = useState('');
  const [needCheck, setNeedCheck] = useState(false);
  const [checked, setChecked] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);
  const loop = meta.setup === 'LOOP';

  useEffect(() => {
    (async () => {
      if (meta.setup !== 'NONE') setBandsAvail(await orderedBands(db, loop ? 'LOOP_BAND' : 'RESISTANCE_BAND'));
      const c = initial !== undefined ? initial : await initialConfig(db, exerciseId);
      if (c) { setBands(c.bandIds); if (c.anchor) setAnchor(c.anchor); setDistance(c.distanceCm?.toString() ?? ''); setNeedCheck(await safetyCheckRequired(db, c.bandIds)); }
      setReady(true);
    })();
  }, [exerciseId]);

  const cfg = useMemo((): ConfigurationSnapshot | null => {
    if (meta.setup === 'NONE') return null;
    const d = distance.trim() === '' ? null : Number(distance.replace(',', '.'));
    return meta.setup === 'TUBE_DOOR' ? snapshotOf(bands, anchor, d === null || Number.isNaN(d) ? null : Math.round(d)) : snapshotOf(bands, null, null);
  }, [bands, anchor, distance, meta.setup]);

  if (!ready) return null;
  const toggle = (id: string) => { setError(null); setBands(loop ? (bands[0] === id ? [] : [id]) : bands.includes(id) ? bands.filter((b) => b !== id) : [...bands, id]); };

  const submit = async () => {
    setError(null);
    if (meta.setup !== 'NONE' && !bands.length) { setError(loop ? 'Scegli l\'elastico ad anello.' : 'Scegli almeno un elastico.'); return; }
    if (meta.setup === 'TUBE_DOOR' && cfg?.distanceCm == null) { setError('Indica la distanza dalla porta in centimetri: serve per confrontare le sedute.'); return; }
    if (cfg && !checked && await safetyCheckRequired(db, cfg.bandIds)) { setNeedCheck(true); setError('Usi un elastico per la prima volta o è passata una settimana: controlla e spunta la conferma.'); return; }
    setBusy(true);
    try { await onSubmit(cfg, checked); } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  };

  return (
    <div className="panel">
      {meta.setup !== 'NONE' && (
        <>
          <p className="small muted">{loop ? 'Elastico ad anello' : 'Elastici a tubo (puoi sceglierne più di uno, si usano insieme)'}</p>
          <div className="chips">
            {bandsAvail.map((t) => (
              <button key={t.id} className="pick" aria-pressed={bands.includes(t.id)} disabled={t.integrity === 'DAMAGED'} onClick={() => toggle(t.id)}>
                <span className="tag">{t.physicalLabel}</span> {t.color}
              </button>
            ))}
          </div>
          {bandsAvail.length === 0 && <p className="todo small">Nessun elastico di questo tipo censito: completa Profilo → Attrezzatura.</p>}
        </>
      )}
      {meta.setup === 'TUBE_DOOR' && (
        <div className="grid">
          <label>Ancoraggio alla porta
            <select value={anchor} onChange={(e) => setAnchor(e.target.value)}>{Object.entries(ANCHOR_NAMES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
          </label>
          <label>Distanza dalla porta (cm)<input inputMode="numeric" value={distance} onChange={(e) => { setDistance(e.target.value); setError(null); }} placeholder="es. 80" /></label>
        </div>
      )}
      {meta.setup === 'TUBE_DOOR' && distance.trim() === '' && (
        <p className="hint">Prima volta? Mettiti nella posizione di partenza, dove l'elastico è appena teso, misura la distanza e scrivila. Dopo ogni serie l'app ti dirà se allontanarti o avvicinarti.</p>
      )}
      {meta.setup !== 'NONE' && (needCheck
        ? <label className="check"><input type="checkbox" checked={checked} onChange={(e) => setChecked(e.target.checked)} />
            Ho controllato elastici, maniglie e {meta.setup === 'TUBE_DOOR' ? 'ancoraggio: niente crepe o tagli, ancoraggio ben chiuso nella porta' : 'moschettoni: niente crepe o tagli'}</label>
        : <p className="small muted">Prima di tendere l'elastico, un'occhiata a elastico{meta.setup === 'TUBE_DOOR' ? ' e ancoraggio' : ''}.</p>)}
      {meta.setup !== 'NONE' && <p className="muted small">Configurazione: {cfgText(cfg, label)}.</p>}
      {error && <p className="save error" role="alert">{error}</p>}
      <div className="row">
        <button className="primary big" disabled={busy} onClick={submit}>{submitLabel}</button>
        {onCancel && <button onClick={onCancel}>Annulla</button>}
      </div>
    </div>
  );
}
