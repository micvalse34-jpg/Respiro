import { useEffect, useState } from 'react';
import { countSessions, deleteTestData, getHistoryDetail, listSessionSummaries, markSessionAsTest, markSessionsAsTest, type HistoryDetail, type SessionSummary } from '../data/historyRepo';
import type { ConfigurationSnapshot, EquipmentItem, ExercisePrescription, SetPerformance } from '../domain/types';
import { db } from './db';
import { useBack } from './back';
import { ANCHOR_NAMES } from '../domain/comparability';
import { fmtDay, fmtTime, plural, sessionTypeName, SIDE_NAMES, STATUS_NAMES } from './format';

const PAGE = 30;

export function HistoryScreen({ onChange, version }: { onChange: () => Promise<void>; version: number }) {
  const [includeTest, setIncludeTest] = useState(false);
  const [items, setItems] = useState<SessionSummary[] | null>(null);
  const [counts, setCounts] = useState({ real: 0, test: 0 });
  const [limit, setLimit] = useState(PAGE);
  const [openId, setOpenId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [selecting, setSelecting] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  useBack(openId !== null, () => setOpenId(null));
  useBack(selecting, () => { setSelecting(false); setSelected(new Set()); });

  useEffect(() => {
    (async () => {
      setCounts(await countSessions(db));
      setItems(await listSessionSummaries(db, { includeTest, limit }));
    })();
  }, [includeTest, limit, version]);

  if (openId) return <SessionView id={openId} onBack={() => setOpenId(null)} onMarked={async () => { setOpenId(null); setNotice('Seduta spostata tra quelle di prova: non conta più per le proposte. Puoi eliminarla in fondo allo Storico.'); await onChange(); }} />;
  if (!items) return null;
  const total = includeTest ? counts.real + counts.test : counts.real;

  return (
    <section className="screen">
      <h2 className="screen-title">Storico</h2>
      {notice && <p className="alert" role="status">{notice}</p>}
      {counts.test > 0 && (
        <label className="check"><input type="checkbox" checked={includeTest} onChange={(e) => { setIncludeTest(e.target.checked); setLimit(PAGE); }} /> Mostra anche le sedute di prova ({counts.test})</label>
      )}
      {items.length === 0 ? (
        <p className="empty">{counts.real === 0 ? 'Nessuna seduta di allenamento registrata. Le sedute compariranno qui man mano che le registri.' : 'Nessuna seduta.'}</p>
      ) : (
        <ul className="list">
          {items.map((s) => (
            <li key={s.session.id} className={selecting ? 'selectable' : undefined}>
              {selecting && s.session.sessionType === 'FREE' && s.session.status !== 'IN_PROGRESS' && (
                <input type="checkbox" aria-label="Seleziona" checked={selected.has(s.session.id)}
                  onChange={(e) => { const n = new Set(selected); if (e.target.checked) n.add(s.session.id); else n.delete(s.session.id); setSelected(n); }} />
              )}
              <button className="list-item" onClick={() => selecting ? undefined : setOpenId(s.session.id)}>
                <span className="li-head">
                  <strong>{fmtDay(s.session.startedAt)}</strong>
                  <span className={`chip chip-${s.session.status.toLowerCase()}`}>{STATUS_NAMES[s.session.status]}</span>
                </span>
                <span className="li-sub">{sessionTypeName(s.session)}, ore {fmtTime(s.session.startedAt)}{s.durationMin !== null ? `, ${s.durationMin} min` : ''}</span>
                <span className="li-sub">{summaryLine(s)}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
      {items.length < total && <button onClick={() => setLimit(limit + PAGE)}>Mostra altre sedute</button>}
      {counts.real > 0 && !selecting && <button className="secondary" onClick={() => { setSelecting(true); setIncludeTest(false); }}>Seleziona sedute inserite per prova</button>}
      {selecting && (
        <div className="row">
          <button className="danger" disabled={selected.size === 0} onClick={async () => {
            await markSessionsAsTest(db, [...selected]);
            setNotice(`${selected.size === 1 ? '1 seduta spostata' : `${selected.size} sedute spostate`} tra quelle di prova: non contano più per le proposte. Puoi eliminarle qui sotto.`);
            setSelecting(false); setSelected(new Set()); await onChange();
          }}>Segna come prova ({selected.size})</button>
          <button onClick={() => { setSelecting(false); setSelected(new Set()); }}>Annulla</button>
        </div>
      )}
      {counts.test > 0 && <DeleteTestData count={counts.test} onDone={async (m) => { setNotice(m); setIncludeTest(false); await onChange(); }} />}
    </section>
  );
}

function summaryLine(s: SessionSummary): string {
  const parts = [plural(s.performed, 'serie eseguita', 'serie eseguite')];
  if (s.interrupted) parts.push(plural(s.interrupted, 'interrotta', 'interrotte'));
  if (s.notPerformed) parts.push(`${s.notPerformed} non eseguite`);
  return parts.join(', ');
}

function SessionView({ id, onBack, onMarked }: { id: string; onBack: () => void; onMarked: () => Promise<void> }) {
  const [d, setD] = useState<HistoryDetail | null | undefined>(undefined);
  const [confirmMark, setConfirmMark] = useState(false);
  useBack(confirmMark, () => setConfirmMark(false));
  useEffect(() => { getHistoryDetail(db, id).then(setD); }, [id]);
  if (d === undefined) return null;
  if (d === null) return <section className="screen"><button onClick={onBack}>Torna allo storico</button><p>Seduta non trovata.</p></section>;
  const s = d.session;
  return (
    <section className="screen">
      <button className="back" onClick={onBack}>Torna allo storico</button>
      <h2 className="screen-title">{fmtDay(s.startedAt)}</h2>
      <p className="muted">
        {sessionTypeName(s)}, {STATUS_NAMES[s.status].toLowerCase()}. Inizio {fmtTime(s.startedAt)}{s.endedAt ? `, fine ${fmtTime(s.endedAt)}` : ''}.
        {s.closeReason === 'CLOSED_ON_REOPEN' && ' Chiusa alla riapertura dell\'app.'}
      </p>
      {d.blocks.map((b) => (
        <div key={b.prescription.id} className="card">
          <h3>{b.prescription.order}. {b.name}{b.prescription.origin === 'USER_ADDED' ? ' (aggiunto da te)' : ''}</h3>
          <p className="muted small">{targetLine(b.prescription)}</p>
          {b.prescription.configurationSnapshot && <p className="muted small">{snapshotLine(b.prescription.configurationSnapshot, d.equipment)}</p>}
          {b.sets.length === 0 ? <p className="muted">Nessuna serie registrata.</p> : (
            <ol className="sets">{b.sets.map((x) => <li key={x.id} className={`set set-${x.status.toLowerCase()}`}>{setLine(x)}{x.configurationSnapshot && b.prescription.configurationSnapshot && JSON.stringify(x.configurationSnapshot) !== JSON.stringify(b.prescription.configurationSnapshot) ? ` — ${snapshotLine(x.configurationSnapshot, d.equipment).replace('Elastici usati: ', 'con ')}` : ''}{x.discomfort ? ' (fastidio segnalato)' : ''}</li>)}</ol>
          )}
        </div>
      ))}
      {d.events.map((e) => (
        <div key={e.id} className="card card-quiet">
          <h3>{e.status === 'INFO' ? 'Valutazione' : `Proposta ${e.status === 'ACCEPTED' ? 'accettata' : e.status === 'REJECTED' ? 'rifiutata' : 'in attesa'}`}</h3>
          <p className="small">{e.reason}</p>
          {e.rejectionReason && <p className="small muted">Motivo: {({ NO_SPACE: 'non c\'è spazio per allontanarsi', JUMP_TOO_BIG: 'salto troppo grande', NOT_READY: 'non ancora pronto', OTHER: 'altro' } as Record<string, string>)[e.rejectionReason]}.</p>}
        </div>
      ))}
      {s.sessionType === 'FREE' && s.status !== 'IN_PROGRESS' && (
        <div className="card card-quiet">
          <p className="small">Dati inseriti per prova o per errore? Spostala tra le sedute di prova: non conterà per le proposte.</p>
          {!confirmMark ? <button onClick={() => setConfirmMark(true)}>Segna come seduta di prova</button> : (
            <div className="row"><button className="danger" onClick={async () => { await markSessionAsTest(db, s.id); await onMarked(); }}>Sì, è una prova</button><button onClick={() => setConfirmMark(false)}>Annulla</button></div>
          )}
        </div>
      )}
      <button className="back" onClick={onBack}>Torna allo storico</button>
    </section>
  );
}

function targetLine(p: ExercisePrescription): string {
  if (p.origin === 'USER_ADDED' && p.prescribedSets === 0) return 'Fuori programma: nessun obiettivo prescritto.';
  const what = p.targetDurationS !== null ? `${p.targetDurationS} s` : p.repMin !== null ? `${p.repMin}–${p.repMax} ripetizioni` : 'obiettivo non indicato';
  const sides = p.sidesPerSet.length > 1 ? ' per lato' : '';
  return `Previsto: ${p.prescribedSets} serie da ${what}${sides}${p.targetRir !== null ? `, RIR ${p.targetRir}` : ''}.`;
}

function snapshotLine(c: ConfigurationSnapshot, eq: Map<string, EquipmentItem>): string {
  const where = c.anchor && ANCHOR_NAMES[c.anchor] ? `, ancoraggio ${ANCHOR_NAMES[c.anchor]}` : '';
  const dist = c.distanceCm !== null ? `, ${c.distanceCm} cm dalla porta` : '';
  return bandsLine(c, eq) + where + dist + '.';
}
function bandsLine(c: ConfigurationSnapshot, eq: Map<string, EquipmentItem>): string {
  const bands = c.bandIds.map((id) => {
    const it = eq.get(id);
    if (!it) return 'elastico non più presente nell\'archivio';
    return [it.physicalLabel ?? it.description ?? 'elastico senza etichetta', it.color].filter(Boolean).join(' ');
  });
  return `Elastici usati: ${bands.length ? bands.join(' + ') : 'nessuno'}`;
}

function setLine(x: SetPerformance): string {
  const side = x.side && x.side !== 'BILATERAL' ? ` (${SIDE_NAMES[x.side]})` : '';
  if (x.status === 'NOT_PERFORMED') return `Serie ${x.setIndex}${side}: non eseguita`;
  const value = x.reps !== null ? plural(x.reps, 'ripetizione', 'ripetizioni') : x.durationS !== null ? `${x.durationS} s` : 'valore non registrato';
  const rir = x.rir === null ? 'RIR non rilevato' : `RIR ${x.rir}`;
  const extra = [x.status === 'INTERRUPTED' ? 'interrotta' : null, x.plausibility === 'CONFIRMED_BY_USER' ? 'valore insolito confermato' : null].filter(Boolean);
  return `Serie ${x.setIndex}${side}: ${value}, ${rir}${extra.length ? ` (${extra.join(', ')})` : ''}`;
}

function DeleteTestData({ count, onDone }: { count: number; onDone: (message: string) => Promise<void> }) {
  const [step, setStep] = useState<'idle' | 'confirm' | 'busy'>('idle');
  useBack(step === 'confirm', () => setStep('idle'));
  const [msg, setMsg] = useState<string | null>(null);
  return (
    <div className="card card-quiet">
      <h3>Sedute di prova</h3>
      <p className="small">Le {plural(count, 'seduta', 'sedute')} di prova servono solo per i test. Eliminandole restano intatti profilo, attrezzatura e sedute vere.</p>
      {step === 'idle' && <button onClick={() => { setStep('confirm'); setMsg(null); }}>Elimina le sedute di prova</button>}
      {step === 'confirm' && (
        <>
          <p className="alert alert-warn">Operazione definitiva. Se vuoi conservarle, salva prima un backup.</p>
          <div className="row">
            <button className="danger" onClick={async () => {
              setStep('busy');
              try { const r = await deleteTestData(db); setStep('idle'); await onDone(`Eliminate ${plural(r.sessions, 'seduta', 'sedute')} di prova e ${r.sets} serie. Il resto dei dati è invariato.`); }
              catch (e) { setMsg(`Non eliminato: ${(e as Error).message}.`); setStep('idle'); }
            }}>Sì, elimina</button>
            <button onClick={() => setStep('idle')}>Annulla</button>
          </div>
        </>
      )}
      {msg && <p className="alert" role="status">{msg}</p>}
    </div>
  );
}
