import { useEffect, useState } from 'react';
import { censusStatus, type CensusStatus } from '../data/equipmentRepo';
import { countSessions } from '../data/historyRepo';
import { getCurrentProfile } from '../data/profileRepo';
import { libraryItems } from '../data/libraryRepo';
import { assessmentProgress } from '../data/assessmentRepo';
import { pendingProposal } from '../data/sliceRepo';
import { TYPE_NAMES } from '../domain/equipment';
import type { ProfileVersion } from '../domain/types';
import type { Nav } from './App';
import { db } from './db';
import { plural } from './format';

interface State { census: CensusStatus; profile: ProfileVersion | null; sessions: { real: number; test: number }; pending: boolean; ready: number; probesDone: number; probesTotal: number }

export function HomeScreen({ nav, reminder, hasOpenSession }: { nav: Nav; reminder: boolean; hasOpenSession: boolean }) {
  const [s, setS] = useState<State | null>(null);
  useEffect(() => {
    (async () => setS({ census: await censusStatus(db), profile: await getCurrentProfile(db), sessions: await countSessions(db), pending: !!(await pendingProposal(db)), ready: (await libraryItems(db)).filter((i) => i.status !== 'IN_PREPARATION').length, ...(await probeCounts()) }))();
  }, []);
  if (!s) return null;
  const { census, profile, sessions } = s;
  const censusDone = census.elastics > 0 && census.elasticsWithoutColor === 0 && census.typesToOrder.length === 0;

  return (
    <section className="screen">
      {hasOpenSession ? (
        <div className="card card-accent">
          <h2>Seduta in corso</h2>
          <button className="primary" onClick={() => nav.go('allenamento')}>Continua la seduta</button>
        </div>
      ) : (
        <div className="card card-accent">
          <h2>Allenamento libero</h2>
          <p>{s.pending ? 'C\'è una proposta di progressione per il rematore in attesa della tua decisione.' : `Scegli uno degli esercizi con la scheda pronta (${s.ready}) e registra le serie. Le sedute complete proposte dall'app arriveranno con le prossime fasi.`}</p>
          <div className="row">
            <button className="primary" onClick={() => nav.go('allenamento')}>{s.pending ? 'Vedi la proposta' : 'Allenati'}</button>
            <button onClick={() => nav.go('libreria')}>Libreria</button>
          </div>
        </div>
      )}

      <div className="card">
        <h2>Valutazione ed equilibrio</h2>
        <p>{s.probesDone === 0 ? `${s.probesTotal} prove in 3 fasi, al massimo 3 per volta, per capire dove sei più indietro: l'app le userà per decidere dove insistere.` : s.probesDone < s.probesTotal ? `Valutazione: ${s.probesDone} prove su ${s.probesTotal}.` : 'Valutazione completata: il profilo si aggiorna con le prove ripetute.'}</p>
        <div className="row">
          <button className={s.probesDone < s.probesTotal ? 'primary' : ''} onClick={() => nav.go('valutazione')}>{s.probesDone === 0 ? 'Inizia la valutazione' : 'Valutazione'}</button>
          {s.probesDone > 0 && <button onClick={() => nav.go('equilibrio')}>Equilibrio</button>}
        </div>
      </div>

      {reminder && (
        <div className="card card-warn">
          <h2>Salva un backup</h2>
          <p>L'ultimo backup ha più di 7 giorni o non è mai stato fatto. Se il telefono si guasta o l'app viene disinstallata, i dati successivi all'ultimo backup vanno persi.</p>
          <button className="primary" onClick={() => nav.go('profilo', 'backup')}>Salva backup</button>
        </div>
      )}

      <div className="card">
        <h2>Attrezzatura</h2>
        {census.elastics === 0 ? (
          <>
            <p>Prima di tutto serve il censimento: ogni elastico riceve un'etichetta (E1, E2…) e viene registrato con il suo colore, poi li metti in ordine dal più morbido al più duro.</p>
            <button className="primary" onClick={() => nav.go('profilo', 'attrezzatura')}>Inizia il censimento</button>
          </>
        ) : (
          <>
            <p>{plural(census.elastics, 'elastico censito', 'elastici censiti')}, {plural(census.accessories, 'accessorio', 'accessori')}.</p>
            {census.elasticsWithoutColor > 0 && <p className="todo">Colore da inserire per {plural(census.elasticsWithoutColor, 'elastico', 'elastici')}.</p>}
            {census.typesToOrder.map((t) => <p key={t} className="todo">Da mettere in ordine: {TYPE_NAMES[t].many.toLowerCase()}.</p>)}
            {censusDone && <p className="done">Censimento completo.</p>}
            <button onClick={() => nav.go('profilo', 'attrezzatura')}>{censusDone ? 'Apri attrezzatura' : 'Completa il censimento'}</button>
          </>
        )}
      </div>

      <div className="card">
        <h2>Profilo</h2>
        {profile
          ? <><p className="done">Compilato.</p><button onClick={() => nav.go('profilo', 'dati')}>Apri profilo</button></>
          : <><p>Anno di nascita, altezza ed esperienza di allenamento: servono più avanti per proporre le sedute.</p><button className="primary" onClick={() => nav.go('profilo', 'dati')}>Compila il profilo</button></>}
      </div>

      <div className="card">
        <h2>Storico</h2>
        <p>{sessions.real === 0 ? 'Nessuna seduta di allenamento registrata.' : plural(sessions.real, 'seduta registrata', 'sedute registrate') + '.'}
          {sessions.test > 0 && ` Ci sono anche ${plural(sessions.test, 'seduta di prova', 'sedute di prova')}.`}</p>
        <button onClick={() => nav.go('storico')}>Apri storico</button>
      </div>

    </section>
  );
}

async function probeCounts() {
  const p = await assessmentProgress(db);
  return { probesDone: p.filter((x) => x.done).length, probesTotal: p.length };
}
