// Libreria esercizi: elenco per gruppo, filtro sull'attrezzatura disponibile, scheda completa e segno «provata» (D092).
import { useEffect, useState } from 'react';
import { libraryItems, PROBLEM_REASONS, problemReportText, reportProblem, setExcluded, setTested, withdrawProblem, type LibraryItem, type ProblemReason } from '../data/libraryRepo';
import { matches, searchText } from '../domain/search';
import { shareText } from '../platform';
import { TYPE_NAMES } from '../domain/equipment';
import { GROUP_NAMES, type LibraryGroup } from '../domain/library';
import { db } from './db';
import { useBack } from './back';
import { equipmentText, ExerciseCard, StatusChip } from './ExerciseCard';
import { fmtDateTime, plural } from './format';

const GROUP_ORDER: LibraryGroup[] = ['LEGS', 'PUSH', 'PULL', 'ARMS_SHOULDERS', 'CORE', 'BALANCE', 'MOBILITY', 'CONDITIONING'];

export function LibraryScreen({ version, hasOpenSession, onTrain, onChange }: { version: number; hasOpenSession: boolean; onTrain: (exerciseId: string) => void; onChange: () => Promise<void> }) {
  const [items, setItems] = useState<LibraryItem[] | null>(null);
  const [group, setGroup] = useState<LibraryGroup | 'ALL'>('ALL');
  const [onlyMine, setOnlyMine] = useState(true);
  const [query, setQuery] = useState('');
  const [shared, setShared] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const load = async () => setItems(await libraryItems(db));
  useEffect(() => { load(); }, [version]);
  useBack(openId !== null, () => setOpenId(null));
  if (!items) return null;

  const open = items.find((i) => i.entry.id === openId);
  if (open) return <Detail item={open} hasOpenSession={hasOpenSession} onBack={() => setOpenId(null)} onTrain={onTrain} onChanged={async () => { await load(); await onChange(); }} />;

  const ready = items.filter((i) => i.status !== 'IN_PREPARATION').length;
  const tested = items.filter((i) => i.status === 'TESTED').length;
  const hiddenByMat = onlyMine ? items.filter((i) => i.missing.length === 1 && i.missing[0] === 'YOGA_MAT').length : 0;
  const problems = items.filter((i) => i.status === 'NEEDS_REVIEW').length;
  const searching = query.trim().length > 0;
  const shown = items
    .filter((i) => searching || group === 'ALL' || i.entry.meta.group === group) // la ricerca vale su tutta la libreria
    .filter((i) => !searching || matches(query, searchText(i.entry)))
    .filter((i) => !onlyMine || i.missing.length === 0)
    .sort((a, b) => rank(a) - rank(b) || a.entry.displayName.localeCompare(b.entry.displayName, 'it'));

  return (
    <section className="screen">
      <h2 className="screen-title">Libreria</h2>
      <p className="small muted">{items.length} esercizi · {plural(ready, 'scheda pronta', 'schede pronte')} · {plural(tested, 'provata', 'provate')}</p>
      {problems > 0 && (
        <div className="alert alert-warn small">
          {plural(problems, 'scheda segnalata', 'schede segnalate')} da rivedere.{' '}
          <button className="link" onClick={async () => { const t = await problemReportText(db, __APP_VERSION__); if (t) setShared((await shareText('Segnalazioni FitPRO', t)) === 'copied' ? 'Testo copiato: incollalo nella chat con Claude.' : null); }}>Manda le segnalazioni a Claude</button>
          {shared && <span> {shared}</span>}
        </div>
      )}
      <input className="search" type="search" placeholder="Cerca: nome, muscolo, attrezzo…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Cerca negli esercizi" />
      {!searching && (
        <div className="chips scroll-x">
          <button className="pick" aria-pressed={group === 'ALL'} onClick={() => setGroup('ALL')}>Tutti</button>
          {GROUP_ORDER.map((g) => <button key={g} className="pick" aria-pressed={group === g} onClick={() => setGroup(g)}>{GROUP_NAMES[g]}</button>)}
        </div>
      )}
      <label className="check"><input type="checkbox" checked={onlyMine} onChange={(e) => setOnlyMine(e.target.checked)} /> Solo quelli che posso fare con la mia attrezzatura</label>
      {hiddenByMat > 0 && <p className="alert small">{plural(hiddenByMat, 'esercizio a terra è nascosto', 'esercizi a terra sono nascosti')}: aggiungi il tappetino in Profilo → Attrezzatura.</p>}
      <ul className="list">
        {shown.map((i) => (
          <li key={i.entry.id}>
            <button className="list-item" onClick={() => setOpenId(i.entry.id)}>
              <span className="li-head"><strong>{i.entry.displayName}</strong><span className="row-tight">{i.excluded && <span className="chip chip-excluded">Non proposto</span>}<StatusChip status={i.status} /></span></span>
              <span className="li-sub">{GROUP_NAMES[i.entry.meta.group]} · {i.missing.length ? `manca: ${i.missing.map((t) => TYPE_NAMES[t].one.toLowerCase()).join(', ')}` : equipmentText(i.entry.meta)}</span>
            </button>
          </li>
        ))}
      </ul>
      {shown.length === 0 && <p className="empty">Nessun esercizio con questi filtri.</p>}
    </section>
  );
}

/** Ordine nell'elenco: prima le schede pronte, poi quelle in arrivo. */
const rank = (i: LibraryItem) => (i.status === 'IN_PREPARATION' ? 1 : 0);

function Detail({ item, hasOpenSession, onBack, onTrain, onChanged }: { item: LibraryItem; hasOpenSession: boolean; onBack: () => void; onTrain: (id: string) => void; onChanged: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const ready = item.status !== 'IN_PREPARATION';

  return (
    <section className="screen">
      <button className="back" onClick={onBack}>‹ Libreria</button>
      <ExerciseCard version={item.version} meta={item.entry.meta} mode="full" status={item.status} />
      {ready && item.missing.length === 0 && (
        <button className="primary big" onClick={() => onTrain(item.entry.id)}>{hasOpenSession ? 'Aggiungi alla seduta in corso' : 'Allenati con questo esercizio'}</button>
      )}
      {item.missing.length > 0 && <p className="alert alert-warn small">Per questo esercizio manca: {item.missing.map((t) => TYPE_NAMES[t].one.toLowerCase()).join(', ')}. Se ce l'hai, aggiungilo in Profilo → Attrezzatura.</p>}
      {ready && <Feedback item={item} busy={busy} setBusy={setBusy} onChanged={onChanged} />}
      <div className="card">
        {item.excluded
          ? <><p className="small">Hai chiesto di non vederti proporre questo esercizio: il motore delle sedute lo salterà. Puoi comunque sceglierlo tu.</p><button disabled={busy} onClick={async () => { setBusy(true); try { await setExcluded(db, item.entry.id, false); await onChanged(); } finally { setBusy(false); } }}>Proponimelo di nuovo</button></>
          : <><p className="small">Non vuoi proprio fare questo esercizio? Il motore delle sedute lo salterà e sceglierà un'alternativa.</p><button disabled={busy} onClick={async () => { setBusy(true); try { await setExcluded(db, item.entry.id, true); await onChanged(); } finally { setBusy(false); } }}>Non propormelo</button></>}
      </div>
    </section>
  );
}

function Feedback({ item, busy, setBusy, onChanged }: { item: LibraryItem; busy: boolean; setBusy: (b: boolean) => void; onChanged: () => Promise<void> }) {
  const [reporting, setReporting] = useState(false);
  const [reason, setReason] = useState<ProblemReason | null>(null);
  const [note, setNote] = useState('');
  useBack(reporting, () => setReporting(false));
  const run = async (f: () => Promise<void>) => { setBusy(true); try { await f(); await onChanged(); } finally { setBusy(false); } };
  const reportForm = (
      <div className="panel">
        <p className="small muted">Che cosa non va?</p>
        <div className="chips">{(Object.keys(PROBLEM_REASONS) as ProblemReason[]).map((r) => <button key={r} className="pick" aria-pressed={reason === r} onClick={() => setReason(r)}>{PROBLEM_REASONS[r]}</button>)}</div>
        <label>Dettagli (facoltativi)<textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="es. non capisco dove mettere il piede dietro" /></label>
        <div className="row">
          <button className="primary" disabled={busy || !reason} onClick={() => run(async () => { await reportProblem(db, item.entry.id, reason!, note); setReporting(false); })}>Invia segnalazione</button>
          <button onClick={() => setReporting(false)}>Annulla</button>
        </div>
      </div>
    );
  if (item.status === 'TESTED') return (
    <div className="card"><p className="done small">Provata il {fmtDateTime(item.testedAt)}: istruzioni chiare e impostazione che funziona a casa tua.</p>
      <div className="row"><button disabled={busy} onClick={() => run(() => setTested(db, item.entry.id, false))}>Togli «provata»</button><button disabled={busy} onClick={() => setReporting(true)}>Segnala un problema</button></div>
      {reporting && reportForm}</div>
  );
  if (item.status === 'NEEDS_REVIEW') return (
    <div className="card card-warn"><p className="small"><strong>Da rivedere:</strong> {PROBLEM_REASONS[item.problem!.reason]}{item.problem!.note ? ` — «${item.problem!.note}»` : ''} ({fmtDateTime(item.problem!.at)}). Mandami le segnalazioni dalla Libreria: correggo la scheda e la nuova versione torna «bozza».</p>
      <button disabled={busy} onClick={() => run(() => withdrawProblem(db, item.entry.id))}>Ritira la segnalazione</button></div>
  );
  return (
    <div className="card">
      <p className="small">Dopo averlo fatto almeno una volta: le istruzioni si capiscono e l'impostazione funziona a casa tua?</p>
      <div className="row"><button disabled={busy} onClick={() => run(() => setTested(db, item.entry.id, true))}>Segna come provata</button><button disabled={busy} onClick={() => setReporting(true)}>Segnala un problema</button></div>
      {reporting && reportForm}
    </div>
  );

}
