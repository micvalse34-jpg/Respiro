import { BackupPanel } from './BackupPanel';
import { EquipmentScreen } from './EquipmentScreen';
import { ProfileForm } from './ProfileForm';
import { ToolsPanel } from './ToolsPanel';

export type ProfileTab = 'dati' | 'attrezzatura' | 'backup' | 'strumenti';
const TABS: [ProfileTab, string][] = [['dati', 'Dati personali'], ['attrezzatura', 'Attrezzatura'], ['backup', 'Backup'], ['strumenti', 'Strumenti']];

export function ProfileArea({ tab, onTab, onChange, hasOpenSession, version }: {
  tab: ProfileTab; onTab: (t: ProfileTab) => void; onChange: () => Promise<void>; hasOpenSession: boolean; version: number;
}) {
  return (
    <section className="screen">
      <nav className="tabs" aria-label="Sezioni del profilo">
        {TABS.map(([t, label]) => <button key={t} aria-pressed={tab === t} onClick={() => onTab(t)}>{label}</button>)}
      </nav>
      {tab === 'dati' && <ProfileForm onChange={onChange} />}
      {tab === 'attrezzatura' && <EquipmentScreen onChange={onChange} />}
      {tab === 'backup' && <BackupPanel onChange={onChange} hasOpenSession={hasOpenSession} version={version} />}
      {tab === 'strumenti' && <ToolsPanel onChange={onChange} version={version} />}
      <p className="muted small version">FitPRO {__APP_VERSION__} · build {__BUILD_LABEL__.split('-')[0]}</p>
    </section>
  );
}
