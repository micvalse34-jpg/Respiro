import { useEffect, useState } from 'react';
import { countProfileVersions, getCurrentProfile, saveProfile } from '../data/profileRepo';
import { EXPERIENCE_NAMES, numberOrNull, profileErrors, textOrNull, type ProfileInput } from '../domain/profile';
import type { ExperienceLevel, ProfileVersion } from '../domain/types';
import { db } from './db';
import { fmtDateTime } from './format';

interface Form { birthYear: string; heightCm: string; weightKg: string; experience: string; usualActivities: string; notes: string }
const toForm = (p: ProfileVersion | null): Form => ({
  birthYear: p?.birthYear?.toString() ?? '', heightCm: p?.heightCm?.toString().replace('.', ',') ?? '', weightKg: p?.weightKg?.toString().replace('.', ',') ?? '',
  experience: p?.experience ?? '', usualActivities: p?.usualActivities ?? '', notes: p?.notes ?? '',
});
const toInput = (f: Form): ProfileInput => ({
  birthYear: numberOrNull(f.birthYear), heightCm: numberOrNull(f.heightCm), weightKg: numberOrNull(f.weightKg),
  experience: (f.experience || null) as ExperienceLevel | null, usualActivities: textOrNull(f.usualActivities), notes: textOrNull(f.notes),
});

export function ProfileForm({ onChange }: { onChange: () => Promise<void> }) {
  const [form, setForm] = useState<Form | null>(null);
  const [current, setCurrent] = useState<ProfileVersion | null>(null);
  const [versions, setVersions] = useState(0);
  const [msg, setMsg] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const p = await getCurrentProfile(db);
    setCurrent(p); setForm(toForm(p)); setVersions(await countProfileVersions(db));
  };
  useEffect(() => { load(); }, []);
  if (!form) return null;

  const set = (k: keyof Form) => (e: { target: { value: string } }) => { setForm({ ...form, [k]: e.target.value }); setMsg(null); };
  const save = async () => {
    const input = toInput(form);
    const errors = profileErrors(input);
    if (errors.length) { setMsg({ kind: 'error', text: errors.join(' ') }); return; }
    setBusy(true);
    try {
      const r = await saveProfile(db, input);
      setMsg({ kind: 'ok', text: r.outcome === 'saved' ? `Salvato sul dispositivo alle ${new Date(r.profile.recordedAt).toLocaleTimeString('it-IT')}.` : 'Nessuna modifica da salvare.' });
      await load(); await onChange();
    } catch (e) { setMsg({ kind: 'error', text: `Non salvato: ${(e as Error).message}` }); }
    finally { setBusy(false); }
  };

  return (
    <div className="panel">
      <p className="muted small">Ogni campo è facoltativo: un campo vuoto resta «non indicato», l'app non inventa valori.</p>
      <div className="grid">
        <label>Anno di nascita<input inputMode="numeric" value={form.birthYear} onChange={set('birthYear')} placeholder="es. 1988" /></label>
        <label>Altezza (cm)<input inputMode="decimal" value={form.heightCm} onChange={set('heightCm')} placeholder="es. 178" /></label>
        <label>Peso (kg)<input inputMode="decimal" value={form.weightKg} onChange={set('weightKg')} placeholder="facoltativo" /></label>
      </div>
      <label>Esperienza di allenamento con elastici, pesi o corpo libero strutturato
        <select value={form.experience} onChange={set('experience')}>
          <option value="">Non indicata</option>
          {(Object.keys(EXPERIENCE_NAMES) as ExperienceLevel[]).map((k) => <option key={k} value={k}>{EXPERIENCE_NAMES[k]}</option>)}
        </select>
      </label>
      <label>Attività abituali fuori dall'app<textarea rows={2} value={form.usualActivities} onChange={set('usualActivities')} placeholder="es. yoga 2 volte a settimana, camminate" /></label>
      <label>Note<textarea rows={2} value={form.notes} onChange={set('notes')} /></label>
      <button className="primary big" disabled={busy} onClick={save}>Salva profilo</button>
      {msg && <p className={msg.kind === 'ok' ? 'save saved' : 'save error'} role="status">{msg.text}</p>}
      <p className="muted small">
        {versions === 0 ? 'Profilo non ancora salvato.' : `Ultima modifica: ${fmtDateTime(current!.recordedAt)}. Versioni conservate: ${versions} (le modifiche non cancellano le precedenti).`}
      </p>
      <div className="alert">
        Limitazioni, fastidi e movimenti da evitare non si inseriscono qui: verranno raccolti con domande strutturate insieme ai controlli di sicurezza, nella fase in cui l'app inizierà a proporre le sedute.
      </div>
    </div>
  );
}
