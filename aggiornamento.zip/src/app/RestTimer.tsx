// Timer di recupero a tutto schermo (D101, D111): conto alla rovescia grande, poi conteggio del tempo in più finché
// non tocchi «Inizio la serie». Lo schermo resta acceso durante il recupero; a schermo spento avvisa la notifica di sistema.
import { useEffect, useRef, useState } from 'react';
import type { RestAdvice } from '../domain/rest';
import { REST_STEP_S } from '../domain/rest';
import { restRecord } from '../domain/restRecord';
import type { RestRecord } from '../domain/types';
import { cancelRestEnd, prepareRestAlarm, ringInApp, scheduleRestEnd } from '../restAlarm';

/** setStartedAt: tocco di «Inizio la serie». minimized: ridotto a barra. rung: avviso di fine già dato. */
export interface RestState { startedAt: number; suggestedS: number; addedS: number; reason: string; setStartedAt: number | null; minimized: boolean; rung: boolean; notes: string[] }

const totalMs = (r: RestState) => (r.suggestedS + r.addedS) * 1000;
const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

/** Stato del timer della seduta: un solo recupero alla volta, anche passando da un esercizio all'altro. */
export function useRest() {
  const [rest, setRest] = useState<RestState | null>(null);
  const ref = useRef<RestState | null>(null);
  ref.current = rest;
  const update = (r: RestState | null) => { ref.current = r; setRest(r); };
  return {
    rest,
    /** notes: consigli da vedere durante il recupero (calibrazione, avviso di fastidio). */
    start(a: RestAdvice, notes: string[] = []) {
      const r: RestState = { startedAt: Date.now(), suggestedS: a.seconds, addedS: 0, reason: a.reason, setStartedAt: null, minimized: false, rung: false, notes };
      update(r);
      void prepareRestAlarm().then(() => scheduleRestEnd(r.startedAt + totalMs(r)));
    },
    add() {
      const r = ref.current; if (!r || r.setStartedAt) return;
      const n = { ...r, addedS: r.addedS + REST_STEP_S, rung: false };
      update(n); void scheduleRestEnd(n.startedAt + totalMs(n));
    },
    /** «Inizio la serie»: chiude il recupero e ne fissa la durata reale. */
    startSet() { const r = ref.current; if (!r || r.setStartedAt) return; update({ ...r, setStartedAt: Date.now(), minimized: true }); void cancelRestEnd(); },
    rang() { const r = ref.current; if (r && !r.rung) update({ ...r, rung: true }); },
    minimize(v: boolean) { const r = ref.current; if (r) update({ ...r, minimized: v }); },
    close() { update(null); void cancelRestEnd(); },
    /** Dato da salvare con la serie che si sta registrando (misurato col tocco o stimato). */
    record(set: { reps: number | null; durationS: number | null }): RestRecord | null {
      const r = ref.current; if (!r) return null;
      return restRecord({ startedAt: r.startedAt, suggestedS: r.suggestedS, addedS: r.addedS, setStartedAt: r.setStartedAt }, Date.now(), set);
    },
  };
}

/** Tiene acceso lo schermo durante il recupero, dove il sistema lo consente. */
function useWakeLock(active: boolean) {
  useEffect(() => {
    if (!active) return;
    let lock: { release: () => Promise<void> } | null = null;
    const nav = navigator as unknown as { wakeLock?: { request: (t: 'screen') => Promise<{ release: () => Promise<void> }> } };
    nav.wakeLock?.request('screen').then((l) => { lock = l; }).catch(() => { /* non disponibile */ });
    return () => { void lock?.release().catch(() => undefined); };
  }, [active]);
}

export function RestView({ rest, onAdd, onStartSet, onRang, onMinimize }: {
  rest: RestState; onAdd: () => void; onStartSet: () => void; onRang: () => void; onMinimize: (v: boolean) => void;
}) {
  const [now, setNow] = useState(Date.now());
  const running = rest.setStartedAt === null;
  useEffect(() => { if (!running) return; const t = window.setInterval(() => setNow(Date.now()), 250); return () => window.clearInterval(t); }, [running]);
  useWakeLock(running && !rest.minimized);
  const endAt = rest.startedAt + totalMs(rest);
  useEffect(() => {
    if (!running || rest.rung || endAt - now > 800) return;
    if (document.visibilityState === 'visible') { void cancelRestEnd(); void ringInApp(); }
    onRang(); // a schermo spento ha già suonato la notifica di sistema
  }, [now, running, rest.rung, endAt]);
  if (!running) return null;
  const remaining = Math.ceil((endAt - now) / 1000);
  const over = remaining <= 0;
  const shown = over ? `+${fmt(Math.floor((now - endAt) / 1000))}` : fmt(remaining);
  const progress = Math.min(1, (now - rest.startedAt) / totalMs(rest));

  if (rest.minimized) return (
    <div className={`rest-bar${over ? ' done' : ''}`} role="timer" aria-live="polite">
      <button className="rest-main as-link" onClick={() => onMinimize(false)}><span className="rest-time">{shown}</span><span className="small">{over ? 'Recupero finito' : 'Recupero'} · tocca per ingrandire</span></button>
      <button className="primary" onClick={onStartSet}>Inizio</button>
    </div>
  );
  return (
    <div className={`rest-full${over ? ' done' : ''}`} role="timer" aria-live="polite">
      <p className="rest-label">{over ? 'Recupero finito' : 'Recupero'}</p>
      <div className="rest-big">{shown}</div>
      <div className="rest-progress" aria-hidden="true"><span style={{ width: `${Math.round(progress * 100)}%` }} /></div>
      <p className="rest-reason">{rest.reason} · suggerito {fmt(rest.suggestedS)}{rest.addedS ? ` + ${rest.addedS} s` : ''}</p>
      {rest.notes.map((n) => <p key={n} className="rest-note">{n}</p>)}
      <button className="rest-go" onClick={onStartSet}>Inizio la serie</button>
      <div className="rest-row">
        {!over && <button onClick={onAdd}>+30 s</button>}
        <button onClick={() => onMinimize(true)}>Riduci</button>
      </div>
    </div>
  );
}
