import { useEffect, useMemo, useState } from 'react';
import { currentOrderings, listEquipment, rankOf } from '../data/equipmentRepo';
import { closeSession, getOpenSessions, getSessionDetail, recordSet, resumePoint, startPocSession, type SessionDetail } from '../data/repository';
import { benchmarkDurability, benchmarkHistory, fullReport, journalCheck, migrationSelfTest, migrationV3SelfTest, requestPersistence } from '../data/diagnostics';
import { journalAppend, journalClear } from '../data/journal';
import { uuidv7 } from '../domain/ids';
import type { Side } from '../domain/types';
import { exportTextFile, isNativeApp } from '../platform';
import { db } from './db';
import { fmtDateTime } from './format';
import { runSave, type SaveState } from './saveState';

/** Strumenti di verifica: seduta di prova (per i test su telefono) e diagnostica. Non fanno parte dell'uso quotidiano. */
export function ToolsPanel({ onChange, version }: { onChange: () => Promise<void>; version: number }) {
  const [active, setActive] = useState<SessionDetail | null | undefined>(undefined);
  const [names, setNames] = useState<Map<string, string>>(new Map());
  const [closedNotice, setClosedNotice] = useState(false);
  const load = async () => {
    const open = await getOpenSessions(db);
    setActive(open.length ? await getSessionDetail(db, open[0]!.id) : null);
    setNames(new Map((await db.exercises.toArray()).map((e) => [e.id, e.canonicalName])));
  };
  useEffect(() => { load(); }, [version]);
  if (active === undefined) return null;
  return (
    <div className="panel">
      <h3>Seduta di prova</h3>
      <p className="small muted">Serve per i test sul telefono e per vedere come appare lo Storico. Le sedute di prova sono marcate come tali e si possono eliminare dallo Storico.</p>
      <TestSession active={active} names={names} onChange={async () => { await load(); await onChange(); }} onClosed={async () => { setClosedNotice(true); await load(); await onChange(); }} />
      {closedNotice && !active && <p className="alert">Seduta chiusa: la trovi nello Storico (attiva «Mostra anche le sedute di prova»).</p>}
      <Diagnostics />
    </div>
  );
}

function TestSession({ active, names, onChange, onClosed }: { active: SessionDetail | null; names: Map<string, string>; onChange: () => Promise<void>; onClosed: () => Promise<void> }) {
  const point = useMemo(() => (active ? resumePoint(active) : null), [active]);
  const [presId, setPresId] = useState('');
  const [setIndex, setSetIndex] = useState(1);
  const [side, setSide] = useState<Side>('BILATERAL');
  const [value, setValue] = useState('10');
  const [rir, setRir] = useState('');
  const [interrupted, setInterrupted] = useState(false);
  const [attemptId, setAttemptId] = useState(uuidv7());
  const [save, setSave] = useState<SaveState>({ kind: 'idle' });

  useEffect(() => { if (point) { setPresId(point.prescriptionId); setSetIndex(point.setIndex); setSide(point.side); } }, [point]);

  if (!active) {
    return <button className="primary big" onClick={async () => {
      // Se gli elastici a tubo sono censiti e ordinati, la seduta di prova registra il più morbido nello snapshot.
      const tubes = (await listEquipment(db)).filter((i) => i.type === 'RESISTANCE_BAND');
      const o = (await currentOrderings(db)).RESISTANCE_BAND;
      const softest = tubes.find((t) => rankOf(t.id, o, tubes) === 1);
      await startPocSession(db, softest ? [softest.id] : []);
      await onChange();
    }}>Inizia seduta di prova</button>;
  }
  const pres = active.prescriptions.find((p) => p.id === presId) ?? active.prescriptions[0]!;
  const isDuration = pres.targetDurationS !== null;
  const done = active.sets.filter((s) => s.status !== 'NOT_PERFORMED').length;
  const fresh = () => setAttemptId(uuidv7());

  const submit = async (confirmedImplausible = false) => {
    const n = value.trim() === '' ? null : Number(value);
    const input = {
      id: attemptId, sessionId: active.session.id, prescriptionId: pres.id, setIndex, side,
      status: interrupted ? 'INTERRUPTED' as const : 'PERFORMED' as const,
      reps: isDuration ? null : n, durationS: isDuration ? n : null,
      rir: rir.trim() === '' ? null : Number(rir), rpe: null, techniqueQuality: null, discomfort: null, confirmedImplausible,
    };
    const r = await runSave(attemptId, () => recordSet(db, input), setSave);
    if (r) { journalAppend(r.set.id); fresh(); setInterrupted(false); await onChange(); } // giornale: solo dopo il commit
  };

  return (
    <div className="card">
      <p className="muted small">Seduta di prova del {fmtDateTime(active.session.startedAt)}, serie registrate: {done}</p>
      <label>Esercizio
        <select value={pres.id} onChange={(e) => { setPresId(e.target.value); fresh(); }}>
          {active.prescriptions.map((p) => <option key={p.id} value={p.id}>{p.order}. {names.get(p.exerciseId) ?? p.exerciseId}{p.origin === 'USER_ADDED' ? ' (aggiunto)' : ''}</option>)}
        </select>
      </label>
      <div className="grid">
        <label>Serie<input inputMode="numeric" value={setIndex} onChange={(e) => { setSetIndex(Number(e.target.value) || 1); fresh(); }} /></label>
        <label>Lato
          <select value={side} onChange={(e) => { setSide(e.target.value as Side); fresh(); }}>
            {pres.sidesPerSet.map((s) => <option key={s} value={s}>{s === 'BILATERAL' ? 'Bilaterale' : s === 'LEFT' ? 'Sinistro' : 'Destro'}</option>)}
          </select>
        </label>
        <label>{isDuration ? 'Durata (s)' : 'Ripetizioni'}<input inputMode="numeric" value={value} onChange={(e) => { setValue(e.target.value); fresh(); }} /></label>
        <label>RIR (vuoto = non rilevato)<input inputMode="numeric" value={rir} onChange={(e) => { setRir(e.target.value); fresh(); }} /></label>
      </div>
      <label className="check"><input type="checkbox" checked={interrupted} onChange={(e) => { setInterrupted(e.target.checked); fresh(); }} /> Serie interrotta</label>
      <button className="primary big" disabled={save.kind === 'saving'} onClick={() => submit()}>Registra serie</button>
      <SaveIndicator state={save} onConfirm={() => submit(true)} />
      <button className="secondary" onClick={async () => { await closeSession(db, active.session.id, 'FINISHED_BY_USER'); await onClosed(); }}>Chiudi seduta</button>
    </div>
  );
}

function SaveIndicator({ state, onConfirm }: { state: SaveState; onConfirm: () => void }) {
  if (state.kind === 'idle') return null;
  if (state.kind === 'saving') return <p className="save saving" role="status">Salvataggio in corso…</p>;
  if (state.kind === 'saved') return <p className="save saved" role="status">Salvato sul dispositivo alle {new Date(state.at).toLocaleTimeString('it-IT')}</p>;
  if (state.code === 'IMPLAUSIBLE_VALUE') return <p className="save error" role="alert">Valore insolito, non salvato. <button className="link" onClick={onConfirm}>Confermo il valore</button> oppure correggilo.</p>;
  return <p className="save error" role="alert">Non salvato: {state.message}. I dati del modulo sono ancora qui: riprova.</p>;
}

function Diagnostics() {
  const [out, setOut] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const run = async (label: string, fn: () => Promise<unknown>) => {
    setBusy(label);
    try { const r = await fn(); setOut(JSON.stringify({ test: label, at: new Date().toISOString(), result: r }, null, 2)); }
    catch (e) { setOut(JSON.stringify({ test: label, error: (e as Error).message }, null, 2)); }
    finally { setBusy(null); }
  };
  const buttons: [string, () => Promise<unknown>][] = [
    ['Report completo', () => fullReport(db)],
    ['Autotest migrazione v2→v3 (DM07)', () => migrationV3SelfTest()],
    ['Autotest migrazione v1→v3', () => migrationSelfTest()],
    ['Giornale serie confermate', () => journalCheck(db)],
    ['Latenza di salvataggio', () => benchmarkDurability(50)],
    ['Prestazioni con 5 anni di dati', () => benchmarkHistory(5)],
    ['Richiedi storage persistente', async () => ({ granted: await requestPersistence() })],
  ];
  return (
    <details className="card card-quiet">
      <summary>Diagnostica</summary>
      <div className="stack">
        {buttons.map(([l, f]) => <button key={l} disabled={!!busy} onClick={() => run(l, f)}>{busy === l ? 'In esecuzione…' : l}</button>)}
        <button className="secondary" disabled={!!busy} onClick={() => { journalClear(); setOut('Giornale azzerato.'); }}>Azzera giornale di prova</button>
      </div>
      {out && (<>
        <pre className="out">{out}</pre>
        <div className="row">
          <button onClick={() => navigator.clipboard?.writeText(out)}>Copia</button>
          <button onClick={() => exportTextFile(`fitpro-diagnostica-${Date.now()}.json`, out, isNativeApp() ? 'share' : 'download').catch(() => undefined)}>{isNativeApp() ? 'Condividi' : 'Scarica'}</button>
        </div>
      </>)}
    </details>
  );
}
