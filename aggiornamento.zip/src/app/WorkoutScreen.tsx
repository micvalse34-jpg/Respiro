// Allenamento: seduta libera con gli esercizi della libreria che hanno la scheda pronta (D098).
// Il Band Row conserva le regole della slice (prescrizione di default, controllo di elastici e ancoraggio, proposta a fine seduta).
import { useEffect, useMemo, useRef, useState } from 'react';
import { addFreeExercise, BAND_ROW_ID, isCalibrating, startFreeSession } from '../data/freeSessionRepo';
import { catalogEntry } from '../data/libraryCatalog';
import { libraryItems, type LibraryItem } from '../data/libraryRepo';
import { closeSession, getOpenSessions, getSessionDetail, recordSet, type SessionDetail } from '../data/repository';
import { bandLabel, decideProposal, evaluateBandRowSession, pendingProposal } from '../data/sliceRepo';
import { calibrationHint } from '../domain/calibration';
import { compare } from '../domain/comparability';
import { suggestRest } from '../domain/rest';
import { uuidv7 } from '../domain/ids';
import type { ExerciseMeta } from '../domain/library';
import type { ConfigurationSnapshot, ExercisePrescription, ExerciseVersion, ProgressionEvent, RejectionReason, SetPerformance, Side } from '../domain/types';
import { db } from './db';
import { useBack } from './back';
import { ExerciseCard } from './ExerciseCard';
import { cfgText, ExercisePicker, SetupForm, type Labeler } from './ExerciseSetup';
import { RestView, useRest } from './RestTimer';
import { runSave, type SaveState } from './saveState';
import { prepareRestAlarm } from '../restAlarm';
import type { RestRecord } from '../domain/types';

interface Loaded { open: SessionDetail | null; otherOpen: boolean; label: Labeler; items: LibraryItem[]; versions: Map<string, ExerciseVersion> }

export function WorkoutScreen({ onChange, version, onTools, initialExercise, onInitialUsed }: {
  onChange: () => Promise<void>; version: number; onTools: () => void; initialExercise: string | null; onInitialUsed: () => void;
}) {
  const [state, setState] = useState<Loaded | null>(null);
  const [result, setResult] = useState<{ event: ProgressionEvent | null; repeatedDiscomfort: boolean } | null>(null);
  const load = async () => {
    const open = await getOpenSessions(db);
    const free = open.find((s) => s.sessionType === 'FREE');
    const detail = free ? await getSessionDetail(db, free.id) : null;
    const versions = new Map((await db.exerciseVersions.bulkGet(detail?.prescriptions.map((p) => p.exerciseVersionId) ?? [])).filter(Boolean).map((v) => [v!.id, v!]));
    setState({ open: detail, otherOpen: !free && open.length > 0, label: await bandLabel(db), items: await libraryItems(db), versions });
  };
  useEffect(() => { load(); }, [version]);
  if (!state) return null;
  const { open, otherOpen, label, items } = state;

  return (
    <section className="screen">
      <h2 className="screen-title">Allenamento</h2>
      {result ? (
        <ResultView result={result} label={label} onDone={async () => { setResult(null); await load(); }} onChange={onChange} />
      ) : open ? (
        <SessionView detail={open} versions={state.versions} items={items} label={label} initialExercise={initialExercise} onInitialUsed={onInitialUsed}
          onChange={async () => { await load(); await onChange(); }}
          onClosed={async (sessionId) => { setResult(await evaluateBandRowSession(db, sessionId)); await onChange(); }} />
      ) : otherOpen ? (
        <div className="card card-warn"><p>C'è una seduta di prova ancora aperta. Chiudila prima di iniziare l'allenamento.</p><button onClick={onTools}>Vai alla seduta di prova</button></div>
      ) : (
        <StartView items={items} label={label} initialExercise={initialExercise} onInitialUsed={onInitialUsed}
          onStarted={async () => { await load(); await onChange(); }} onChange={onChange} />
      )}
    </section>
  );
}

const metaOf = (exerciseId: string, v: ExerciseVersion | undefined): ExerciseMeta => v?.meta ?? catalogEntry(exerciseId)!.meta;
const nameOf = (exerciseId: string) => catalogEntry(exerciseId)?.displayName ?? exerciseId;

function StartView({ items, label, initialExercise, onInitialUsed, onStarted, onChange }: {
  items: LibraryItem[]; label: Labeler; initialExercise: string | null; onInitialUsed: () => void; onStarted: () => Promise<void>; onChange: () => Promise<void>;
}) {
  const pick = (id: string | null) => items.find((i) => i.entry.id === id && i.status !== 'IN_PREPARATION' && i.missing.length === 0) ? id : null;
  const [chosen, setChosen] = useState<string | null>(pick(initialExercise));
  const [pending, setPending] = useState<ProgressionEvent | null>(null);
  useEffect(() => { if (initialExercise) onInitialUsed(); pendingProposal(db).then(setPending); }, []);
  useBack(chosen !== null, () => setChosen(null));
  const item = items.find((i) => i.entry.id === chosen);
  return (
    <>
      {pending && !chosen && <ProposalCard event={pending} label={label} onDecided={async () => { setPending(await pendingProposal(db)); await onChange(); }} />}
      {!item ? (
        <ExercisePicker items={items} exclude={[]} title="Scegli l'esercizio" onPick={setChosen} />
      ) : (
        <>
          <ExerciseCard version={item.version} meta={item.entry.meta} mode="compact" status={item.status} />
          <div className="card">
            <div className="li-head"><h3>Prepara la seduta</h3><button className="link" onClick={() => setChosen(null)}>Cambia esercizio</button></div>
            <p className="small">{goalText(item.entry.id, item.entry.meta, item.entry.meta.defaults.sets[1])}</p>
            <SetupForm exerciseId={item.entry.id} meta={item.entry.meta} label={label} submitLabel="Inizia"
              onSubmit={async (cfg, ok) => { await startFreeSession(db, { exerciseId: item.entry.id, config: cfg }, ok); void prepareRestAlarm(); await onStarted(); }} />
          </div>
        </>
      )}
    </>
  );
}

function goalText(exerciseId: string, m: ExerciseMeta, sets: number): string {
  const per = m.unilateral || m.repsPerSide ? ' per lato' : '';
  const amount = m.measure === 'DURATION' ? `${m.defaults.durationS![0]}–${m.defaults.durationS![1]} secondi${per}` : `${m.defaults.reps![0]}–${m.defaults.reps![1]} ripetizioni${per}`;
  const rir = m.effort !== 'RIR' ? '' : exerciseId === BAND_ROW_ID ? ', fermandoti con 2–3 ancora possibili' : `, fermandoti con ${m.defaults.rir![0]}–${m.defaults.rir![1]} ancora possibili`;
  return `${sets} serie da ${amount}${rir}.`;
}

/** Unità di lavoro prescritte (serie × lati) e registrate (eseguite o interrotte). */
const unitsOf = (p: ExercisePrescription) => p.prescribedSets * p.sidesPerSet.length;
const workedOf = (p: ExercisePrescription, sets: SetPerformance[]) => sets.filter((s) => s.prescriptionId === p.id && s.status !== 'NOT_PERFORMED');

function SessionView({ detail, versions, items, label, initialExercise, onInitialUsed, onChange, onClosed }: {
  detail: SessionDetail; versions: Map<string, ExerciseVersion>; items: LibraryItem[]; label: Labeler; initialExercise: string | null; onInitialUsed: () => void;
  onChange: () => Promise<void>; onClosed: (sessionId: string) => Promise<void>;
}) {
  const ps = detail.prescriptions;
  const inSession = ps.map((p) => p.exerciseId);
  const firstOpen = ps.find((p) => workedOf(p, detail.sets).length < unitsOf(p)) ?? ps[ps.length - 1]!;
  const [activeId, setActiveId] = useState(firstOpen.id);
  const [adding, setAdding] = useState<'pick' | string | null>(null);
  const [confirmClose, setConfirmClose] = useState(false);
  const rest = useRest();
  useBack(adding !== null, () => setAdding(null));
  useBack(confirmClose, () => setConfirmClose(false));
  useEffect(() => {
    if (!initialExercise) return;
    onInitialUsed();
    const p = ps.find((x) => x.exerciseId === initialExercise);
    if (p) setActiveId(p.id); else if (items.some((i) => i.entry.id === initialExercise && i.status !== 'IN_PREPARATION' && i.missing.length === 0)) setAdding(initialExercise);
  }, []);
  const active = ps.find((p) => p.id === activeId) ?? firstOpen;
  const ver = versions.get(active.exerciseVersionId);
  const meta = metaOf(active.exerciseId, ver);
  const status = items.find((i) => i.entry.id === active.exerciseId)?.status ?? 'DRAFT';
  const missingUnits = ps.reduce((n, p) => n + Math.max(0, unitsOf(p) - workedOf(p, detail.sets).length), 0);
  const closeNow = async () => { rest.close(); await closeSession(db, detail.session.id, 'FINISHED_BY_USER'); await onClosed(detail.session.id); };
  const addItem = typeof adding === 'string' && adding !== 'pick' ? items.find((i) => i.entry.id === adding) : undefined;

  return (
    <>
      {ps.length > 1 && (
        <div className="chips scroll-x" role="tablist" aria-label="Esercizi della seduta">
          {ps.map((p) => (
            <button key={p.id} className="pick" role="tab" aria-pressed={p.id === active.id} onClick={() => { setActiveId(p.id); setAdding(null); }}>
              {nameOf(p.exerciseId)} <span className="count">{workedOf(p, detail.sets).length}/{unitsOf(p)}</span>
            </button>
          ))}
        </div>
      )}
      {adding === 'pick' ? (
        <ExercisePicker items={items} exclude={inSession} title="Aggiungi un esercizio" onPick={setAdding} onCancel={() => setAdding(null)} />
      ) : addItem ? (
        <div className="card">
          <div className="li-head"><h3>{addItem.entry.displayName}</h3><button className="link" onClick={() => setAdding('pick')}>Cambia</button></div>
          <p className="small">{goalText(addItem.entry.id, addItem.entry.meta, addItem.entry.meta.defaults.sets[1])}</p>
          <SetupForm exerciseId={addItem.entry.id} meta={addItem.entry.meta} label={label} submitLabel="Aggiungi alla seduta" onCancel={() => setAdding(null)}
            onSubmit={async (cfg, ok) => { const p = await addFreeExercise(db, detail.session.id, { exerciseId: addItem.entry.id, config: cfg }, ok); setAdding(null); setActiveId(p.id); await onChange(); }} />
        </div>
      ) : (
        <>
          {ver?.content && <ExerciseCard version={ver} meta={meta} mode="compact" status={status} />}
          <SetEntry key={active.id} p={active} meta={meta} sets={detail.sets} label={label} onChange={onChange} restRecord={rest.record} onSaved={(a, notes) => (a ? rest.start(a, notes) : rest.close())} />
          <button className="secondary" onClick={() => setAdding('pick')}>+ Aggiungi un esercizio</button>
        </>
      )}
      {!adding && (!confirmClose
        ? <button className={missingUnits === 0 ? 'primary' : 'secondary'} onClick={() => (missingUnits === 0 ? closeNow() : setConfirmClose(true))}>Chiudi seduta</button>
        : <div className="card card-warn"><p className="small">Mancano {missingUnits} serie rispetto all'obiettivo. Chiudere comunque? Quelle mancanti risulteranno non eseguite.</p>
            <div className="row"><button onClick={closeNow}>Sì, chiudi</button><button onClick={() => setConfirmClose(false)}>No</button></div></div>)}
      {rest.rest && rest.rest.setStartedAt === null && <>{rest.rest.minimized && <div className="rest-spacer" aria-hidden="true" />}<RestView rest={rest.rest} onAdd={rest.add} onStartSet={rest.startSet} onRang={rest.rang} onMinimize={rest.minimize} /></>}
    </>
  );
}

/** Prossima serie e lato: negli unilaterali si registra sinistro poi destro, poi la serie successiva. */
function nextPosition(p: ExercisePrescription, worked: SetPerformance[]): { index: number; side: Side } {
  const max = Math.max(0, ...worked.map((s) => s.setIndex));
  if (p.sidesPerSet.length === 1) return { index: max + 1, side: 'BILATERAL' };
  if (max === 0) return { index: 1, side: 'LEFT' };
  const at = worked.filter((s) => s.setIndex === max);
  if (at.some((s) => s.side === 'LEFT') && !at.some((s) => s.side === 'RIGHT')) return { index: max, side: 'RIGHT' };
  if (at.some((s) => s.side === 'RIGHT') && !at.some((s) => s.side === 'LEFT')) return { index: max, side: 'LEFT' };
  return { index: max + 1, side: 'LEFT' };
}

const RIR_OPTIONS: [number | null, string][] = [[0, '0'], [1, '1'], [2, '2'], [3, '3'], [4, '4'], [5, '5+'], [null, 'Non so']];
const TECH: [SetPerformance['techniqueQuality'], string][] = [['GOOD', 'Buona'], ['ACCEPTABLE', 'Accettabile'], ['POOR', 'Scarsa']];
const SIDE_NAMES: Record<Side, string> = { LEFT: 'sinistro', RIGHT: 'destro', BILATERAL: '' };

function SetEntry({ p, meta, sets, label, onChange, restRecord, onSaved }: {
  p: ExercisePrescription; meta: ExerciseMeta; sets: SetPerformance[]; label: Labeler; onChange: () => Promise<void>;
  restRecord: (set: { reps: number | null; durationS: number | null }) => RestRecord | null; onSaved: (advice: ReturnType<typeof suggestRest> | null, notes: string[]) => void;
}) {
  const worked = workedOf(p, sets).sort((a, b) => a.performedAt.localeCompare(b.performedAt));
  const last = worked[worked.length - 1];
  const pos = nextPosition(p, worked);
  const duration = meta.measure === 'DURATION';
  const usesRir = meta.effort === 'RIR';
  const lastCfg = last ? last.configurationSnapshot : p.configurationSnapshot;
  const defaultValue = duration ? (last?.durationS ?? meta.defaults.durationS?.[0] ?? 30) : (last?.reps ?? (p.exerciseId === BAND_ROW_ID ? 10 : Math.round(((meta.defaults.reps?.[0] ?? 8) + (meta.defaults.reps?.[1] ?? 12)) / 2)));
  const [cfg, setCfg] = useState<ConfigurationSnapshot | null>(lastCfg);
  const [changing, setChanging] = useState(false);
  useBack(changing, () => setChanging(false));
  const [side, setSide] = useState<Side>(pos.side);
  const [value, setValue] = useState(defaultValue);
  const [rir, setRir] = useState<number | null | undefined>(undefined);
  const [tech, setTech] = useState<SetPerformance['techniqueQuality']>(null);
  const [discomfort, setDiscomfort] = useState(false);
  const [interrupted, setInterrupted] = useState(false);
  const [attemptId, setAttemptId] = useState(uuidv7());
  const [save, setSave] = useState<SaveState>({ kind: 'idle' });
  const [notice, setNotice] = useState<string | null>(null);
  const [hint, setHint] = useState<string | null>(null);
  const [calibrating, setCalibrating] = useState(false);
  useEffect(() => { if (meta.setup !== 'NONE') isCalibrating(db, p.exerciseId, p.sessionId).then(setCalibrating); }, [p.id]);
  const changed = useMemo(() => meta.setup === 'TUBE_DOOR' && cfg && p.configurationSnapshot && (compare(cfg, p.configurationSnapshot) !== 'A' || cfg.distanceCm !== p.configurationSnapshot.distanceCm), [cfg, p, meta.setup]);
  const touch = () => setAttemptId(uuidv7());
  useEffect(() => { setSide(pos.side); }, [pos.index, pos.side]);
  const step = duration ? 5 : 1;
  const canSave = save.kind !== 'saving' && (!usesRir || rir !== undefined);
  const setsTotal = p.prescribedSets;

  const submit = async (confirmedImplausible = false) => {
    const input = {
      id: attemptId, sessionId: p.sessionId, prescriptionId: p.id, setIndex: pos.index, side,
      status: interrupted ? 'INTERRUPTED' as const : 'PERFORMED' as const,
      reps: duration ? null : value, durationS: duration ? value : null, rir: usesRir ? rir ?? null : null, rpe: null,
      techniqueQuality: tech, discomfort, confirmedImplausible, configurationSnapshot: meta.setup === 'NONE' ? null : cfg,
      rest: restRecord({ reps: duration ? null : value, durationS: duration ? value : null }),
    };
    const r = await runSave(attemptId, () => recordSet(db, input), setSave);
    if (r) {
      const next = nextPosition(p, [...worked, r.set]);
      const hintText = calibrating ? calibrationHint(meta, p, r.set)?.text ?? null : null;
      const noticeText = discomfort ? `Hai segnalato un fastidio. Se è un dolore che aumenta, insolito o forte, interrompi l'esercizio.${p.exerciseId === BAND_ROW_ID ? ' Oggi non ti verrà proposto di aumentare la difficoltà.' : ''}` : null;
      // anche dopo l'ultima serie: recupero prima del prossimo esercizio; i consigli si vedono dentro il timer
      onSaved(suggestRest(meta, { side: r.set.side, rir: r.set.rir }, next.side), [noticeText, hintText].filter((x): x is string => !!x));
      setHint(hintText);
      setNotice(noticeText);
      touch(); setRir(undefined); setTech(null); setDiscomfort(false); setInterrupted(false);
      await onChange();
    }
  };

  return (
    <div className="card card-accent">
      <div className="li-head">
        <h3>Serie {pos.index}{pos.index <= setsTotal ? ` di ${setsTotal}` : ' (in più)'}{side !== 'BILATERAL' ? ` · lato ${SIDE_NAMES[side]}` : ''}</h3>
        <span className="muted small">{targetShort(p, meta)}</span>
      </div>
      {meta.setup !== 'NONE' && (!changing ? (
        <p className="small">{cfgText(cfg, label)}{changed ? ' (cambiata durante la seduta)' : ''}. <button className="link" onClick={() => setChanging(true)}>Cambia</button></p>
      ) : (
        <SetupForm exerciseId={p.exerciseId} meta={meta} label={label} initial={cfg} submitLabel="Usa per le prossime serie" onCancel={() => setChanging(false)}
          onSubmit={async (c) => { setCfg(c); setChanging(false); touch(); setNotice(p.exerciseId === BAND_ROW_ID ? 'Le prossime serie useranno la nuova configurazione. Questa seduta non sarà confrontabile per le proposte.' : 'Le prossime serie useranno la nuova configurazione.'); }} />
      ))}
      {p.sidesPerSet.length > 1 && (
        <div className="chips">{(['LEFT', 'RIGHT'] as Side[]).map((s) => <button key={s} className="pick" aria-pressed={side === s} onClick={() => { setSide(s); touch(); }}>Lato {SIDE_NAMES[s]}</button>)}</div>
      )}
      <div className="stepper">
        <button aria-label={duration ? 'Cinque secondi in meno' : 'Una ripetizione in meno'} onClick={() => { setValue(Math.max(0, value - step)); touch(); }}>−</button>
        <label>{duration ? 'Secondi' : meta.repsPerSide ? 'Ripetizioni per lato' : 'Ripetizioni'}<input inputMode="numeric" value={value} onChange={(e) => { setValue(Number(e.target.value.replace(/\D/g, '')) || 0); touch(); }} /></label>
        <button aria-label={duration ? 'Cinque secondi in più' : 'Una ripetizione in più'} onClick={() => { setValue(value + step); touch(); }}>+</button>
      </div>
      {duration && <Stopwatch onStop={(s) => { setValue(s); touch(); }} />}
      {usesRir && (
        <>
          <p className="small muted">Quante ripetizioni avresti potuto fare ancora (RIR)?</p>
          <div className="chips">{RIR_OPTIONS.map(([v, l]) => <button key={l} className="pick" aria-pressed={rir === v} onClick={() => { setRir(v); touch(); }}>{l}</button>)}</div>
        </>
      )}
      <p className="small muted">Tecnica (facoltativa)</p>
      <div className="chips">{TECH.map(([v, l]) => <button key={l} className="pick" aria-pressed={tech === v} onClick={() => { setTech(tech === v ? null : v); touch(); }}>{l}</button>)}</div>
      <label className="check"><input type="checkbox" checked={discomfort} onChange={(e) => { setDiscomfort(e.target.checked); touch(); }} /> Ho sentito fastidio o dolore</label>
      <label className="check"><input type="checkbox" checked={interrupted} onChange={(e) => { setInterrupted(e.target.checked); touch(); }} /> Ho interrotto la serie</label>
      <button className="primary big" disabled={!canSave} onClick={() => submit()}>{usesRir && rir === undefined ? 'Indica il RIR per registrare' : 'Registra serie'}</button>
      <SaveIndicator state={save} onConfirm={() => submit(true)} />
      {notice && <p className="alert alert-warn">{notice}</p>}
      {hint && <p className="hint">{hint}</p>}
      {worked.length > 0 && (
        <ol className="sets">{worked.map((s) => (
          <li key={s.id}>Serie {s.setIndex}{s.side && s.side !== 'BILATERAL' ? ` (${SIDE_NAMES[s.side]})` : ''}: {s.durationS !== null ? `${s.durationS} secondi` : `${s.reps} ripetizioni`}
            {usesRir ? `, ${s.rir === null ? 'RIR non indicato' : `RIR ${s.rir === 5 ? '5+' : s.rir}`}` : ''}{s.discomfort ? ', fastidio' : ''}{s.status === 'INTERRUPTED' ? ', interrotta' : ''}</li>
        ))}</ol>
      )}
    </div>
  );
}

function targetShort(p: ExercisePrescription, m: ExerciseMeta): string {
  const amount = m.measure === 'DURATION' ? `${m.defaults.durationS![0]}–${m.defaults.durationS![1]} s` : `${p.repMin ?? m.defaults.reps![0]}–${p.repMax ?? m.defaults.reps![1]}`;
  const rir = m.effort !== 'RIR' ? '' : p.exerciseId === BAND_ROW_ID ? ', RIR 2–3' : `, RIR ${m.defaults.rir![0]}–${m.defaults.rir![1]}`;
  return `obiettivo ${amount}${rir}`;
}

/** Cronometro per gli esercizi a tempo: allo stop riporta i secondi nel campo, che resta modificabile. */
function Stopwatch({ onStop }: { onStop: (seconds: number) => void }) {
  const [start, setStart] = useState<number | null>(null);
  const [now, setNow] = useState(0);
  const timer = useRef<number | null>(null);
  useEffect(() => () => { if (timer.current) window.clearInterval(timer.current); }, []);
  const elapsed = start ? Math.floor((now - start) / 1000) : 0;
  if (start === null) return <button onClick={() => { const t = Date.now(); setStart(t); setNow(t); timer.current = window.setInterval(() => setNow(Date.now()), 250); }}>Avvia cronometro</button>;
  return (
    <button className="primary stopwatch" onClick={() => { if (timer.current) window.clearInterval(timer.current); timer.current = null; setStart(null); onStop(elapsed); }}>
      Ferma · {elapsed} s
    </button>
  );
}

function SaveIndicator({ state, onConfirm }: { state: SaveState; onConfirm: () => void }) {
  if (state.kind === 'idle') return null;
  if (state.kind === 'saving') return <p className="save saving" role="status">Salvataggio in corso…</p>;
  if (state.kind === 'saved') return <p className="save saved" role="status">Salvato sul dispositivo alle {new Date(state.at).toLocaleTimeString('it-IT')}</p>;
  if (state.code === 'IMPLAUSIBLE_VALUE') return <p className="save error" role="alert">Valore insolito, non salvato. <button className="link" onClick={onConfirm}>Confermo il valore</button> oppure correggilo.</p>;
  return <p className="save error" role="alert">Non salvato: {state.message}. I dati sono ancora qui: riprova.</p>;
}

function ResultView({ result, label, onDone, onChange }: { result: { event: ProgressionEvent | null; repeatedDiscomfort: boolean }; label: Labeler; onDone: () => Promise<void>; onChange: () => Promise<void> }) {
  const [event, setEvent] = useState(result.event);
  useBack(true, () => { void onDone(); });
  return (
    <>
      <div className="card"><h3>Seduta salvata</h3><p className="small">La trovi nello Storico.</p></div>
      {result.repeatedDiscomfort && <p className="alert alert-warn">Hai segnalato fastidio in più sedute recenti. Se continua o aumenta, è utile chiedere il parere di un medico o di un fisioterapista prima di proseguire con questo esercizio.</p>}
      {event && <ProposalCard event={event} label={label} onDecided={async (alt) => { if (alt) setEvent(alt); await onChange(); }} />}
      <button onClick={onDone}>Fatto</button>
    </>
  );
}

const REASONS: Record<string, [RejectionReason, string][]> = {
  INCREASE_DISTANCE: [['NO_SPACE', 'Non ho spazio per allontanarmi'], ['NOT_READY', 'Non mi sento pronto'], ['OTHER', 'Altro motivo']],
  NEXT_BAND: [['JUMP_TOO_BIG', 'Il salto mi sembra troppo grande'], ['NOT_READY', 'Non mi sento pronto'], ['OTHER', 'Altro motivo']],
  ADD_BAND: [['NOT_READY', 'Non mi sento pronto'], ['OTHER', 'Altro motivo']],
};

export function ProposalCard({ event, label, onDecided }: { event: ProgressionEvent; label: Labeler; onDecided: (alternative: ProgressionEvent | null) => Promise<void> }) {
  const [rejecting, setRejecting] = useState(false);
  useBack(rejecting, () => setRejecting(false));
  const [done, setDone] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const isProposal = event.status === 'PROPOSED';
  const decide = async (accept: boolean, reason: RejectionReason | null = null) => {
    try {
      const alt = await decideProposal(db, event.id, accept, reason);
      setDone(accept ? 'Proposta accettata: la troverai già impostata alla prossima seduta.' : alt ? null : 'Proposta rifiutata: alla prossima seduta mantieni la configurazione attuale.');
      setRejecting(false);
      await onDecided(alt);
    } catch (e) { setError((e as Error).message); }
  };
  return (
    <div className={isProposal ? 'card card-accent' : 'card'}>
      <h3>{headline(event, label)}</h3>
      {isProposal && event.proposedConfig && <p className="small">{cfgText(event.proposedConfig, label)}</p>}
      <details><summary className="small">Perché</summary><p className="small">{event.reason}</p></details>
      {isProposal && !done && !rejecting && (
        <div className="row"><button className="primary" onClick={() => decide(true)}>Accetta</button><button onClick={() => setRejecting(true)}>Non ora</button></div>
      )}
      {isProposal && rejecting && !done && (
        <div className="stack">{(REASONS[event.kind] ?? []).map(([r, l]) => <button key={r} onClick={() => decide(false, r)}>{l}</button>)}<button className="secondary" onClick={() => setRejecting(false)}>Annulla</button></div>
      )}
      {done && <p className="done small">{done}</p>}
      {error && <p className="save error">{error}</p>}
    </div>
  );
}

/** Frase breve (D087): il dettaglio resta nel «Perché». */
function headline(e: ProgressionEvent, label: Labeler): string {
  const ev = (e.evidence ?? {}) as { unmet?: string[]; comparability?: string };
  const from = e.fromConfig, to = e.proposedConfig;
  switch (e.kind) {
    case 'INCREASE_DISTANCE': return `Proposta: allontanati di ${(to?.distanceCm ?? 0) - (from?.distanceCm ?? 0)} cm`;
    case 'NEXT_BAND': return `Proposta: passa a ${to ? to.bandIds.map(label).join(' + ') : 'un elastico più duro'}`;
    case 'ADD_BAND': return `Proposta: usa ${to ? to.bandIds.map(label).join(' + ') : 'due elastici'}`;
    case 'BLOCKED_DISCOMFORT': return 'Nessun aumento oggi: hai segnalato un fastidio';
    case 'NONE_AVAILABLE': return 'Mantieni la configurazione';
    default:
      if (ev.comparability === 'D') return 'Seduta non confrontabile: mantieni la configurazione';
      if (ev.unmet?.length) return 'Continua così: obiettivo non ancora raggiunto';
      return 'Obiettivo raggiunto: serve una conferma alla prossima seduta';
  }
}
