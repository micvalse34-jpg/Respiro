// Tasto «indietro» di Android: chiude prima la vista più interna aperta (dettaglio, modulo, conferma),
// poi riporta alla Home; dalla Home l'app va in secondo piano invece di chiudersi.
import { useEffect, useRef } from 'react';

type Handler = () => void;
const stack: Handler[] = [];

export function pushBack(h: Handler): () => void {
  stack.push(h);
  return () => { const i = stack.lastIndexOf(h); if (i >= 0) stack.splice(i, 1); };
}

/**
 * Esegue il gestore più recente; false se non ce n'è nessuno. Il gestore non viene tolto qui:
 * lo toglie il componente quando la vista si chiude (così una scelta obbligatoria resta bloccante).
 */
export function popBack(): boolean {
  const h = stack[stack.length - 1];
  if (!h) return false;
  h();
  return true;
}

export const backDepth = () => stack.length;

/** Registra un gestore finché `active` è vero. Il gestore usato è sempre l'ultima versione passata. */
export function useBack(active: boolean, handler: Handler): void {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => (active ? pushBack(() => ref.current()) : undefined), [active]);
}
