import { FitDb } from '../data/schema';

// Unico database dell'app (nome «fitpro»: lo stesso del POC, così i dati sul telefono vengono migrati, non persi).
export const db = new FitDb();
