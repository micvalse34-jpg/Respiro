import type { SessionStatus, Side, WorkoutSession } from '../domain/types';

export const fmtDateTime = (iso: string | null) => (iso ? new Date(iso).toLocaleString('it-IT', { dateStyle: 'medium', timeStyle: 'short' }) : 'mai');
export const fmtDay = (iso: string) => new Date(iso).toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
export const fmtTime = (iso: string) => new Date(iso).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });

export const STATUS_NAMES: Record<SessionStatus, string> = {
  GENERATED: 'Proposta', IN_PROGRESS: 'In corso', COMPLETED: 'Completata', PARTIALLY_COMPLETED: 'Parziale', CANCELLED: 'Annullata',
};
export const sessionTypeName = (s: WorkoutSession) => (s.sessionType === 'POC' ? 'Seduta di prova' : s.sessionType === 'FREE' ? 'Seduta libera' : `Seduta ${s.sessionType}`);
export const SIDE_NAMES: Record<Side, string> = { LEFT: 'sinistro', RIGHT: 'destro', BILATERAL: 'bilaterale' };

export const plural = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`;
