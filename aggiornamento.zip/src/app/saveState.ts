// Stato visibile del salvataggio di una serie. «saved» è raggiungibile solo dalla risoluzione
// della promessa di commit; un errore porta a «error» e i dati del modulo restano in UI per il nuovo tentativo.
export type SaveState =
  | { kind: 'idle' }
  | { kind: 'saving'; attemptId: string }
  | { kind: 'saved'; attemptId: string; at: string }
  | { kind: 'error'; attemptId: string; message: string; code: string | null };

export async function runSave<T>(
  attemptId: string,
  commit: () => Promise<T>,
  onState: (s: SaveState) => void,
): Promise<T | null> {
  onState({ kind: 'saving', attemptId });
  try {
    const r = await commit();
    onState({ kind: 'saved', attemptId, at: new Date().toISOString() });
    return r;
  } catch (e) {
    const err = e as { message?: string; code?: string; name?: string };
    onState({ kind: 'error', attemptId, message: err.message ?? String(e), code: err.code ?? err.name ?? null });
    return null;
  }
}
