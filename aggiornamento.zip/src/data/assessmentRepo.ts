// Valutazione iniziale in 3 fasi contate in sedute (D097 rivista, D108) e profilo dei domini (D105).
// Le prove sono dati misurati e non si modificano mai; il profilo è ricalcolato dalle prove ogni volta.
import { domainDef, DOMAIN_RULE_VERSION, ladder, LADDERS, PROBES, threshold, type DomainId, type LadderStep, type Probe } from '../domain/domains';
import { computeProfile, ladderLevel, passesStep, type Profile } from '../domain/domainProfile';
import { nowIso, tzOffset, uuidv7 } from '../domain/ids';
import type { DomainTrial, EquipmentItem, Side } from '../domain/types';
import { DomainError } from './errors';
import { orderedBands } from './freeSessionRepo';
import type { FitDb } from './schema';

export const GATE_QUESTIONS = [
  'Hai dolore adesso?',
  'Hai avuto sintomi insoliti negli ultimi giorni?',
  'Qualcuno ti ha detto di evitare certi movimenti?',
] as const;

/** Controllo minimo prima di un gruppo di prove (D096, testo neutro per D094). Restituisce l'esito e registra le risposte. */
export async function recordGate(db: FitDb, answers: boolean[]): Promise<{ runId: string; allowed: boolean }> {
  if (answers.length !== GATE_QUESTIONS.length) throw new DomainError('INVALID_GATE', 'Rispondi a tutte le domande');
  const allowed = answers.every((a) => !a);
  const runId = uuidv7();
  await db.decisionLog.add({
    id: uuidv7(), ts: nowIso(), engine: 'assessment', ruleVersion: 'gate-1', input: { runId, answers },
    decision: allowed ? 'ASSESSMENT_GATE_PASSED' : 'ASSESSMENT_GATE_STOPPED',
    reason: allowed ? 'Controllo minimo superato (D096)' : 'Prove non proposte oggi: almeno una risposta «sì» (D096)',
  });
  return { runId, allowed };
}

export interface LadderAttempt {
  runId: string | null; probeId: string | null; ladderId: string; level: number; side: Side;
  reps: number | null; seconds: number | null; rir: number | null; technique: DomainTrial['technique']; discomfort: boolean;
  bandIds: string[]; referenceCm: number | null;
}

const base = () => ({ id: uuidv7(), ruleVersion: DOMAIN_RULE_VERSION, performedAt: nowIso(), tzOffsetMin: tzOffset(), source: 'ASSESSMENT' as const });

/** Registra un tentativo su un gradino. L'esito «superato» è calcolato qui con il criterio comune, non dall'interfaccia. */
export async function recordLadderAttempt(db: FitDb, a: LadderAttempt): Promise<DomainTrial> {
  const l = LADDERS.find((x) => x.id === a.ladderId);
  if (!l) throw new DomainError('UNKNOWN_LADDER', 'Scala sconosciuta');
  const step = l.steps.find((s) => s.level === a.level);
  if (!step) throw new DomainError('UNKNOWN_LEVEL', 'Livello inesistente');
  if (l.perSide !== (a.side !== 'BILATERAL')) throw new DomainError('INVALID_SIDE', l.perSide ? 'Indica il lato' : 'Questa prova non è per lato');
  if (step.reps !== undefined && (a.reps === null || !Number.isInteger(a.reps) || a.reps < 0 || a.reps > 200)) throw new DomainError('INVALID_VALUE', 'Ripetizioni non valide');
  if (step.seconds !== undefined && (a.seconds === null || a.seconds < 0 || a.seconds > 600)) throw new DomainError('INVALID_VALUE', 'Secondi non validi');
  if (a.rir !== null && (a.rir < 0 || a.rir > 10)) throw new DomainError('INVALID_RIR', 'RIR fuori scala');
  if (step.band) {
    if (!a.bandIds.length) throw new DomainError('INCOMPLETE_CONFIG', 'Indica l\'elastico usato');
    if (step.band.door && (a.referenceCm === null || a.referenceCm < 0 || a.referenceCm > 500)) throw new DomainError('INVALID_DISTANCE', 'Indica la distanza di riferimento dalla porta');
  }
  const passed = passesStep(step, l, { reps: a.reps, seconds: a.seconds, rir: l.useRir ? a.rir : null, technique: a.technique, discomfort: a.discomfort });
  const t: DomainTrial = {
    ...base(), runId: a.runId, probeId: a.probeId, domainId: l.domain, ladderId: l.id, kind: 'LADDER', side: l.perSide ? a.side : null,
    level: a.level, passed, reps: step.reps !== undefined ? a.reps : null, seconds: step.seconds !== undefined ? a.seconds : null,
    valueCm: step.band?.door ? a.referenceCm : null, mobilityClass: null, rir: l.useRir ? a.rir : null, technique: a.technique,
    discomfort: a.discomfort, bandIds: a.bandIds, pressReps: null,
  };
  await db.domainTrials.add(t);
  return t;
}

export interface ThresholdInput { runId: string | null; probeId: string | null; domainId: DomainId; side: Side; value: number | null; choice: DomainTrial['mobilityClass']; discomfort: boolean }

export async function recordThreshold(db: FitDb, i: ThresholdInput): Promise<DomainTrial> {
  const d = domainDef(i.domainId);
  if (d.kind !== 'THRESHOLD') throw new DomainError('UNKNOWN_DOMAIN', 'Dominio senza soglia');
  if (d.perSide !== (i.side !== 'BILATERAL')) throw new DomainError('INVALID_SIDE', d.perSide ? 'Indica il lato' : 'Questa prova non è per lato');
  const th = threshold(i.domainId);
  let cls: DomainTrial['mobilityClass'];
  let valueCm: number | null = null; let seconds: number | null = null;
  if (th.input.kind === 'NUMBER') {
    if (i.value === null || !Number.isFinite(i.value) || i.value < 0 || i.value > th.input.max) throw new DomainError('INVALID_VALUE', `Valore tra 0 e ${th.input.max} ${th.input.unit}`);
    cls = th.input.classify(i.value);
    if (th.input.unit === 'cm') valueCm = i.value; else seconds = i.value;
  } else {
    if (!i.choice) throw new DomainError('INVALID_VALUE', 'Scegli la descrizione');
    cls = i.choice;
  }
  const t: DomainTrial = {
    ...base(), runId: i.runId, probeId: i.probeId, domainId: i.domainId, ladderId: null, kind: 'THRESHOLD', side: d.perSide ? i.side : null,
    level: null, passed: null, reps: null, seconds, valueCm, mobilityClass: cls, rir: null, technique: null, discomfort: i.discomfort, bandIds: [], pressReps: null,
  };
  await db.domainTrials.add(t);
  return t;
}

/** Rapporto orizzontale: rematore e spinta al petto con lo stesso elastico alla stessa distanza (massime ripetizioni con buona tecnica). */
export async function recordRatioH(db: FitDb, i: { runId: string | null; probeId: string | null; rowReps: number; pressReps: number; bandIds: string[]; distanceCm: number; discomfort: boolean }): Promise<DomainTrial> {
  if (![i.rowReps, i.pressReps].every((x) => Number.isInteger(x) && x > 0 && x <= 200)) throw new DomainError('INVALID_VALUE', 'Ripetizioni non valide');
  if (!i.bandIds.length) throw new DomainError('INCOMPLETE_CONFIG', 'Indica l\'elastico usato');
  if (!(i.distanceCm >= 0 && i.distanceCm <= 500)) throw new DomainError('INVALID_DISTANCE', 'Distanza tra 0 e 500 cm');
  const t: DomainTrial = {
    ...base(), runId: i.runId, probeId: i.probeId, domainId: 'T-OR', ladderId: null, kind: 'RATIO_H', side: null, level: null, passed: null,
    reps: i.rowReps, seconds: null, valueCm: i.distanceCm, mobilityClass: null, rir: null, technique: null, discomfort: i.discomfort, bandIds: i.bandIds, pressReps: i.pressReps,
  };
  await db.domainTrials.add(t);
  return t;
}

export async function getProfile(db: FitDb, now = Date.now()): Promise<Profile> {
  return computeProfile(await db.domainTrials.toArray(), now);
}

/** Elastico da usare per un gradino: n-esimo nell'ordine dichiarato dall'utente (E1 = il più morbido). */
export async function bandForStep(db: FitDb, step: LadderStep): Promise<EquipmentItem | null> {
  if (!step.band) return null;
  const list = await orderedBands(db, step.band.family === 'LOOP' ? 'LOOP_BAND' : 'RESISTANCE_BAND');
  return list[step.band.index - 1] ?? null;
}

/** Ultima distanza di riferimento usata per una scala alla porta (si ripropone alla prova successiva). */
export async function lastReference(db: FitDb, ladderId: string): Promise<number | null> {
  const t = (await db.domainTrials.filter((x) => x.ladderId === ladderId && x.valueCm !== null).toArray()).sort((a, b) => b.performedAt.localeCompare(a.performedAt))[0];
  return t?.valueCm ?? null;
}

/** Gradino di partenza: uno sotto il livello attuale della scala (per quel lato), oppure 2 se non c'è stima. */
export async function startLevel(db: FitDb, ladderId: string, side: Side): Promise<number> {
  const l = ladder(ladderId);
  const trials = await db.domainTrials.filter((t) => t.ladderId === ladderId && (t.side ?? 'BILATERAL') === side).toArray();
  const r = ladderLevel(trials, Date.now());
  if (r.level === null) return Math.min(2, l.steps.length);
  return Math.max(1, r.level - 1);
}

export interface ProbeStatus { probe: Probe; done: boolean; lastAt: string | null }

/** Avanzamento del piano: una prova è fatta quando ha almeno un risultato per ogni lato richiesto. */
export async function assessmentProgress(db: FitDb): Promise<ProbeStatus[]> {
  const trials = await db.domainTrials.filter((t) => t.source === 'ASSESSMENT').toArray();
  return PROBES.map((probe) => {
    const mine = trials.filter((t) => t.probeId === probe.id);
    const perSide = probe.kind === 'LADDER' ? ladder(probe.ref).perSide : probe.kind === 'THRESHOLD' ? domainDef(probe.ref as DomainId).perSide : false;
    const done = perSide ? ['LEFT', 'RIGHT'].every((s) => mine.some((t) => t.side === s)) : mine.length > 0;
    const lastAt = mine.map((t) => t.performedAt).sort().pop() ?? null;
    return { probe, done, lastAt };
  });
}

/**
 * Elimina le prove di valutazione fatte per simulare (D110): servono a provare l'app, non devono entrare nel profilo.
 * È l'unica eccezione alla regola «le prove non si modificano»: richiesta esplicita dell'utente, registrata nel decision log.
 */
export async function deleteAssessmentTrials(db: FitDb): Promise<number> {
  return db.transaction('rw', db.domainTrials, db.decisionLog, async () => {
    const ids = (await db.domainTrials.toCollection().primaryKeys()) as string[];
    await db.domainTrials.bulkDelete(ids);
    await db.decisionLog.add({
      id: uuidv7(), ts: nowIso(), engine: 'user', ruleVersion: 'assessment-1', input: { count: ids.length },
      decision: 'ASSESSMENT_TRIALS_DELETED', reason: 'Prove di valutazione di prova eliminate dall\'utente (D110)',
    });
    return ids.length;
  });
}
