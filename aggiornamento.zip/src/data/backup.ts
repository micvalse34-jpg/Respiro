import { z } from 'zod';
import { nowIso } from '../domain/ids';
import { canonicalStringify, sha256Hex } from './canonical';
import { DomainError } from './errors';
import { ACCESSORY_TYPES, ELASTIC_TYPES } from '../domain/types';
import { seedKnowledge } from './repository';
import { CURRENT_SCHEMA_VERSION, DATA_TABLES, DATA_TABLES_V4, MIN_IMPORTABLE_SCHEMA_VERSION, type DataTable, FitDb, upgradeEquipmentV2 } from './schema';

export const BACKUP_FORMAT = 'fitpro-backup';
// Formato 1: Persistence POC (schema 1–2). Formato 2: F1 (schema 3). Formato 3: slice Band Row (schema 4, proposte).
export const BACKUP_FORMAT_VERSION = 8;
export const SUPPORTED_FORMAT_VERSIONS = [1, 2, 3, 4, 5, 6, 7, 8] as const;
/** Tabelle presenti nei file di formato 1: le altre, assenti, vengono importate vuote. */
const FORMAT1_TABLES = ['equipmentItems', 'exercises', 'exerciseVersions', 'sessions', 'prescriptions', 'sets', 'decisionLog'] as const;
const FORMAT2_TABLES = [...FORMAT1_TABLES, 'bandOrderings', 'profileVersions'] as const;
// Formato 4 (0.4.0): stesso schema 4, versioni esercizio con classificazione e contenuti estesi, tipo «tappetino».
// Formato 5 (0.4.1): serie con il dato del recupero (timer).
// Formato 6 (0.4.2): schema 5, prove dei domini funzionali.
// Formato 7 (0.4.3): recupero con l'intervallo reale tra le registrazioni.
// Formato 8 (0.4.4): recupero misurato con il tocco «Inizio la serie» o stimato.
const MAX_SCHEMA_FOR_FORMAT: Record<number, number> = { 1: 2, 2: 3, 3: 4, 4: 4, 5: 4, 6: 5, 7: 5, 8: 5 };

const iso = z.string().datetime({ offset: true });
const nullableNum = z.number().finite().nullable();
const nullableText = z.string().nullable();
const side = z.enum(['LEFT', 'RIGHT', 'BILATERAL']);
const snapshot = z.object({
  configurationId: z.string().nullable(), bandIds: z.array(z.string()), anchor: z.string().nullable(),
  anchorHeightCm: nullableNum, distanceCm: nullableNum, notes: z.string().nullable(),
}).strict().nullable();
const equipmentType = z.enum([...ELASTIC_TYPES, ...ACCESSORY_TYPES]);
const range = z.tuple([z.number(), z.number()]);
const metaSchema = z.object({
  group: z.string(), pattern: z.string(), primary: z.array(z.string()), secondary: z.array(z.string()), joints: z.array(z.string()),
  functions: z.array(z.string()), equipment: z.array(equipmentType), needs: z.array(z.enum(['WALL', 'SUPPORT'])),
  setup: z.enum(['TUBE_DOOR', 'TUBE_FREE', 'LOOP', 'NONE']), anchor: z.enum(['DOOR_LOW', 'DOOR_MID', 'DOOR_HIGH']).nullable(),
  complexity: z.union([z.literal(1), z.literal(2), z.literal(3)]), unilateral: z.boolean(), repsPerSide: z.boolean(),
  measure: z.enum(['REPS', 'DURATION']), effort: z.enum(['RIR', 'NONE']),
  defaults: z.object({ sets: range, reps: range.nullable(), durationS: range.nullable(), rir: range.nullable() }).strict(),
}).strict();
const elasticType = z.enum(ELASTIC_TYPES);

/** Oggetto attrezzatura nella forma del POC (formato 1). */
const legacyEquipmentSchema = z.object({ id: z.string().min(1), type: z.enum(['RESISTANCE_BAND', 'LOOP_BAND', 'HANDLE', 'ANKLE_STRAP', 'DOOR_ANCHOR', 'OTHER']), label: z.string(), color: z.string().nullable(), declaredResistance: z.string().nullable(), createdAt: iso }).strict();

const recordSchemas = {
  equipmentItems: z.object({
    id: z.string().min(1), type: equipmentType, physicalLabel: z.string().regex(/^E[1-9]\d{0,2}$/).nullable(), description: nullableText,
    color: nullableText, brandModel: nullableText, declaredResistance: nullableText, restLengthCm: nullableNum,
    integrity: z.enum(['OK', 'WORN', 'DAMAGED']).nullable(), quantity: z.number().int().min(1).nullable(), status: z.enum(['ACTIVE', 'RETIRED']),
    notes: nullableText, createdAt: iso, updatedAt: iso, retiredAt: iso.nullable(),
  }).strict(),
  bandOrderings: z.object({ id: z.string().min(1), bandType: elasticType, orderedIds: z.array(z.string().min(1)).min(2), method: z.literal('USER_DECLARED'), declaredAt: iso, tzOffsetMin: z.number().int(), note: nullableText }).strict(),
  profileVersions: z.object({
    id: z.string().min(1), birthYear: z.number().int().nullable(), heightCm: nullableNum, weightKg: nullableNum,
    experience: z.enum(['NONE', 'LESS_THAN_6_MONTHS', 'FROM_6_TO_24_MONTHS', 'MORE_THAN_24_MONTHS']).nullable(),
    usualActivities: nullableText, notes: nullableText, recordedAt: iso, tzOffsetMin: z.number().int(),
  }).strict(),
  exercises: z.object({ id: z.string().min(1), canonicalName: z.string().min(1), createdAt: iso }).strict(),
  exerciseVersions: z.object({
    id: z.string().min(1), exerciseId: z.string().min(1), version: z.number().int().positive(), unilateral: z.boolean(), measure: z.enum(['REPS', 'DURATION']), breathing: z.string().nullable(),
    content: z.object({
      displayName: z.string(), status: z.enum(['DRAFT', 'VALIDATED']), setup: z.array(z.string()), cues: z.array(z.string()), commonErrors: z.array(z.string()), safetyChecks: z.array(z.string()), defaultAnchor: z.enum(['DOOR_LOW', 'DOOR_MID', 'DOOR_HIGH']).nullable(),
      purpose: z.string().optional(), stopIf: z.array(z.string()).optional(), easier: z.array(z.string()).optional(), harder: z.array(z.string()).optional(),
      variants: z.array(z.object({ name: z.string(), description: z.string() }).strict()).optional(), sources: z.array(z.string()).optional(),
    }).strict().nullable().optional(),
    meta: metaSchema.nullable().optional(),
    createdAt: iso,
  }).strict(),
  sessions: z.object({ id: z.string().min(1), sessionType: z.enum(['A', 'B', 'C', 'FREE', 'POC']), status: z.enum(['GENERATED', 'IN_PROGRESS', 'COMPLETED', 'PARTIALLY_COMPLETED', 'CANCELLED']), startedAt: iso, tzOffsetMin: z.number().int(), endedAt: iso.nullable(), updatedAt: iso, closeReason: z.enum(['FINISHED_BY_USER', 'CLOSED_ON_REOPEN']).nullable() }).strict(),
  prescriptions: z.object({ id: z.string().min(1), sessionId: z.string().min(1), exerciseId: z.string().min(1), exerciseVersionId: z.string().min(1), order: z.number().int().positive(), origin: z.enum(['ENGINE', 'USER_ADDED', 'SUBSTITUTION']), prescribedSets: z.number().int().min(0), repMin: nullableNum, repMax: nullableNum, targetDurationS: nullableNum, targetRir: nullableNum, sidesPerSet: z.array(side).min(1), configurationSnapshot: snapshot, createdAt: iso }).strict(),
  sets: z.object({ id: z.string().min(1), sessionId: z.string().min(1), prescriptionId: z.string().min(1), exerciseId: z.string().min(1).nullable().optional(), setIndex: z.number().int().positive(), side: side.nullable(), status: z.enum(['PERFORMED', 'INTERRUPTED', 'NOT_PERFORMED']), reps: z.number().int().min(0).nullable(), durationS: nullableNum, rir: nullableNum, rpe: nullableNum, techniqueQuality: z.enum(['GOOD', 'ACCEPTABLE', 'POOR']).nullable(), discomfort: z.boolean().nullable(), configurationSnapshot: snapshot, plausibility: z.enum(['OK', 'CONFIRMED_BY_USER']), performedAt: iso, tzOffsetMin: z.number().int(), rest: z.object({ suggestedS: z.number().min(0), addedS: z.number().min(0), elapsedS: z.number().min(0), skipped: z.boolean(), intervalS: z.number().min(0).optional(), measured: z.enum(['TAP', 'ESTIMATED']).optional() }).strict().nullable().optional() }).strict(),
  progressionEvents: z.object({
    id: z.string().min(1), exerciseId: z.string().min(1), sessionId: z.string().min(1), previousEventId: z.string().nullable(), ruleVersion: z.string(),
    kind: z.enum(['MAINTAIN', 'BLOCKED_DISCOMFORT', 'INCREASE_DISTANCE', 'NEXT_BAND', 'ADD_BAND', 'NONE_AVAILABLE']),
    status: z.enum(['INFO', 'PROPOSED', 'ACCEPTED', 'REJECTED']), fromConfig: snapshot, proposedConfig: snapshot, reason: z.string(), evidence: z.unknown(),
    createdAt: iso, tzOffsetMin: z.number().int(), decidedAt: iso.nullable(), rejectionReason: z.enum(['NO_SPACE', 'JUMP_TOO_BIG', 'NOT_READY', 'OTHER']).nullable(),
  }).strict(),
  decisionLog: z.object({ id: z.string().min(1), ts: iso, engine: z.string(), ruleVersion: z.string(), input: z.unknown(), decision: z.string(), reason: z.string() }).strict(),
  domainTrials: z.object({
    id: z.string().min(1), runId: z.string().nullable(), probeId: z.string().nullable(), domainId: z.string().min(1), ladderId: z.string().nullable(),
    kind: z.enum(['LADDER', 'THRESHOLD', 'RATIO_H']), side: side.nullable(), level: z.number().int().min(1).max(5).nullable(), passed: z.boolean().nullable(),
    reps: z.number().int().min(0).nullable(), seconds: nullableNum, valueCm: nullableNum, mobilityClass: z.enum(['CARENTE', 'LIMITATA', 'ADEGUATA']).nullable(),
    rir: nullableNum, technique: z.enum(['GOOD', 'ACCEPTABLE', 'POOR']).nullable(), discomfort: z.boolean(), bandIds: z.array(z.string().min(1)),
    pressReps: z.number().int().min(0).nullable(), source: z.enum(['ASSESSMENT', 'TRAINING']), ruleVersion: z.string(), performedAt: iso, tzOffsetMin: z.number().int(),
  }).strict(),
} satisfies Record<DataTable, z.ZodTypeAny>;

const envelopeSchema = z.object({
  format: z.literal(BACKUP_FORMAT),
  formatVersion: z.number().int(),
  schemaVersion: z.number().int(),
  appVersion: z.string(),
  exportedAt: iso,
  installId: z.string().nullable(),
  counts: z.record(z.number().int()),
  checksum: z.string().regex(/^[0-9a-f]{64}$/),
  tables: z.record(z.array(z.unknown())),
}).strict();

export type Tables = Record<DataTable, Record<string, unknown>[]>;
export interface BackupFile {
  format: typeof BACKUP_FORMAT; formatVersion: number; schemaVersion: number; appVersion: string;
  exportedAt: string; installId: string | null; counts: Record<string, number>; checksum: string; tables: Tables;
}

export async function getMeta<T>(db: FitDb, key: string): Promise<T | null> {
  return ((await db.meta.get(key))?.value as T | undefined) ?? null;
}
export async function setMeta(db: FitDb, key: string, value: unknown): Promise<void> {
  await db.meta.put({ key, value });
}

/** Lettura in un'unica transazione: istantanea coerente anche se nel frattempo si registrano serie. */
export async function exportBackup(db: FitDb, appVersion: string): Promise<BackupFile> {
  const tables = {} as Tables;
  let installId: string | null = null;
  await db.transaction('r', [db.meta, ...DATA_TABLES.map((t) => db.table(t))], async () => {
    for (const t of DATA_TABLES) tables[t] = (await db.table(t).toArray()).sort((a, b) => String(a.id).localeCompare(String(b.id)));
    installId = ((await db.meta.get('installId'))?.value as string | undefined) ?? null;
  });
  const counts = Object.fromEntries(DATA_TABLES.map((t) => [t, tables[t].length]));
  return {
    format: BACKUP_FORMAT, formatVersion: BACKUP_FORMAT_VERSION, schemaVersion: CURRENT_SCHEMA_VERSION, appVersion,
    exportedAt: nowIso(), installId, counts, checksum: await sha256Hex(canonicalStringify(tables)), tables,
  };
}

export async function contentHash(db: FitDb): Promise<string> {
  const b = await exportBackup(db, 'hash');
  return b.checksum;
}

export interface ValidationReport {
  ok: boolean;
  errors: string[];
  summary: { schemaVersion: number | null; exportedAt: string | null; counts: Record<string, number> };
  backup: BackupFile | null; // contenuto già portato allo schema corrente, pronto per l'import
}

const MAX_ERRORS = 50;

/**
 * Validazione completa, senza scrivere nulla: formato, versioni, checksum, schema dei record, ID duplicati, relazioni.
 * Accetta anche i backup del Persistence POC (formato 1), portandoli allo schema corrente.
 */
export async function validateBackup(raw: string | unknown): Promise<ValidationReport> {
  const errors: string[] = [];
  const empty = (): ValidationReport => ({ ok: false, errors, summary: { schemaVersion: null, exportedAt: null, counts: {} }, backup: null });
  let data: unknown = raw;
  if (typeof raw === 'string') {
    try { data = JSON.parse(raw); } catch { errors.push('Il file non è JSON valido (corrotto o troncato).'); return empty(); }
  }
  const env = envelopeSchema.safeParse(data);
  if (!env.success) { errors.push(`Struttura del backup non riconosciuta: ${env.error.issues.slice(0, 3).map((i) => `${i.path.join('.')}: ${i.message}`).join('; ')}`); return empty(); }
  const e = env.data;
  const summary = { schemaVersion: e.schemaVersion, exportedAt: e.exportedAt, counts: e.counts };
  const fv = e.formatVersion;
  if (!(SUPPORTED_FORMAT_VERSIONS as readonly number[]).includes(fv)) errors.push(`Versione di formato ${fv} non supportata (gestite: ${SUPPORTED_FORMAT_VERSIONS.join(', ')}).`);
  if (e.schemaVersion > CURRENT_SCHEMA_VERSION) errors.push(`Backup creato da una versione più recente dell'app (schema ${e.schemaVersion}, questa app gestisce fino a ${CURRENT_SCHEMA_VERSION}). Aggiornare l'app prima di importare.`);
  if (e.schemaVersion < MIN_IMPORTABLE_SCHEMA_VERSION) errors.push(`Schema ${e.schemaVersion} troppo vecchio per l'import diretto.`);
  if (MAX_SCHEMA_FOR_FORMAT[fv] !== undefined && e.schemaVersion > MAX_SCHEMA_FOR_FORMAT[fv]!) errors.push(`File incoerente: formato ${fv} con schema ${e.schemaVersion}.`);
  if (errors.length) return { ...empty(), summary };
  const expected: readonly string[] = fv === 1 ? FORMAT1_TABLES : fv === 2 ? FORMAT2_TABLES : fv <= 5 ? DATA_TABLES_V4 : DATA_TABLES;
  const unknownTables = Object.keys(e.tables).filter((t) => !expected.includes(t));
  if (unknownTables.length) errors.push(`Tabelle sconosciute: ${unknownTables.join(', ')}.`);
  const missingTables = expected.filter((t) => !(t in e.tables));
  if (missingTables.length) errors.push(`Tabelle mancanti: ${missingTables.join(', ')}.`);
  if (errors.length) return { ...empty(), summary };

  const actual = await sha256Hex(canonicalStringify(e.tables));
  if (actual !== e.checksum) { errors.push('Checksum non corrispondente: il contenuto è stato alterato o è incompleto.'); return { ...empty(), summary }; }

  // Porta il contenuto allo schema corrente: tabelle assenti nel formato 1 = vuote; attrezzatura del POC → forma v3.
  const fileTables = e.tables as Record<string, Record<string, unknown>[]>;
  const tables = Object.fromEntries(DATA_TABLES.map((t) => [t, fileTables[t] ?? []])) as Tables;
  for (const t of expected) if (fileTables[t]!.length !== e.counts[t]) errors.push(`${t}: conteggio dichiarato ${e.counts[t]}, presenti ${fileTables[t]!.length}.`);
  if (fv === 1) {
    tables.equipmentItems.forEach((r, i) => {
      const res = legacyEquipmentSchema.safeParse(r);
      if (!res.success) errors.push(`equipmentItems[${i}]: ${res.error.issues.slice(0, 2).map((x) => `${x.path.join('.')} ${x.message}`).join('; ')}`);
    });
    if (errors.length) return { ...empty(), summary };
    tables.equipmentItems = tables.equipmentItems.map((r) => upgradeEquipmentV2(r, e.exportedAt) as unknown as Record<string, unknown>);
  }

  for (const t of DATA_TABLES) {
    const seen = new Set<string>();
    tables[t].forEach((r, i) => {
      if (errors.length >= MAX_ERRORS) return;
      const res = recordSchemas[t].safeParse(r);
      if (!res.success) errors.push(`${t}[${i}]: ${res.error.issues.slice(0, 2).map((x) => `${x.path.join('.')} ${x.message}`).join('; ')}`);
      const id = String((r as { id?: unknown }).id);
      if (seen.has(id)) errors.push(`${t}: ID duplicato ${id}.`);
      seen.add(id);
    });
  }
  if (errors.length) return { ...empty(), summary };

  // Integrità referenziale (IndexedDB non ha chiavi esterne: la garantisce il repository e la verifica l'import).
  const ids = (t: DataTable) => new Set(tables[t].map((r) => r.id as string));
  const ex = ids('exercises'), ver = ids('exerciseVersions'), ses = ids('sessions'), pre = ids('prescriptions');
  const eqType = new Map(tables.equipmentItems.map((r) => [r.id as string, r.type as string]));
  const preSession = new Map(tables.prescriptions.map((p) => [p.id as string, p.sessionId as string]));
  const labels = new Map<string, string>();
  for (const it of tables.equipmentItems) {
    const l = it.physicalLabel as string | null;
    if (l && labels.has(l)) errors.push(`Etichetta ${l} assegnata a due oggetti.`);
    if (l) labels.set(l, it.id as string);
    if ((ELASTIC_TYPES as readonly string[]).includes(it.type as string) && it.status === 'ACTIVE' && !l) errors.push(`Elastico ${it.id} in uso senza etichetta.`);
    if ((ELASTIC_TYPES as readonly string[]).includes(it.type as string) && it.quantity !== 1) errors.push(`Elastico ${it.id}: quantità diversa da 1.`);
  }
  for (const o of tables.bandOrderings) {
    for (const id of o.orderedIds as string[]) if (eqType.get(id) !== o.bandType) errors.push(`Ordinamento ${o.id}: ${id} non è un elastico del tipo ${o.bandType}.`);
    if (new Set(o.orderedIds as string[]).size !== (o.orderedIds as string[]).length) errors.push(`Ordinamento ${o.id}: elastico ripetuto.`);
  }
  const checkBands = (what: string, id: unknown, snap: unknown) => {
    for (const b of ((snap as { bandIds?: string[] } | null)?.bandIds ?? [])) if (!eqType.has(b)) errors.push(`${what} ${id}: elastico ${b} inesistente.`);
  };
  for (const v of tables.exerciseVersions) if (!ex.has(v.exerciseId as string)) errors.push(`Versione ${v.id}: esercizio ${v.exerciseId} inesistente.`);
  for (const p of tables.prescriptions) {
    if (!ses.has(p.sessionId as string)) errors.push(`Prescrizione ${p.id}: seduta inesistente.`);
    if (!ver.has(p.exerciseVersionId as string)) errors.push(`Prescrizione ${p.id}: versione esercizio inesistente.`);
    checkBands('Prescrizione', p.id, p.configurationSnapshot);
  }
  const evIds = ids('progressionEvents');
  for (const ev of tables.progressionEvents) {
    if (!ses.has(ev.sessionId as string)) errors.push(`Proposta ${ev.id}: seduta inesistente.`);
    if (!ex.has(ev.exerciseId as string)) errors.push(`Proposta ${ev.id}: esercizio inesistente.`);
    if (ev.previousEventId && !evIds.has(ev.previousEventId as string)) errors.push(`Proposta ${ev.id}: proposta precedente inesistente.`);
    checkBands('Proposta', ev.id, ev.fromConfig); checkBands('Proposta', ev.id, ev.proposedConfig);
  }
  for (const s of tables.sets) {
    if (!pre.has(s.prescriptionId as string)) errors.push(`Serie ${s.id}: prescrizione inesistente.`);
    else if (preSession.get(s.prescriptionId as string) !== s.sessionId) errors.push(`Serie ${s.id}: seduta incoerente con la prescrizione.`);
    checkBands('Serie', s.id, s.configurationSnapshot);
  }
  if (errors.length) return { ...empty(), summary: { ...summary } };

  // Schema 1 → 2: backfill exerciseId sulle serie.
  const exOfPre = new Map(tables.prescriptions.map((p) => [p.id as string, p.exerciseId as string]));
  tables.sets = tables.sets.map((s) => ({ ...s, exerciseId: (s.exerciseId as string | null | undefined) ?? exOfPre.get(s.prescriptionId as string) ?? null }));
  return { ok: true, errors, summary, backup: { ...e, tables, schemaVersion: CURRENT_SCHEMA_VERSION } as BackupFile };
}

export async function isPopulated(db: FitDb): Promise<boolean> {
  // Qualsiasi dato inserito dall'utente: sedute, serie, profilo, attrezzatura, ordinamenti.
  for (const t of ['sessions', 'sets', 'profileVersions', 'equipmentItems', 'bandOrderings'] as const) if ((await db.table(t).count()) > 0) return true;
  return false;
}

export interface ImportOptions {
  confirmReplace: boolean;
  /** Solo test: interrompe la transazione dopo la cancellazione per verificare che il DB resti invariato. */
  faultInjection?: 'after_clear' | 'after_first_table';
}

/**
 * Import come sostituzione integrale, atomica: o tutto il backup entra, o il database resta com'era.
 * Rifiutato con una seduta in corso. Su DB popolato richiede conferma esplicita.
 */
export async function importBackup(db: FitDb, report: ValidationReport, opts: ImportOptions): Promise<void> {
  if (!report.ok || !report.backup) throw new DomainError('INVALID_BACKUP', 'Backup non valido: import bloccato');
  if ((await db.sessions.where('status').equals('IN_PROGRESS').count()) > 0) throw new DomainError('SESSION_OPEN', 'Chiudere la seduta in corso prima di ripristinare un backup');
  if ((await isPopulated(db)) && !opts.confirmReplace) throw new DomainError('NEEDS_CONFIRMATION', 'Il database contiene già dati: serve conferma esplicita della sostituzione');
  const b = report.backup;
  await db.transaction('rw', [db.meta, ...DATA_TABLES.map((t) => db.table(t))], async () => {
    for (const t of DATA_TABLES) await db.table(t).clear();
    if (opts.faultInjection === 'after_clear') throw new Error('FAULT_INJECTED_AFTER_CLEAR');
    let i = 0;
    for (const t of DATA_TABLES) {
      await db.table(t).bulkAdd(b.tables[t]);
      if (opts.faultInjection === 'after_first_table' && i++ === 0) throw new Error('FAULT_INJECTED_AFTER_FIRST_TABLE');
    }
    await db.meta.put({ key: 'lastImport', value: { at: nowIso(), sourceExportedAt: b.exportedAt, sourceInstallId: b.installId, checksum: b.checksum } });
  });  // Un backup di una versione precedente non contiene le schede nuove: le aggiunge subito, senza toccare quelle importate.
  await seedKnowledge(db);
}

export const BACKUP_REMINDER_DAYS = 7; // D3

/** Giorni di calendario (ora locale) trascorsi dall'ultimo backup: 0 = oggi, 1 = ieri. */
export function backupAgeDays(lastExportAt: string | null, now = Date.now()): number | null {
  if (!lastExportAt) return null;
  const day = (t: number) => { const d = new Date(t); return Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()); };
  return Math.max(0, Math.round((day(now) - day(Date.parse(lastExportAt))) / 86_400_000));
}
export function needsBackupReminder(lastExportAt: string | null, hasData: boolean, now = Date.now()): boolean {
  if (!hasData) return false;
  const age = backupAgeDays(lastExportAt, now);
  return age === null || age > BACKUP_REMINDER_DAYS;
}
