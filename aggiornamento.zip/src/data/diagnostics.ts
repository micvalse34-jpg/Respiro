import Dexie from 'dexie';
import { uuidv7 } from '../domain/ids';
import { FitDb, FitDbV1, FitDbV2, CURRENT_SCHEMA_VERSION, POC_PLACEHOLDER_ID } from './schema';
import { exerciseHistory, generateHistory, percentile } from './synthetic';
import { SEED, closeSession, getOpenSessions, recordSet, seedKnowledge, startPocSession, tableCounts } from './repository';
import { contentHash, getMeta } from './backup';
import { journalRead } from './journal';
import { isNativeApp, nativeDeviceInfo } from '../platform';

/**
 * DEF-03 (POC): nell'app Android il campo riportava «browser (scheda)», perché la WebView non dichiara la
 * modalità «standalone» delle PWA. Ora l'app nativa ha un'etichetta propria.
 */
export function displayModeLabel(native: boolean, standalone: boolean): string {
  if (native) return 'app Android (Capacitor)';
  return standalone ? 'standalone (PWA installata)' : 'browser (scheda)';
}

export async function environment(): Promise<Record<string, unknown>> {
  const uad = (navigator as unknown as { userAgentData?: { getHighEntropyValues(h: string[]): Promise<Record<string, unknown>> } }).userAgentData;
  let hints: Record<string, unknown> | null = null;
  try { hints = uad ? await uad.getHighEntropyValues(['platform', 'platformVersion', 'model', 'fullVersionList']) : null; } catch { hints = null; }
  const standalone = matchMedia('(display-mode: standalone)').matches;
  const twa = document.referrer.startsWith('android-app://');
  return {
    runtime: isNativeApp() ? 'app Android (Capacitor, WebView)' : 'browser / PWA',
    device: await nativeDeviceInfo(), // solo app: modello, versione Android, versione WebView
    userAgent: navigator.userAgent,
    clientHints: hints, // Android: platformVersion = versione Android; fullVersionList = versione Chrome completa
    displayMode: displayModeLabel(isNativeApp(), standalone),
    launchedFromAndroidApp: twa,
    serviceWorkerControlled: !!navigator.serviceWorker?.controller,
    online: navigator.onLine,
    app: { version: __APP_VERSION__, build: __BUILD_LABEL__, builtAt: __BUILD_TIME__ },
  };
}

export async function storageStatus(): Promise<Record<string, unknown>> {
  const s = navigator.storage;
  const persisted = s?.persisted ? await s.persisted() : null;
  const est = s?.estimate ? await s.estimate() : null;
  return { persisted, usageBytes: est?.usage ?? null, quotaBytes: est?.quota ?? null };
}

export async function requestPersistence(): Promise<boolean | null> {
  return navigator.storage?.persist ? navigator.storage.persist() : null;
}

/** Latenza di commit della singola scrittura, strict vs relaxed, su DB di prova separati (POC-04). */
export async function benchmarkDurability(n = 50): Promise<Record<string, unknown>> {
  const out: Record<string, unknown> = {};
  for (const mode of ['strict', 'relaxed'] as const) {
    const name = `fitpro-bench-${mode}`;
    await Dexie.delete(name);
    const db = new FitDb(name, mode);
    await seedKnowledge(db);
    const s = await startPocSession(db);
    const p = (await db.prescriptions.where('sessionId').equals(s.id).first())!;
    const times: number[] = [];
    for (let i = 0; i < n; i++) {
      const t = performance.now();
      await recordSet(db, { id: uuidv7(), sessionId: s.id, prescriptionId: p.id, setIndex: i + 1, side: 'BILATERAL', status: 'PERFORMED', reps: 10, durationS: null, rir: 2, rpe: null, techniqueQuality: 'GOOD', discomfort: null });
      times.push(performance.now() - t);
    }
    db.close(); await Dexie.delete(name);
    out[mode] = { n, p50Ms: +percentile(times, 50).toFixed(1), p95Ms: +percentile(times, 95).toFixed(1), maxMs: +Math.max(...times).toFixed(1) };
  }
  return out;
}

/** Prestazioni con storico sintetico (POC-14), su DB separato. */
export async function benchmarkHistory(years = 5): Promise<Record<string, unknown>> {
  const name = 'fitpro-perf';
  await Dexie.delete(name);
  let db = new FitDb(name);
  const t0 = performance.now();
  const gen = await generateHistory(db, years);
  const genMs = performance.now() - t0;
  db.close();
  const t1 = performance.now();
  db = new FitDb(name); await db.open();
  const openMs = performance.now() - t1;
  const q: number[] = [];
  for (let i = 0; i < 20; i++) { const t = performance.now(); await exerciseHistory(db, SEED.bandRow.exerciseId, 200); q.push(performance.now() - t); }
  const t2 = performance.now(); await contentHash(db); const exportMs = performance.now() - t2;
  db.close(); await Dexie.delete(name);
  return { years, ...gen, generateMs: Math.round(genMs), reopenMs: Math.round(openMs), historyQueryP95Ms: +percentile(q, 95).toFixed(1), fullExportAndHashMs: Math.round(exportMs) };
}

/** Autotest di migrazione v2→v3 (F1, DM07) con seduta IN_PROGRESS e attrezzatura del POC, su DB separato. */
export async function migrationV3SelfTest(): Promise<Record<string, unknown>> {
  const name = 'fitpro-migtest-v3';
  await Dexie.delete(name);
  const v2 = new FitDbV2(name);
  await v2.open();
  const t = new Date().toISOString();
  await v2.table('equipmentItems').add({ id: POC_PLACEHOLDER_ID, type: 'RESISTANCE_BAND', label: 'Banda 1 (etichetta da censire)', color: null, declaredResistance: null, createdAt: t });
  await v2.table('sessions').add({ id: 'mig3-s', sessionType: 'POC', status: 'IN_PROGRESS', startedAt: t, tzOffsetMin: 0, endedAt: null, updatedAt: t, closeReason: null });
  await v2.table('prescriptions').add({ id: 'mig3-p', sessionId: 'mig3-s', exerciseId: SEED.bandRow.exerciseId, exerciseVersionId: SEED.bandRow.versionId, order: 1, origin: 'ENGINE', prescribedSets: 3, repMin: 8, repMax: 15, targetDurationS: null, targetRir: 2, sidesPerSet: ['BILATERAL'], configurationSnapshot: { configurationId: null, bandIds: [POC_PLACEHOLDER_ID], anchor: 'door', anchorHeightCm: 100, distanceCm: 120, notes: null }, createdAt: t });
  await v2.table('sets').add({ id: 'mig3-set', sessionId: 'mig3-s', prescriptionId: 'mig3-p', exerciseId: SEED.bandRow.exerciseId, setIndex: 1, side: 'BILATERAL', status: 'PERFORMED', reps: 10, durationS: null, rir: null, rpe: null, techniqueQuality: null, discomfort: null, configurationSnapshot: null, plausibility: 'OK', performedAt: t, tzOffsetMin: 0 });
  v2.close();
  const v3 = new FitDb(name); await v3.open();
  const eq = await v3.equipmentItems.get(POC_PLACEHOLDER_ID);
  const set = await v3.sets.get('mig3-set');
  const open = await getOpenSessions(v3);
  const result = {
    fromVersion: 2, toVersion: v3.verno, setPreserved: set?.reps === 10 && set?.rir === null,
    sessionStillInProgress: open.length === 1, placeholderRetired: eq?.status === 'RETIRED' && eq.physicalLabel === null,
    newTablesReady: (await v3.profileVersions.count()) === 0 && (await v3.bandOrderings.count()) === 0, pass: false,
  };
  result.pass = result.setPreserved && result.sessionStillInProgress && result.placeholderRetired && result.newTablesReady && v3.verno === CURRENT_SCHEMA_VERSION;
  v3.close(); await Dexie.delete(name);
  return result;
}

/** Autotest di migrazione v1→corrente con seduta IN_PROGRESS (POC-06), su DB separato. */
export async function migrationSelfTest(): Promise<Record<string, unknown>> {
  const name = 'fitpro-migtest';
  await Dexie.delete(name);
  const v1 = new FitDbV1(name);
  await v1.open();
  const sid = 'mig-session', pid = 'mig-pres';
  await v1.table('exercises').add({ id: SEED.bandRow.exerciseId, canonicalName: 'Band Row', createdAt: new Date().toISOString() });
  await v1.table('sessions').add({ id: sid, sessionType: 'POC', status: 'IN_PROGRESS', startedAt: new Date().toISOString(), tzOffsetMin: 0, endedAt: null, updatedAt: new Date().toISOString(), closeReason: null });
  await v1.table('prescriptions').add({ id: pid, sessionId: sid, exerciseId: SEED.bandRow.exerciseId, exerciseVersionId: SEED.bandRow.versionId, order: 1, origin: 'ENGINE', prescribedSets: 3, repMin: 8, repMax: 15, targetDurationS: null, targetRir: 2, sidesPerSet: ['BILATERAL'], configurationSnapshot: null, createdAt: new Date().toISOString() });
  await v1.table('sets').add({ id: 'mig-set-1', sessionId: sid, prescriptionId: pid, setIndex: 1, side: 'BILATERAL', status: 'PERFORMED', reps: 10, durationS: null, rir: 2, rpe: null, techniqueQuality: 'GOOD', discomfort: null, configurationSnapshot: null, plausibility: 'OK', performedAt: new Date().toISOString(), tzOffsetMin: 0 });
  v1.close();
  const v2 = new FitDb(name); await v2.open();
  const set = await v2.sets.get('mig-set-1');
  const open = await getOpenSessions(v2);
  const result = { fromVersion: 1, toVersion: v2.verno, setPreserved: !!set, exerciseIdBackfilled: set?.exerciseId === SEED.bandRow.exerciseId, sessionStillInProgress: open.length === 1, pass: false };
  result.pass = result.setPreserved && result.exerciseIdBackfilled && result.sessionStillInProgress && v2.verno === CURRENT_SCHEMA_VERSION;
  v2.close(); await Dexie.delete(name);
  return result;
}

/** Confronto tra il giornale delle serie confermate e il database (POC-03). */
export async function journalCheck(db: FitDb): Promise<{ confirmed: number; found: number; lost: string[] }> {
  const ids = journalRead();
  const found = await db.sets.bulkGet(ids);
  const lost = ids.filter((_, i) => !found[i]);
  return { confirmed: ids.length, found: ids.length - lost.length, lost };
}

export async function fullReport(db: FitDb): Promise<Record<string, unknown>> {
  return {
    generatedAt: new Date().toISOString(),
    environment: await environment(),
    storage: await storageStatus(),
    database: { name: db.name, schemaVersion: db.verno, counts: await tableCounts(db), installId: await getMeta(db, 'installId'), installCreatedAt: await getMeta(db, 'installCreatedAt'), lastExportAt: await getMeta(db, 'lastExportAt'), contentHash: await contentHash(db) },
    killTestJournal: await journalCheck(db),
  };
}

export { closeSession };
