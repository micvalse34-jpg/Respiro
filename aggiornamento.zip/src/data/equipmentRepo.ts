import { nowIso, tzOffset, uuidv7 } from '../domain/ids';
import { isElastic, labelNumber, nextFreeLabel, normalizeLabel, orderingErrors, STARTER_KIT } from '../domain/equipment';
import type { BandOrdering, ElasticType, EquipmentItem, EquipmentType, Integrity } from '../domain/types';
import { ELASTIC_TYPES } from '../domain/types';
import { DomainError } from './errors';
import type { FitDb } from './schema';

export interface EquipmentInput {
  type: EquipmentType;
  physicalLabel: string | null; // elastici: «E3» o «3»; accessori: ignorata
  description: string | null;
  color: string | null;
  brandModel: string | null;
  declaredResistance: string | null;
  restLengthCm: number | null;
  integrity: Integrity | null;
  quantity: number | null;
  notes: string | null;
}

/** Campi modificabili dopo la creazione. Tipo ed etichetta no: lo storico li usa per riconoscere l'oggetto. */
export type EquipmentPatch = Partial<Omit<EquipmentInput, 'type' | 'physicalLabel'>>;

function checkFields(p: EquipmentPatch): void {
  if (p.restLengthCm != null && (!Number.isFinite(p.restLengthCm) || p.restLengthCm <= 0 || p.restLengthCm > 500)) throw new DomainError('INVALID_LENGTH', 'Lunghezza: inserire un valore tra 1 e 500 cm');
  if (p.quantity !== undefined && p.quantity !== null && (!Number.isInteger(p.quantity) || p.quantity < 1 || p.quantity > 20)) throw new DomainError('INVALID_QUANTITY', 'Quantità: inserire un numero intero tra 1 e 20');
}

export async function listEquipment(db: FitDb, includeRetired = false): Promise<EquipmentItem[]> {
  const all = await db.equipmentItems.toArray();
  return all
    .filter((i) => includeRetired || i.status === 'ACTIVE')
    .sort((a, b) => labelNumber(a.physicalLabel) - labelNumber(b.physicalLabel) || a.type.localeCompare(b.type) || a.createdAt.localeCompare(b.createdAt));
}

export async function suggestLabel(db: FitDb): Promise<string> {
  return nextFreeLabel(await db.equipmentItems.toArray());
}

export async function addEquipment(db: FitDb, input: EquipmentInput): Promise<EquipmentItem> {
  checkFields(input);
  return db.transaction('rw', db.equipmentItems, async () => {
    let label: string | null = null;
    if (isElastic(input.type)) {
      label = input.physicalLabel ? normalizeLabel(input.physicalLabel) : null;
      if (!label) throw new DomainError('INVALID_LABEL', 'Etichetta non valida: usare E seguito da un numero (es. E3)');
      const clash = await db.equipmentItems.filter((i) => i.physicalLabel === label).first();
      if (clash) throw new DomainError('LABEL_IN_USE', `L'etichetta ${label} è già assegnata${clash.status === 'RETIRED' ? ' a un elastico dismesso' : ''}`);
      if (input.quantity !== 1) throw new DomainError('INVALID_QUANTITY', 'Ogni elastico si registra singolarmente');
    }
    const t = nowIso();
    const item: EquipmentItem = {
      id: uuidv7(), type: input.type, physicalLabel: label, description: input.description, color: input.color,
      brandModel: input.brandModel, declaredResistance: input.declaredResistance, restLengthCm: input.restLengthCm,
      integrity: input.integrity, quantity: isElastic(input.type) ? 1 : input.quantity, status: 'ACTIVE',
      notes: input.notes, createdAt: t, updatedAt: t, retiredAt: null,
    };
    await db.equipmentItems.add(item);
    return item;
  });
}

/** Crea il kit dell'inventario iniziale con tutti gli attributi sconosciuti (null). Solo se non c'è attrezzatura in uso. */
export async function addStarterKit(db: FitDb): Promise<number> {
  return db.transaction('rw', db.equipmentItems, async () => {
    if ((await db.equipmentItems.where('status').equals('ACTIVE').count()) > 0) throw new DomainError('KIT_EXISTS', 'Attrezzatura già presente: aggiungi i singoli oggetti');
    const existing = await db.equipmentItems.toArray();
    const t = nowIso();
    const items: EquipmentItem[] = [];
    for (const k of STARTER_KIT) {
      const elastic = isElastic(k.type);
      items.push({
        id: uuidv7(), type: k.type, physicalLabel: elastic ? nextFreeLabel([...existing, ...items]) : null, description: k.description ?? null,
        color: k.color ?? null, brandModel: k.brandModel ?? null, declaredResistance: k.declaredResistance ?? null,
        restLengthCm: k.restLengthCm ?? null, integrity: null, quantity: elastic ? 1 : k.count, status: 'ACTIVE', notes: null,
        createdAt: t, updatedAt: t, retiredAt: null,
      });
    }
    await db.equipmentItems.bulkAdd(items);
    return items.length;
  });
}

export async function updateEquipment(db: FitDb, id: string, patch: EquipmentPatch): Promise<EquipmentItem> {
  checkFields(patch);
  return db.transaction('rw', db.equipmentItems, async () => {
    const cur = await db.equipmentItems.get(id);
    if (!cur) throw new DomainError('NOT_FOUND', 'Oggetto inesistente');
    if (isElastic(cur.type) && patch.quantity !== undefined && patch.quantity !== 1) throw new DomainError('INVALID_QUANTITY', 'Ogni elastico si registra singolarmente');
    const next: EquipmentItem = { ...cur, ...patch, type: cur.type, physicalLabel: cur.physicalLabel, updatedAt: nowIso() };
    await db.equipmentItems.put(next);
    return next;
  });
}

export async function setEquipmentStatus(db: FitDb, id: string, status: 'ACTIVE' | 'RETIRED'): Promise<void> {
  await db.transaction('rw', db.equipmentItems, async () => {
    const cur = await db.equipmentItems.get(id);
    if (!cur) throw new DomainError('NOT_FOUND', 'Oggetto inesistente');
    const t = nowIso();
    await db.equipmentItems.update(id, { status, retiredAt: status === 'RETIRED' ? t : null, updatedAt: t });
  });
}

/** Dove è usato un oggetto: sedute registrate (snapshot) e ordinamenti. */
export async function equipmentReferences(db: FitDb, id: string): Promise<{ prescriptions: number; sets: number; orderings: number }> {
  return db.transaction('r', db.prescriptions, db.sets, db.bandOrderings, async () => ({
    prescriptions: await db.prescriptions.filter((p) => !!p.configurationSnapshot?.bandIds.includes(id)).count(),
    sets: await db.sets.filter((s) => !!s.configurationSnapshot?.bandIds.includes(id)).count(),
    orderings: await db.bandOrderings.filter((o) => o.orderedIds.includes(id)).count(),
  }));
}

/** Eliminazione definitiva: solo per oggetti mai usati (errori di inserimento). Altrimenti si dismette. */
export async function deleteEquipment(db: FitDb, id: string): Promise<void> {
  await db.transaction('rw', db.equipmentItems, db.prescriptions, db.sets, db.bandOrderings, async () => {
    const r = await equipmentReferences(db, id);
    if (r.prescriptions + r.sets + r.orderings > 0) throw new DomainError('IN_USE', 'Oggetto già usato in sedute o ordinamenti: non si può eliminare, ma puoi segnarlo come dismesso');
    await db.equipmentItems.delete(id);
  });
}

export async function saveOrdering(db: FitDb, bandType: ElasticType, orderedIds: string[], note: string | null = null): Promise<BandOrdering> {
  return db.transaction('rw', db.equipmentItems, db.bandOrderings, async () => {
    const errors = orderingErrors(bandType, orderedIds, await db.equipmentItems.toArray());
    if (errors.length) throw new DomainError('INVALID_ORDERING', errors.join(' '));
    const o: BandOrdering = { id: uuidv7(), bandType, orderedIds: [...orderedIds], method: 'USER_DECLARED', declaredAt: nowIso(), tzOffsetMin: tzOffset(), note };
    await db.bandOrderings.add(o);
    return o;
  });
}

export async function currentOrderings(db: FitDb): Promise<Partial<Record<ElasticType, BandOrdering>>> {
  const out: Partial<Record<ElasticType, BandOrdering>> = {};
  for (const t of ELASTIC_TYPES) {
    const list = await db.bandOrderings.where('bandType').equals(t).sortBy('declaredAt');
    const last = list[list.length - 1];
    if (last) out[t] = last;
  }
  return out;
}

export async function orderingHistoryCount(db: FitDb, bandType: ElasticType): Promise<number> {
  return db.bandOrderings.where('bandType').equals(bandType).count();
}

/** Ordinamento valido per gli elastici attivi oggi? (completo e senza elastici dismessi) */
export function orderingIsCurrent(o: BandOrdering | undefined, activeOfType: EquipmentItem[]): boolean {
  if (!o) return false;
  const ids = new Set(activeOfType.map((i) => i.id));
  return o.orderedIds.length === ids.size && o.orderedIds.every((id) => ids.has(id));
}

/** Posizione (1 = più morbido) secondo l'ordinamento valido; null se non ordinato o ordinamento da aggiornare. */
export function rankOf(itemId: string, o: BandOrdering | undefined, activeOfType: EquipmentItem[]): number | null {
  if (!orderingIsCurrent(o, activeOfType)) return null;
  return o!.orderedIds.indexOf(itemId) + 1 || null;
}

export interface CensusStatus {
  elastics: number;
  elasticsWithoutColor: number;
  accessories: number;
  typesToOrder: ElasticType[]; // tipi con ≥2 elastici attivi e ordinamento mancante o non aggiornato
}

export async function censusStatus(db: FitDb): Promise<CensusStatus> {
  const items = await listEquipment(db);
  const orderings = await currentOrderings(db);
  const elastics = items.filter((i) => isElastic(i.type));
  const typesToOrder = ELASTIC_TYPES.filter((t) => {
    const ofType = elastics.filter((i) => i.type === t);
    return ofType.length >= 2 && !orderingIsCurrent(orderings[t], ofType);
  });
  return {
    elastics: elastics.length,
    elasticsWithoutColor: elastics.filter((i) => i.color === null).length,
    accessories: items.length - elastics.length,
    typesToOrder,
  };
}
