export class DomainError extends Error {
  constructor(public code: string, message: string) { super(message); this.name = 'DomainError'; }
}
export const isQuotaError = (e: unknown): boolean => {
  const n = (e as { name?: string; inner?: { name?: string } })?.name;
  const inner = (e as { inner?: { name?: string } })?.inner?.name;
  return n === 'QuotaExceededError' || inner === 'QuotaExceededError';
};
