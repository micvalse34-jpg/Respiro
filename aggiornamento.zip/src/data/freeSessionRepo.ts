// Seduta libera con qualsiasi esercizio della libreria (D098). Una seduta può contenere più esercizi, uno per riga
// di prescrizione; le proposte di progressione restano solo per il Band Row (D088), valutato a fine seduta da sliceRepo.
import { isComplete } from '../domain/comparability';
import { nowIso, tzOffset, uuidv7 } from '../domain/ids';
import type { ExerciseMeta } from '../domain/library';
import type { ConfigurationSnapshot, EquipmentItem, ExercisePrescription, ExerciseVersion, WorkoutSession } from '../domain/types';
import { currentOrderings, listEquipment, orderingIsCurrent } from './equipmentRepo';
import { DomainError } from './errors';
import { currentVersion } from './knowledge';
import type { FitDb } from './schema';
// Import circolare voluto e sicuro: setupDefaults si usa solo dentro una funzione, mai al caricamento del modulo.
import { setupDefaults } from './sliceRepo';

export const BAND_ROW_ID = 'ex-021';
/** Prescrizione di default del Band Row (D039, PROVISIONAL): 3 serie, 8–15 ripetizioni, RIR 2–3. Invariata dalla slice. */
export const BAND_ROW_DEFAULTS = { sets: 3, repMin: 8, repMax: 15, targetRir: 2 } as const;
export const SAFETY_CHECK_DAYS = 7; // D086, PROVISIONAL

export const snapshotOf = (bandIds: string[], anchor: string | null, distanceCm: number | null): ConfigurationSnapshot =>
  ({ configurationId: null, bandIds, anchor, anchorHeightCm: null, distanceCm, notes: null });

export interface FreeSetup { exerciseId: string; config: ConfigurationSnapshot | null }

/** Versione corrente con classificazione e contenuto: solo questi esercizi si possono allenare (le schede in preparazione no). */
export function trainableVersion(exerciseId: string): ExerciseVersion & { meta: ExerciseMeta } {
  const v = currentVersion(exerciseId);
  if (!v || !v.meta) throw new DomainError('UNKNOWN_EXERCISE', 'Esercizio non presente nella libreria');
  if (!v.content) throw new DomainError('CONTENT_NOT_READY', 'La scheda di questo esercizio è ancora in preparazione');
  return v as ExerciseVersion & { meta: ExerciseMeta };
}

const usesBands = (m: ExerciseMeta) => m.setup !== 'NONE';

/** Controlla la configurazione secondo il tipo di impostazione dell'esercizio. Lancia DomainError con un messaggio per l'utente. */
export async function checkSetup(db: FitDb, meta: Pick<ExerciseMeta, 'setup'>, cfg: ConfigurationSnapshot | null): Promise<void> {
  if (meta.setup === 'NONE') { if (cfg && cfg.bandIds.length) throw new DomainError('UNEXPECTED_CONFIG', 'Questo esercizio non usa elastici'); return; }
  if (!cfg || cfg.bandIds.length === 0) throw new DomainError('INCOMPLETE_CONFIG', meta.setup === 'LOOP' ? 'Scegli l\'elastico ad anello' : 'Scegli almeno un elastico');
  if (meta.setup === 'TUBE_DOOR') {
    if (!isComplete(cfg)) throw new DomainError('INCOMPLETE_CONFIG', 'Indica elastici, punto di ancoraggio e distanza dalla porta');
    if (!Number.isFinite(cfg.distanceCm) || cfg.distanceCm! < 0 || cfg.distanceCm! > 500) throw new DomainError('INVALID_DISTANCE', 'Distanza: inserire un valore tra 0 e 500 cm');
  } else if (cfg.anchor !== null || cfg.distanceCm !== null) {
    throw new DomainError('UNEXPECTED_CONFIG', 'Questo esercizio non usa l\'ancoraggio alla porta');
  }
  const wanted = meta.setup === 'LOOP' ? 'LOOP_BAND' : 'RESISTANCE_BAND';
  for (const id of cfg.bandIds) {
    const it = await db.equipmentItems.get(id);
    if (!it || it.type !== wanted || it.status !== 'ACTIVE') throw new DomainError('INVALID_BAND', 'Elastico non valido per questo esercizio');
    if (it.integrity === 'DAMAGED') throw new DomainError('DAMAGED_BAND', `${it.physicalLabel} è segnato come danneggiato: scegli un altro elastico`);
  }
}

/**
 * Controllo di elastici e ancoraggio da confermare (D086): alla prima seduta, dopo 7 giorni dall'ultima conferma
 * oppure quando si usa un elastico mai usato prima in una seduta libera.
 */
export async function safetyCheckRequired(db: FitDb, bandIds: string[], now = Date.now()): Promise<boolean> {
  const last = (await db.decisionLog.filter((l) => l.decision === 'SAFETY_CHECK_CONFIRMED').toArray()).sort((a, b) => b.ts.localeCompare(a.ts))[0];
  if (!last || now - Date.parse(last.ts) > SAFETY_CHECK_DAYS * 86_400_000) return true;
  const free = new Set((await db.sessions.filter((s) => s.sessionType === 'FREE').primaryKeys()) as string[]);
  const used = new Set<string>();
  for (const s of await db.sets.filter((x) => free.has(x.sessionId) && x.status !== 'NOT_PERFORMED').toArray()) s.configurationSnapshot?.bandIds.forEach((b) => used.add(b));
  return bandIds.some((b) => !used.has(b));
}

/** Prescrizione di default dalla classificazione (D039, PROVISIONAL). Il Band Row conserva i default della slice. */
export function buildPrescription(sessionId: string, order: number, setup: FreeSetup, t: string): ExercisePrescription {
  const v = trainableVersion(setup.exerciseId);
  const m = v.meta;
  const base = { id: uuidv7(), sessionId, exerciseId: setup.exerciseId, exerciseVersionId: v.id, order, configurationSnapshot: setup.config, createdAt: t };
  if (setup.exerciseId === BAND_ROW_ID) {
    return { ...base, origin: 'ENGINE', prescribedSets: BAND_ROW_DEFAULTS.sets, repMin: BAND_ROW_DEFAULTS.repMin, repMax: BAND_ROW_DEFAULTS.repMax, targetDurationS: null, targetRir: BAND_ROW_DEFAULTS.targetRir, sidesPerSet: ['BILATERAL'] };
  }
  return {
    ...base, origin: 'USER_ADDED', prescribedSets: m.defaults.sets[1],
    repMin: m.measure === 'REPS' ? m.defaults.reps?.[0] ?? null : null, repMax: m.measure === 'REPS' ? m.defaults.reps?.[1] ?? null : null,
    targetDurationS: m.measure === 'DURATION' ? m.defaults.durationS?.[1] ?? null : null,
    targetRir: m.effort === 'RIR' ? m.defaults.rir?.[0] ?? null : null,
    sidesPerSet: m.unilateral ? ['LEFT', 'RIGHT'] : ['BILATERAL'],
  };
}

async function precheck(db: FitDb, setup: FreeSetup, safetyConfirmed: boolean): Promise<void> {
  const v = trainableVersion(setup.exerciseId);
  await checkSetup(db, v.meta, setup.config);
  if (usesBands(v.meta) && !safetyConfirmed && await safetyCheckRequired(db, setup.config!.bandIds)) {
    throw new DomainError('SAFETY_CHECK_REQUIRED', 'Prima di iniziare controlla elastici, maniglie e ancoraggio e spunta la conferma');
  }
}

const safetyLog = (sessionId: string, bandIds: string[], t: string) => ({
  id: uuidv7(), ts: t, engine: 'user', ruleVersion: 'safety-check-1', input: { sessionId, bandIds },
  decision: 'SAFETY_CHECK_CONFIRMED', reason: 'Controllo di elastici, maniglie e ancoraggio confermato',
});

export async function startFreeSession(db: FitDb, setup: FreeSetup, safetyConfirmed = false): Promise<WorkoutSession> {
  await precheck(db, setup, safetyConfirmed);
  const t = nowIso();
  const session: WorkoutSession = { id: uuidv7(), sessionType: 'FREE', status: 'IN_PROGRESS', startedAt: t, tzOffsetMin: tzOffset(), endedAt: null, updatedAt: t, closeReason: null };
  const p = buildPrescription(session.id, 1, setup, t);
  await db.transaction('rw', db.sessions, db.prescriptions, db.decisionLog, async () => {
    if ((await db.sessions.where('status').equals('IN_PROGRESS').count()) > 0) throw new DomainError('SESSION_OPEN', 'C\'è già una seduta in corso');
    await db.sessions.add(session);
    await db.prescriptions.add(p);
    await db.decisionLog.add({ id: uuidv7(), ts: t, engine: 'free-session', ruleVersion: 'free-1', input: { exerciseId: setup.exerciseId, config: setup.config }, decision: 'SESSION_CREATED', reason: 'Seduta libera con prescrizione di default (D039, D098)' });
    if (safetyConfirmed && setup.config?.bandIds.length) await db.decisionLog.add(safetyLog(session.id, setup.config.bandIds, t));
  });
  return session;
}

/** Aggiunge un esercizio alla seduta libera in corso. Lo stesso esercizio non può comparire due volte. */
export async function addFreeExercise(db: FitDb, sessionId: string, setup: FreeSetup, safetyConfirmed = false): Promise<ExercisePrescription> {
  // Prima il doppione: è l'informazione più utile, inutile chiedere il controllo degli elastici per un esercizio già presente.
  if (await db.prescriptions.where('sessionId').equals(sessionId).filter((p) => p.exerciseId === setup.exerciseId).count()) throw new DomainError('ALREADY_IN_SESSION', 'Questo esercizio è già nella seduta');
  await precheck(db, setup, safetyConfirmed);
  const t = nowIso();
  return db.transaction('rw', db.sessions, db.prescriptions, db.decisionLog, async () => {
    const s = await db.sessions.get(sessionId);
    if (!s || s.status !== 'IN_PROGRESS' || s.sessionType !== 'FREE') throw new DomainError('SESSION_NOT_OPEN', 'La seduta non è in corso');
    const existing = await db.prescriptions.where('sessionId').equals(sessionId).toArray();
    if (existing.some((p) => p.exerciseId === setup.exerciseId)) throw new DomainError('ALREADY_IN_SESSION', 'Questo esercizio è già nella seduta');
    const p = buildPrescription(sessionId, existing.length + 1, setup, t);
    await db.prescriptions.add(p);
    await db.sessions.update(sessionId, { updatedAt: t });
    await db.decisionLog.add({ id: uuidv7(), ts: t, engine: 'free-session', ruleVersion: 'free-1', input: { sessionId, exerciseId: setup.exerciseId, config: setup.config }, decision: 'EXERCISE_ADDED', reason: 'Esercizio aggiunto alla seduta libera (D098)' });
    if (safetyConfirmed && setup.config?.bandIds.length) await db.decisionLog.add(safetyLog(sessionId, setup.config.bandIds, t));
    return p;
  });
}

/** Elastici di un tipo nell'ordine dichiarato dall'utente (dal più morbido), esclusi i danneggiati. */
export async function orderedBands(db: FitDb, type: 'RESISTANCE_BAND' | 'LOOP_BAND'): Promise<EquipmentItem[]> {
  const all = (await listEquipment(db)).filter((i) => i.type === type);
  const o = (await currentOrderings(db))[type];
  return orderingIsCurrent(o, all) ? o!.orderedIds.map((id) => all.find((t) => t.id === id)!).filter(Boolean) : all;
}

/**
 * Configurazione proposta all'avvio di un esercizio: per il Band Row la regola della slice (proposta accettata,
 * ultima seduta, default); per gli altri l'ultima usata in una seduta libera, se ancora valida, altrimenti l'elastico più morbido.
 */
export async function initialConfig(db: FitDb, exerciseId: string): Promise<ConfigurationSnapshot | null> {
  const meta = trainableVersion(exerciseId).meta;
  if (meta.setup === 'NONE') return null;
  if (exerciseId === BAND_ROW_ID) {
    return (await setupDefaults(db)).config;
  }
  const free = new Set((await db.sessions.filter((s) => s.sessionType === 'FREE').primaryKeys()) as string[]);
  const last = (await db.sets.where('[exerciseId+performedAt]').between([exerciseId, ''], [exerciseId, '\uffff']).reverse().toArray())
    .find((s) => free.has(s.sessionId) && s.status !== 'NOT_PERFORMED' && s.configurationSnapshot)?.configurationSnapshot ?? null;
  if (last) { try { await checkSetup(db, meta, last); return last; } catch { /* configurazione non più valida */ } }
  const soft = (await orderedBands(db, meta.setup === 'LOOP' ? 'LOOP_BAND' : 'RESISTANCE_BAND'))[0];
  return snapshotOf(soft ? [soft.id] : [], meta.setup === 'TUBE_DOOR' ? meta.anchor : null, null);
}

/** Prima volta con questo esercizio (D102): nessuna serie eseguita in altre sedute. Serve per i consigli di calibrazione. */
export async function isCalibrating(db: FitDb, exerciseId: string, sessionId: string): Promise<boolean> {
  const n = await db.sets.where('[exerciseId+performedAt]').between([exerciseId, ''], [exerciseId, '\uffff'])
    .filter((s) => s.sessionId !== sessionId && s.status === 'PERFORMED').count();
  return n === 0;
}
