import { exerciseName } from './libraryCatalog';
import { journalRemove } from './journal';
import { nowIso, uuidv7 } from '../domain/ids';
import type { EquipmentItem, ExercisePrescription, ProgressionEvent, SetPerformance, WorkoutSession } from '../domain/types';
import { DomainError } from './errors';
import { getSessionDetail } from './repository';
import { POC_PLACEHOLDER_ID, type FitDb } from './schema';

/** Le sedute di prova (strumenti di verifica e POC) hanno sessionType 'POC'. */
export const isTestSession = (s: WorkoutSession): boolean => s.sessionType === 'POC';

export interface SessionSummary {
  session: WorkoutSession;
  exercises: number;
  performed: number;
  interrupted: number;
  notPerformed: number;
  durationMin: number | null; // null se la seduta non è chiusa
}

export async function countSessions(db: FitDb): Promise<{ real: number; test: number }> {
  const all = await db.sessions.toArray();
  const test = all.filter(isTestSession).length;
  return { real: all.length - test, test };
}

/** Elenco dal più recente. Lettura in un'unica transazione: istantanea coerente. */
export async function listSessionSummaries(db: FitDb, opts: { includeTest: boolean; limit?: number; offset?: number }): Promise<SessionSummary[]> {
  return db.transaction('r', db.sessions, db.prescriptions, db.sets, async () => {
    const sessions = (await db.sessions.orderBy('startedAt').reverse().toArray()).filter((s) => opts.includeTest || !isTestSession(s));
    const page = sessions.slice(opts.offset ?? 0, (opts.offset ?? 0) + (opts.limit ?? 30));
    const out: SessionSummary[] = [];
    for (const s of page) {
      const sets = await db.sets.where('sessionId').equals(s.id).toArray();
      const exercises = await db.prescriptions.where('sessionId').equals(s.id).count();
      out.push({
        session: s, exercises,
        performed: sets.filter((x) => x.status === 'PERFORMED').length,
        interrupted: sets.filter((x) => x.status === 'INTERRUPTED').length,
        notPerformed: sets.filter((x) => x.status === 'NOT_PERFORMED').length,
        durationMin: s.endedAt ? Math.max(0, Math.round((Date.parse(s.endedAt) - Date.parse(s.startedAt)) / 60_000)) : null,
      });
    }
    return out;
  });
}

export interface ExerciseBlock { prescription: ExercisePrescription; name: string; sets: SetPerformance[] }
export interface HistoryDetail {
  session: WorkoutSession;
  blocks: ExerciseBlock[];
  equipment: Map<string, EquipmentItem>; // per mostrare le etichette degli elastici negli snapshot
  events: ProgressionEvent[];
}

export async function getHistoryDetail(db: FitDb, sessionId: string): Promise<HistoryDetail | null> {
  const d = await getSessionDetail(db, sessionId);
  if (!d) return null;
  const names = new Map((await db.exercises.bulkGet(d.prescriptions.map((p) => p.exerciseId))).filter(Boolean).map((e) => [e!.id, e!.canonicalName]));
  const bandIds = new Set<string>();
  for (const p of d.prescriptions) p.configurationSnapshot?.bandIds.forEach((b) => bandIds.add(b));
  for (const s of d.sets) s.configurationSnapshot?.bandIds.forEach((b) => bandIds.add(b));
  const equipment = new Map((await db.equipmentItems.bulkGet([...bandIds])).filter(Boolean).map((e) => [e!.id, e!]));
  const blocks = d.prescriptions.map((p) => ({
    prescription: p,
    name: exerciseName(p.exerciseId, names.get(p.exerciseId) ?? `Esercizio ${p.exerciseId}`),
    sets: d.sets.filter((s) => s.prescriptionId === p.id).sort((a, b) => a.setIndex - b.setIndex || (a.side ?? '').localeCompare(b.side ?? '') || a.performedAt.localeCompare(b.performedAt)),
  }));
  const events = await db.progressionEvents.where('sessionId').equals(sessionId).sortBy('createdAt');
  return { session: d.session, blocks, equipment, events };
}

/**
 * Elimina SOLO le sedute di prova (con prescrizioni e serie), le voci di registro del POC e il segnaposto
 * attrezzatura del POC se non più usato. Azione esplicita dell'utente; registrata nel registro decisioni.
 */
export async function deleteTestData(db: FitDb): Promise<{ sessions: number; prescriptions: number; sets: number; logEntries: number; placeholderRemoved: boolean }> {
  let deletedSetIds: string[] = [];
  const out = await db.transaction('rw', [db.sessions, db.prescriptions, db.sets, db.decisionLog, db.equipmentItems, db.progressionEvents], async () => {
    const test = (await db.sessions.toArray()).filter(isTestSession);
    if (test.some((s) => s.status === 'IN_PROGRESS')) throw new DomainError('SESSION_OPEN', 'C\'è una seduta di prova in corso: chiudila prima');
    const ids = test.map((s) => s.id);
    const preIds = (await db.prescriptions.where('sessionId').anyOf(ids).primaryKeys()) as string[];
    const setIds = (await db.sets.where('sessionId').anyOf(ids).primaryKeys()) as string[];
    const logIds = (await db.decisionLog.filter((l) => l.engine === 'poc').primaryKeys()) as string[];
    const evIds = (await db.progressionEvents.where('sessionId').anyOf(ids).primaryKeys()) as string[];
    await db.progressionEvents.bulkDelete(evIds);
    await db.sets.bulkDelete(setIds);
    await db.prescriptions.bulkDelete(preIds);
    await db.sessions.bulkDelete(ids);
    await db.decisionLog.bulkDelete(logIds);
    let placeholderRemoved = false;
    const ph = await db.equipmentItems.get(POC_PLACEHOLDER_ID);
    if (ph) {
      const used = (await db.prescriptions.filter((p) => !!p.configurationSnapshot?.bandIds.includes(POC_PLACEHOLDER_ID)).count())
        + (await db.sets.filter((s) => !!s.configurationSnapshot?.bandIds.includes(POC_PLACEHOLDER_ID)).count());
      if (!used) { await db.equipmentItems.delete(POC_PLACEHOLDER_ID); placeholderRemoved = true; }
    }
    const result = { sessions: ids.length, prescriptions: preIds.length, sets: setIds.length, logEntries: logIds.length, placeholderRemoved };
    await db.decisionLog.add({ id: uuidv7(), ts: nowIso(), engine: 'system', ruleVersion: 'f1-1', input: result, decision: 'TEST_DATA_DELETED', reason: 'Eliminazione dei dati di prova richiesta dall\'utente' });
    deletedSetIds = setIds;
    return result;
  });
  journalRemove(deletedSetIds); // dopo il commit: il giornale diagnostico non deve segnalarle come perse
  return out;
}

/**
 * Correzione di un errore di inserimento (21 §6): una seduta libera chiusa diventa «di prova».
 * Le osservazioni restano invariate; esce dalle valutazioni di progressione e diventa eliminabile con i dati di prova.
 */
export async function markSessionAsTest(db: FitDb, sessionId: string): Promise<void> {
  await db.transaction('rw', db.sessions, db.decisionLog, async () => {
    const s = await db.sessions.get(sessionId);
    if (!s) throw new DomainError('NOT_FOUND', 'Seduta inesistente');
    if (s.status === 'IN_PROGRESS') throw new DomainError('SESSION_OPEN', 'Chiudi prima la seduta');
    if (s.sessionType !== 'FREE') throw new DomainError('NOT_ALLOWED', 'Solo le sedute libere si possono segnare come prova');
    const t = nowIso();
    await db.sessions.update(sessionId, { sessionType: 'POC', updatedAt: t });
    await db.decisionLog.add({ id: uuidv7(), ts: t, engine: 'user', ruleVersion: 'f1-1', input: { sessionId, from: 'FREE' }, decision: 'SESSION_MARKED_AS_TEST', reason: 'Correzione: dati inseriti per prova' });
  });
}

/** Più sedute in un'unica transazione: o tutte o nessuna. */
export async function markSessionsAsTest(db: FitDb, sessionIds: string[]): Promise<void> {
  await db.transaction('rw', db.sessions, db.decisionLog, async () => {
    for (const id of sessionIds) await markSessionAsTest(db, id);
  });
}
