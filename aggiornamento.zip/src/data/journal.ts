// Giornale indipendente delle serie confermate (POC-03). Scritto in localStorage DOPO il commit:
// al riavvio, un ID nel giornale ma assente dal DB indica una scrittura confermata e poi persa.
// Limite: localStorage condivide l'origine, quindi una cancellazione dello storage elimina anche il giornale.
const KEY = 'fitpro.killtest.journal';

export function journalAppend(id: string): void {
  try {
    const cur = JSON.parse(localStorage.getItem(KEY) ?? '[]') as string[];
    cur.push(id);
    localStorage.setItem(KEY, JSON.stringify(cur));
  } catch { /* il giornale è diagnostico: un errore non deve bloccare il salvataggio */ }
}
export function journalRead(): string[] {
  try { return JSON.parse(localStorage.getItem(KEY) ?? '[]') as string[]; } catch { return []; }
}
export function journalClear(): void { try { localStorage.removeItem(KEY); } catch { /* noop */ } }
/** Toglie dal giornale le serie eliminate di proposito (dati di prova): non sono «perse». */
export function journalRemove(ids: string[]): void {
  try {
    const drop = new Set(ids);
    localStorage.setItem(KEY, JSON.stringify(journalRead().filter((id) => !drop.has(id))));
  } catch { /* noop */ }
}
