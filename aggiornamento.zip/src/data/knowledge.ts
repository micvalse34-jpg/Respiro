// Libreria esercizi inclusa nell'app. Le versioni sono immutabili: una modifica di contenuto o di classificazione
// crea una nuova versione; le versioni già pubblicate non si toccano mai (le sedute passate le citano).
// Contenuti scritti da Claude con fonti citate (D092): restano «bozza» finché l'utente non segna l'esercizio come provato.
import type { Exercise, ExerciseVersion } from '../domain/types';
import { CATALOG } from './libraryCatalog';
import { WAVE1, WAVE_042, WAVE_043 } from './libraryContent';

const T = '2026-11-23T00:00:00.000Z';

const LEGACY_EXERCISES: Exercise[] = [
  { id: 'ex-021', canonicalName: 'Band Row', createdAt: T },
  { id: 'ex-003', canonicalName: 'Split Squat', createdAt: T },
  { id: 'ex-035', canonicalName: 'Forearm Plank', createdAt: T },
];

export const BAND_ROW_V2 = 'ex-021-v2';

/** Versioni pubblicate fino alla 0.3.3: immutabili, mai modificate. */
const LEGACY_VERSIONS: ExerciseVersion[] = [
  { id: 'ex-021-v1', exerciseId: 'ex-021', version: 1, unilateral: false, measure: 'REPS', breathing: 'Inspira nel ritorno, espira nella trazione', createdAt: T },
  { id: 'ex-003-v1', exerciseId: 'ex-003', version: 1, unilateral: true, measure: 'REPS', breathing: 'Inspira in discesa, espira in risalita', createdAt: T },
  { id: 'ex-035-v1', exerciseId: 'ex-035', version: 1, unilateral: false, measure: 'DURATION', breathing: 'Respirazione regolare e continua', createdAt: T },
  {
    id: BAND_ROW_V2, exerciseId: 'ex-021', version: 2, unilateral: false, measure: 'REPS', createdAt: T,
    breathing: 'Espira mentre tiri verso di te, inspira mentre torni avanti. Non trattenere il respiro.',
    content: {
      displayName: 'Rematore con elastico',
      status: 'DRAFT',
      defaultAnchor: 'DOOR_MID',
      setup: [
        'Ancoraggio alla porta a metà altezza, circa all\'altezza del petto, dal lato in cui la porta si apre allontanandosi da te: tirando, la spingi contro lo stipite.',
        'Porta chiusa a chiave, se possibile, e nessuno che possa aprirla.',
        'Maniglie agli elastici, in piedi di fronte alla porta, piedi alla larghezza delle anche e ginocchia morbide.',
        'La distanza si misura dalla porta alla punta dei piedi. Parti con le braccia tese in avanti e l\'elastico già leggermente teso.',
      ],
      cues: [
        'Porta i gomiti indietro, vicini ai fianchi.',
        'Avvicina le scapole senza alzare le spalle.',
        'Torna avanti lentamente, senza farti tirare dall\'elastico.',
      ],
      commonErrors: [
        'Spalle che salgono verso le orecchie.',
        'Busto che si inclina all\'indietro per aiutarsi a tirare.',
        'Ritorno veloce, trascinato dall\'elastico.',
        'Polsi piegati: tienili in linea con l\'avambraccio.',
      ],
      safetyChecks: [
        'Controlla elastici e maniglie: niente crepe, tagli o zone assottigliate.',
        'Verifica che l\'ancoraggio sia ben chiuso nella porta prima di tendere l\'elastico.',
      ],
    },
  },
];

// --- Versione 0.4.0 (F2, ondata 1): classificazione di tutti i 52 esercizi, contenuto per 18 -----------------------
const T_040 = '2026-11-24T00:00:00.000Z';
const T_042 = '2026-11-24T12:00:00.000Z';
const legacyMax = (id: string) => Math.max(0, ...LEGACY_VERSIONS.filter((v) => v.exerciseId === id).map((v) => v.version));
// Gli esercizi aggiunti dopo la 0.4.0 non fanno parte di questa release: le versioni pubblicate non cambiano mai.
const ADDED_AFTER_040 = new Set(['ex-056']);
const RELEASE_040: ExerciseVersion[] = CATALOG.filter((c) => !ADDED_AFTER_040.has(c.id)).map((c) => {
  const n = legacyMax(c.id) + 1;
  const w = WAVE1[c.id];
  return {
    id: `${c.id}-v${n}`, exerciseId: c.id, version: n, unilateral: c.meta.unilateral, measure: c.meta.measure,
    breathing: w?.breathing ?? null, content: w?.content ?? null, meta: c.meta, createdAt: T_040,
  };
});

export const KNOWLEDGE_EXERCISES: Exercise[] = [
  ...LEGACY_EXERCISES,
  ...CATALOG.filter((c) => !LEGACY_EXERCISES.some((e) => e.id === c.id)).map((c) => ({ id: c.id, canonicalName: c.canonicalName, createdAt: ADDED_AFTER_040.has(c.id) ? T_042 : T_040 })),
];
// --- Versione 0.4.2: EX056 (nuovo). Le versioni della 0.4.0 restano immutabili. ----------------------------------
const RELEASE_042: ExerciseVersion[] = Object.entries(WAVE_042).map(([id, w]) => {
  const c = CATALOG.find((x) => x.id === id)!;
  const prev = [...LEGACY_VERSIONS, ...RELEASE_040].filter((v) => v.exerciseId === id).length;
  return { id: `${id}-v${prev + 1}`, exerciseId: id, version: prev + 1, unilateral: c.meta.unilateral, measure: c.meta.measure, breathing: w.breathing, content: w.content, meta: c.meta, createdAt: T_042 };
});

// --- Versione 0.4.3: seconda ondata di schede (nuove versioni degli esercizi che avevano solo la classificazione) ---
const T_043 = '2026-11-25T00:00:00.000Z';
const RELEASE_043: ExerciseVersion[] = Object.entries(WAVE_043).map(([id, w]) => {
  const c = CATALOG.find((x) => x.id === id)!;
  const prev = [...LEGACY_VERSIONS, ...RELEASE_040, ...RELEASE_042].filter((v) => v.exerciseId === id).length;
  return { id: `${id}-v${prev + 1}`, exerciseId: id, version: prev + 1, unilateral: c.meta.unilateral, measure: c.meta.measure, breathing: w.breathing, content: w.content, meta: c.meta, createdAt: T_043 };
});

export const KNOWLEDGE_VERSIONS: ExerciseVersion[] = [...LEGACY_VERSIONS, ...RELEASE_040, ...RELEASE_042, ...RELEASE_043];

/** Versione più recente di ogni esercizio: è quella usata dalle nuove sedute. */
const CURRENT = new Map<string, ExerciseVersion>();
for (const v of KNOWLEDGE_VERSIONS) { const c = CURRENT.get(v.exerciseId); if (!c || v.version > c.version) CURRENT.set(v.exerciseId, v); }
export const currentVersion = (exerciseId: string): ExerciseVersion | undefined => CURRENT.get(exerciseId);
export const BAND_ROW_CURRENT = currentVersion('ex-021')!.id;
