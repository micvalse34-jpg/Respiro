// Catalogo V1: 53 esercizi (47 dei 50 di D038 + 5 nuovi di D093 + EX056 per gli estensori della schiena, D105). EX011, EX022 ed EX038 sono diventati varianti
// (di ex-010 ed ex-021) e i loro numeri non vengono riutilizzati. Classificazione scritta da Claude (D092): bozza.
// Parametri di default = valori PROVISIONAL di 26 (D039), non prescrizioni.
import type { ExerciseMeta } from '../domain/library';

export interface CatalogEntry { id: string; canonicalName: string; displayName: string; meta: ExerciseMeta }

type M = Partial<ExerciseMeta> & Pick<ExerciseMeta, 'group' | 'pattern'>;
const base: Omit<ExerciseMeta, 'group' | 'pattern'> = {
  primary: [], secondary: [], joints: [], functions: [], equipment: [], needs: [], setup: 'NONE', anchor: null,
  complexity: 1, unilateral: false, repsPerSide: false, measure: 'REPS', effort: 'RIR',
  defaults: { sets: [2, 3], reps: [8, 15], durationS: null, rir: [2, 4] },
};
const e = (id: string, canonicalName: string, displayName: string, m: M): CatalogEntry => ({ id, canonicalName, displayName, meta: { ...base, ...m } });

// Default ricorrenti (26 «Parametri iniziali PROVISIONAL»).
const MULTI = { sets: [2, 3], reps: [8, 15], durationS: null, rir: [2, 4] } as ExerciseMeta['defaults'];
const COMPL = { sets: [2, 3], reps: [10, 20], durationS: null, rir: [2, 4] } as ExerciseMeta['defaults'];
const UNI = { sets: [2, 3], reps: [6, 12], durationS: null, rir: [2, 4] } as ExerciseMeta['defaults'];
const CORE_DYN = { sets: [2, 3], reps: [6, 12], durationS: null, rir: null } as ExerciseMeta['defaults'];
const ISO = { sets: [2, 3], reps: null, durationS: [20, 40], rir: null } as ExerciseMeta['defaults'];
const MOB_REPS = { sets: [1, 2], reps: [6, 10], durationS: null, rir: null } as ExerciseMeta['defaults'];
const STRETCH = { sets: [1, 2], reps: null, durationS: [20, 40], rir: null } as ExerciseMeta['defaults'];
const COND = { sets: [2, 4], reps: null, durationS: [30, 60], rir: null } as ExerciseMeta['defaults'];

const TUBE = ['RESISTANCE_BAND', 'HANDLE'] as const;
const DOOR = ['RESISTANCE_BAND', 'HANDLE', 'DOOR_ANCHOR'] as const;
const MAT = ['YOGA_MAT'] as const;

export const CATALOG: CatalogEntry[] = [
  // --- Gambe ---------------------------------------------------------------------------------------------
  e('ex-001', 'Bodyweight Squat', 'Squat a corpo libero', { group: 'LEGS', pattern: 'SQUAT', primary: ['QUADS', 'GLUTE_MAX'], secondary: ['ADDUCTORS'], functions: ['STRENGTH', 'MOTOR_CONTROL'], defaults: MULTI }),
  e('ex-002', 'Resistance Band Squat', 'Squat con elastico', { group: 'LEGS', pattern: 'SQUAT', primary: ['QUADS', 'GLUTE_MAX'], secondary: ['ADDUCTORS'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...TUBE], setup: 'TUBE_FREE', defaults: MULTI }),
  e('ex-003', 'Split Squat', 'Split squat (affondo da fermo)', { group: 'LEGS', pattern: 'LUNGE', primary: ['QUADS', 'GLUTE_MAX'], secondary: ['ADDUCTORS'], functions: ['STRENGTH', 'HYPERTROPHY', 'BALANCE'], complexity: 2, unilateral: true, defaults: UNI }),
  e('ex-004', 'Reverse Lunge', 'Affondo indietro', { group: 'LEGS', pattern: 'LUNGE', primary: ['QUADS', 'GLUTE_MAX'], secondary: ['HAMSTRINGS', 'ADDUCTORS'], functions: ['STRENGTH', 'BALANCE'], complexity: 2, unilateral: true, defaults: UNI }),
  e('ex-005', 'Lateral Lunge', 'Affondo laterale', { group: 'LEGS', pattern: 'LUNGE', primary: ['QUADS', 'GLUTE_MAX', 'ADDUCTORS'], secondary: ['GLUTE_MED'], functions: ['STRENGTH', 'MOBILITY'], complexity: 2, unilateral: true, defaults: UNI }),
  e('ex-007', 'Bodyweight Hip Hinge', 'Piegamento dalle anche (hip hinge)', { group: 'LEGS', pattern: 'HINGE', primary: ['HAMSTRINGS', 'GLUTE_MAX'], secondary: ['ERECTORS'], functions: ['MOTOR_CONTROL'], effort: 'NONE', defaults: { sets: [1, 2], reps: [8, 12], durationS: null, rir: null } }),
  e('ex-008', 'Band Romanian Deadlift', 'Stacco rumeno con elastico', { group: 'LEGS', pattern: 'HINGE', primary: ['HAMSTRINGS', 'GLUTE_MAX'], secondary: ['ERECTORS', 'FOREARMS'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...TUBE], setup: 'TUBE_FREE', complexity: 2, defaults: MULTI }),
  e('ex-009', 'Assisted Single-Leg RDL', 'Stacco a una gamba con appoggio', { group: 'LEGS', pattern: 'HINGE', primary: ['HAMSTRINGS', 'GLUTE_MAX'], secondary: ['GLUTE_MED', 'ERECTORS'], functions: ['STRENGTH', 'BALANCE', 'MOTOR_CONTROL'], needs: ['SUPPORT'], complexity: 2, unilateral: true, defaults: UNI }),
  e('ex-010', 'Glute Bridge', 'Ponte per i glutei', { group: 'LEGS', pattern: 'HIP_EXTENSION', primary: ['GLUTE_MAX'], secondary: ['HAMSTRINGS'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...MAT], defaults: COMPL }),
  e('ex-012', 'Band Hamstring Curl', 'Curl dei femorali con elastico', { group: 'LEGS', pattern: 'KNEE_FLEXION', primary: ['HAMSTRINGS'], secondary: ['CALVES'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: ['RESISTANCE_BAND', 'DOOR_ANCHOR', 'ANKLE_STRAP', 'YOGA_MAT'], setup: 'TUBE_DOOR', anchor: 'DOOR_LOW', complexity: 2, unilateral: true, defaults: COMPL }),
  e('ex-013', 'Standing Calf Raise', 'Sollevamento sui polpacci in piedi', { group: 'LEGS', pattern: 'ANKLE_PLANTAR_FLEXION', primary: ['CALVES'], functions: ['STRENGTH', 'HYPERTROPHY'], needs: ['WALL'], defaults: COMPL }),
  e('ex-014', 'Bent-Knee Calf Raise', 'Polpacci a ginocchia piegate', { group: 'LEGS', pattern: 'ANKLE_PLANTAR_FLEXION', primary: ['CALVES'], functions: ['STRENGTH', 'HYPERTROPHY'], needs: ['WALL'], defaults: COMPL }),
  e('ex-015', 'Lateral Band Walk', 'Passi laterali con elastico ad anello', { group: 'LEGS', pattern: 'ISOLATION', primary: ['GLUTE_MED'], secondary: ['GLUTE_MAX'], functions: ['STRENGTH', 'STABILITY'], equipment: ['LOOP_BAND'], setup: 'LOOP', repsPerSide: true, defaults: COMPL }),
  e('ex-049', 'Side-Lying Hip Abduction', 'Apertura della gamba su un fianco', { group: 'LEGS', pattern: 'ISOLATION', primary: ['GLUTE_MED'], functions: ['STRENGTH'], equipment: [...MAT], unilateral: true, defaults: COMPL }),
  e('ex-051', 'Pilates Ball Adductor Squeeze', 'Stringere la palla tra le ginocchia', { group: 'LEGS', pattern: 'ISOLATION', primary: ['ADDUCTORS'], secondary: ['CORE'], functions: ['STRENGTH'], equipment: ['PILATES_BALL', 'YOGA_MAT'], effort: 'NONE', defaults: { sets: [2, 3], reps: [8, 12], durationS: null, rir: null } }),
  e('ex-052', 'Standing Band Hip Adduction', 'Adduzione in piedi con elastico', { group: 'LEGS', pattern: 'ISOLATION', primary: ['ADDUCTORS'], secondary: ['GLUTE_MED'], functions: ['STRENGTH'], equipment: ['RESISTANCE_BAND', 'DOOR_ANCHOR', 'ANKLE_STRAP'], needs: ['SUPPORT'], setup: 'TUBE_DOOR', anchor: 'DOOR_LOW', complexity: 2, unilateral: true, defaults: COMPL }),
  e('ex-053', 'Fitball Hamstring Curl', 'Curl dei femorali sulla fitball', { group: 'LEGS', pattern: 'KNEE_FLEXION', primary: ['HAMSTRINGS'], secondary: ['GLUTE_MAX', 'CORE'], functions: ['STRENGTH', 'STABILITY'], equipment: ['FITBALL', 'YOGA_MAT'], complexity: 2, defaults: MULTI }),
  // --- Spinte --------------------------------------------------------------------------------------------
  e('ex-016', 'Incline Push-Up', 'Piegamenti inclinati', { group: 'PUSH', pattern: 'HORIZONTAL_PUSH', primary: ['CHEST', 'TRICEPS'], secondary: ['DELT_ANT', 'CORE'], functions: ['STRENGTH', 'HYPERTROPHY'], needs: ['SUPPORT'], defaults: MULTI }),
  e('ex-017', 'Push-Up', 'Piegamenti', { group: 'PUSH', pattern: 'HORIZONTAL_PUSH', primary: ['CHEST', 'TRICEPS'], secondary: ['DELT_ANT', 'CORE'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...MAT], complexity: 2, defaults: MULTI }),
  e('ex-018', 'Band Chest Press', 'Spinta al petto con elastico', { group: 'PUSH', pattern: 'HORIZONTAL_PUSH', primary: ['CHEST', 'TRICEPS'], secondary: ['DELT_ANT'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...DOOR], setup: 'TUBE_DOOR', anchor: 'DOOR_MID', defaults: MULTI }),
  e('ex-019', 'Band Shoulder Press', 'Spinta sopra la testa con elastico', { group: 'PUSH', pattern: 'VERTICAL_PUSH', primary: ['DELT_ANT', 'TRICEPS'], secondary: ['DELT_LAT', 'CORE'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...TUBE], setup: 'TUBE_FREE', complexity: 2, defaults: MULTI }),
  // --- Tirate --------------------------------------------------------------------------------------------
  e('ex-021', 'Band Row', 'Rematore con elastico', { group: 'PULL', pattern: 'HORIZONTAL_PULL', primary: ['LATS', 'MID_BACK'], secondary: ['DELT_POST', 'BICEPS'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...DOOR], setup: 'TUBE_DOOR', anchor: 'DOOR_MID', defaults: MULTI }),
  e('ex-023', 'Band High Row', 'Rematore alto con elastico', { group: 'PULL', pattern: 'HORIZONTAL_PULL', primary: ['MID_BACK', 'DELT_POST'], secondary: ['LATS', 'BICEPS'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...DOOR], setup: 'TUBE_DOOR', anchor: 'DOOR_HIGH', defaults: MULTI }),
  e('ex-024', 'Band Lat Pulldown', 'Tirata verso il basso con elastico', { group: 'PULL', pattern: 'VERTICAL_PULL', primary: ['LATS'], secondary: ['BICEPS', 'MID_BACK'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...DOOR, 'YOGA_MAT'], setup: 'TUBE_DOOR', anchor: 'DOOR_HIGH', defaults: MULTI }),
  e('ex-025', 'Band Face Pull', 'Tirata al viso con elastico (face pull)', { group: 'PULL', pattern: 'HORIZONTAL_PULL', primary: ['DELT_POST', 'MID_BACK'], secondary: ['ROTATOR_CUFF'], functions: ['STRENGTH', 'MOTOR_CONTROL'], equipment: [...DOOR], setup: 'TUBE_DOOR', anchor: 'DOOR_HIGH', defaults: COMPL }),
  e('ex-026', 'Band Pull-Apart', 'Aperture con elastico ad anello', { group: 'PULL', pattern: 'ISOLATION', primary: ['DELT_POST', 'MID_BACK'], functions: ['STRENGTH', 'MOTOR_CONTROL'], equipment: ['LOOP_BAND'], setup: 'LOOP', defaults: COMPL }),
  e('ex-027', 'Band Reverse Fly', 'Aperture posteriori con elastico', { group: 'PULL', pattern: 'ISOLATION', primary: ['DELT_POST'], secondary: ['MID_BACK'], functions: ['STRENGTH', 'HYPERTROPHY'], equipment: [...DOOR], setup: 'TUBE_DOOR', anchor: 'DOOR_MID', defaults: COMPL }),
  // --- Braccia e spalle -----------------------------------------------------------------------------------
  e('ex-020', 'Band Lateral Raise', 'Alzate laterali con elastico', { group: 'ARMS_SHOULDERS', pattern: 'ISOLATION', primary: ['DELT_LAT'], functions: ['HYPERTROPHY'], equipment: [...TUBE], setup: 'TUBE_FREE', defaults: COMPL }),
  e('ex-028', 'Band External Rotation', 'Rotazione esterna della spalla con elastico', { group: 'ARMS_SHOULDERS', pattern: 'ISOLATION', primary: ['ROTATOR_CUFF'], secondary: ['DELT_POST'], functions: ['STRENGTH', 'MOTOR_CONTROL'], equipment: [...DOOR], setup: 'TUBE_DOOR', anchor: 'DOOR_MID', unilateral: true, defaults: COMPL }),
  e('ex-029', 'Band Biceps Curl', 'Curl dei bicipiti con elastico', { group: 'ARMS_SHOULDERS', pattern: 'ISOLATION', primary: ['BICEPS'], secondary: ['FOREARMS'], functions: ['HYPERTROPHY'], equipment: [...TUBE], setup: 'TUBE_FREE', defaults: COMPL }),
  e('ex-030', 'Band Hammer Curl', 'Curl a martello con elastico', { group: 'ARMS_SHOULDERS', pattern: 'ISOLATION', primary: ['BICEPS', 'FOREARMS'], functions: ['HYPERTROPHY'], equipment: [...TUBE], setup: 'TUBE_FREE', defaults: COMPL }),
  e('ex-031', 'Band Triceps Pushdown', 'Spinta in basso per i tricipiti con elastico', { group: 'ARMS_SHOULDERS', pattern: 'ISOLATION', primary: ['TRICEPS'], functions: ['HYPERTROPHY'], equipment: [...DOOR], setup: 'TUBE_DOOR', anchor: 'DOOR_HIGH', defaults: COMPL }),
  e('ex-032', 'Band Overhead Triceps Extension', 'Estensione dei tricipiti sopra la testa con elastico', { group: 'ARMS_SHOULDERS', pattern: 'ISOLATION', primary: ['TRICEPS'], secondary: ['CORE'], functions: ['HYPERTROPHY'], equipment: [...DOOR], setup: 'TUBE_DOOR', anchor: 'DOOR_LOW', complexity: 2, defaults: COMPL }),
  // --- Core ----------------------------------------------------------------------------------------------
  e('ex-033', 'Dead Bug', 'Dead bug (scarafaggio)', { group: 'CORE', pattern: 'ANTI_EXTENSION', primary: ['CORE'], secondary: ['HIP_FLEXORS'], functions: ['STABILITY', 'MOTOR_CONTROL'], equipment: [...MAT], repsPerSide: true, effort: 'NONE', defaults: CORE_DYN }),
  e('ex-034', 'Bird Dog', 'Bird dog (cane da caccia)', { group: 'CORE', pattern: 'ANTI_ROTATION', primary: ['CORE'], secondary: ['GLUTE_MAX', 'ERECTORS'], functions: ['STABILITY', 'MOTOR_CONTROL'], equipment: [...MAT], repsPerSide: true, effort: 'NONE', defaults: CORE_DYN }),
  e('ex-035', 'Forearm Plank', 'Plank sugli avambracci', { group: 'CORE', pattern: 'ANTI_EXTENSION', primary: ['CORE'], secondary: ['DELT_ANT', 'GLUTE_MAX'], functions: ['STABILITY'], equipment: [...MAT], measure: 'DURATION', effort: 'NONE', defaults: ISO }),
  e('ex-036', 'Side Plank', 'Plank laterale', { group: 'CORE', pattern: 'ANTI_LATERAL_FLEXION', primary: ['CORE'], secondary: ['GLUTE_MED'], functions: ['STABILITY'], equipment: [...MAT], complexity: 2, unilateral: true, measure: 'DURATION', effort: 'NONE', defaults: ISO }),
  e('ex-056', 'Prone Back Extension', 'Estensione della schiena da prono', { group: 'CORE', pattern: 'ANTI_EXTENSION', primary: ['ERECTORS'], secondary: ['GLUTE_MAX', 'MID_BACK'], functions: ['STABILITY', 'STRENGTH'], equipment: [...MAT], measure: 'DURATION', effort: 'NONE', defaults: { sets: [2, 3], reps: null, durationS: [20, 45], rir: null } }),
  e('ex-037', 'Pallof Press', 'Pallof press (spinta antirotazione)', { group: 'CORE', pattern: 'ANTI_ROTATION', primary: ['CORE'], secondary: ['GLUTE_MED'], functions: ['STABILITY'], equipment: [...DOOR], setup: 'TUBE_DOOR', anchor: 'DOOR_MID', unilateral: true, defaults: { sets: [2, 3], reps: [8, 12], durationS: null, rir: [2, 4] } }),
  // --- Equilibrio ----------------------------------------------------------------------------------------
  e('ex-006', 'Single-Leg Balance', 'Equilibrio su una gamba', { group: 'BALANCE', pattern: 'BALANCE', secondary: ['GLUTE_MED', 'FOOT'], functions: ['BALANCE'], unilateral: true, measure: 'DURATION', effort: 'NONE', defaults: { sets: [2, 3], reps: null, durationS: [20, 30], rir: null } }),
  e('ex-050', 'Short Foot Exercise', 'Piede corto (attivazione dell\'arco)', { group: 'BALANCE', pattern: 'MOBILITY_CONTROL', primary: ['FOOT'], functions: ['MOTOR_CONTROL', 'BALANCE'], effort: 'NONE', defaults: { sets: [1, 2], reps: [6, 10], durationS: null, rir: null } }),
  // --- Mobilità ------------------------------------------------------------------------------------------
  e('ex-039', 'Knee-to-Wall', 'Ginocchio al muro (caviglia)', { group: 'MOBILITY', pattern: 'MOBILITY_CONTROL', joints: ['ANKLE'], functions: ['MOBILITY'], needs: ['WALL'], unilateral: true, effort: 'NONE', defaults: { sets: [1, 2], reps: [8, 10], durationS: null, rir: null } }),
  e('ex-040', '90/90 Hip Transitions', 'Passaggi 90/90 per le anche', { group: 'MOBILITY', pattern: 'MOBILITY_CONTROL', joints: ['HIP'], functions: ['MOBILITY', 'MOTOR_CONTROL'], equipment: [...MAT], complexity: 2, repsPerSide: true, effort: 'NONE', defaults: MOB_REPS }),
  e('ex-041', 'Half-Kneeling Hip Flexor Stretch', 'Allungamento dei flessori dell\'anca in ginocchio', { group: 'MOBILITY', pattern: 'MOBILITY_CONTROL', joints: ['HIP'], functions: ['MOBILITY'], equipment: [...MAT], unilateral: true, measure: 'DURATION', effort: 'NONE', defaults: STRETCH }),
  e('ex-042', 'Open Book', 'Libro aperto (rotazione del torace)', { group: 'MOBILITY', pattern: 'MOBILITY_CONTROL', joints: ['THORACIC'], functions: ['MOBILITY'], equipment: [...MAT], unilateral: true, effort: 'NONE', defaults: MOB_REPS }),
  e('ex-043', 'Wall Slide', 'Scivolamento delle braccia al muro', { group: 'MOBILITY', pattern: 'MOBILITY_CONTROL', joints: ['SHOULDER', 'THORACIC'], functions: ['MOBILITY', 'MOTOR_CONTROL'], needs: ['WALL'], effort: 'NONE', defaults: { sets: [1, 2], reps: [8, 12], durationS: null, rir: null } }),
  e('ex-044', 'Cat-Cow', 'Gatto e mucca', { group: 'MOBILITY', pattern: 'MOBILITY_CONTROL', joints: ['SPINE'], functions: ['MOBILITY'], equipment: [...MAT], effort: 'NONE', defaults: MOB_REPS }),
  e('ex-054', 'Strap Hamstring Stretch', 'Allungamento del retro della coscia con cinghia', { group: 'MOBILITY', pattern: 'MOBILITY_CONTROL', joints: ['HAMSTRINGS_LENGTH'], functions: ['MOBILITY'], equipment: ['YOGA_STRAP', 'YOGA_MAT'], unilateral: true, measure: 'DURATION', effort: 'NONE', defaults: STRETCH }),
  e('ex-055', 'Foam Roller Thoracic Extension', 'Estensione del torace sul rullo', { group: 'MOBILITY', pattern: 'MOBILITY_CONTROL', joints: ['THORACIC'], functions: ['MOBILITY'], equipment: ['FOAM_ROLLER', 'YOGA_MAT'], effort: 'NONE', defaults: MOB_REPS }),
  // --- Fiato (condizionamento a basso impatto) -----------------------------------------------------------------
  e('ex-045', 'Marching in Place', 'Marcia sul posto', { group: 'CONDITIONING', pattern: 'LOCOMOTION', functions: ['CONDITIONING'], measure: 'DURATION', effort: 'NONE', defaults: { sets: [2, 4], reps: null, durationS: [60, 120], rir: null } }),
  e('ex-046', 'Step Jack', 'Step jack (saltelli senza salto)', { group: 'CONDITIONING', pattern: 'LOCOMOTION', functions: ['CONDITIONING'], measure: 'DURATION', effort: 'NONE', defaults: COND }),
  e('ex-047', 'Low-Impact Skater Step', 'Passo del pattinatore senza salto', { group: 'CONDITIONING', pattern: 'LOCOMOTION', secondary: ['GLUTE_MED', 'QUADS'], functions: ['CONDITIONING', 'BALANCE'], complexity: 2, measure: 'DURATION', effort: 'NONE', defaults: COND }),
  e('ex-048', 'Shadow Boxing', 'Boxe a vuoto', { group: 'CONDITIONING', pattern: 'LOCOMOTION', secondary: ['DELT_ANT', 'CORE'], functions: ['CONDITIONING', 'MOTOR_CONTROL'], measure: 'DURATION', effort: 'NONE', defaults: COND }),
];

const byId = new Map(CATALOG.map((c) => [c.id, c]));
export const catalogEntry = (id: string): CatalogEntry | undefined => byId.get(id);
/** Nome italiano per l'interfaccia (lo storico conserva il nome canonico). */
export const exerciseName = (id: string, fallback?: string): string => byId.get(id)?.displayName ?? fallback ?? id;
