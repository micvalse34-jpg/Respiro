// Libreria esercizi: elenco con stato della scheda e attrezzatura mancante; «provata» registrata come decisione dell'utente (D092).
import { nowIso, uuidv7 } from '../domain/ids';
import { missingEquipment } from '../domain/library';
import type { EquipmentType, ExerciseVersion } from '../domain/types';
import { DomainError } from './errors';
import { currentVersion } from './knowledge';
import { CATALOG, type CatalogEntry } from './libraryCatalog';
import type { FitDb } from './schema';

/**
 * IN_PREPARATION: scheda non ancora scritta. DRAFT: bozza scritta da Claude. TESTED: provata dall'utente.
 * NEEDS_REVIEW: l'utente ha segnalato un problema sulla versione corrente (D103); torna DRAFT con la versione corretta.
 */
export type CardStatus = 'IN_PREPARATION' | 'DRAFT' | 'TESTED' | 'NEEDS_REVIEW';
export const CARD_STATUS_NAMES: Record<CardStatus, string> = { IN_PREPARATION: 'Scheda in arrivo', DRAFT: 'Bozza', TESTED: 'Provata', NEEDS_REVIEW: 'Da rivedere' };

export type ProblemReason = 'UNCLEAR' | 'SETUP' | 'UNCOMFORTABLE' | 'DIFFICULTY' | 'OTHER';
export const PROBLEM_REASONS: Record<ProblemReason, string> = {
  UNCLEAR: 'Istruzioni poco chiare', SETUP: 'Impostazione impossibile a casa mia', UNCOMFORTABLE: 'Scomodo o fastidioso',
  DIFFICULTY: 'Troppo facile o troppo difficile', OTHER: 'Altro',
};
export interface Problem { reason: ProblemReason; note: string | null; at: string; versionId: string }

export interface LibraryItem {
  entry: CatalogEntry; version: ExerciseVersion; status: CardStatus; missing: EquipmentType[]; testedAt: string | null;
  problem: Problem | null; excluded: boolean;
}

const FEEDBACK = ['EXERCISE_TESTED', 'EXERCISE_TEST_REVOKED', 'EXERCISE_PROBLEM_REPORTED', 'EXERCISE_PROBLEM_WITHDRAWN'];
type Feedback = { decision: string; versionId: string; at: string; reason?: ProblemReason; note?: string | null };

/** Tipi di attrezzo utilizzabili: oggetti in uso e non danneggiati. */
export async function availableTypes(db: FitDb): Promise<Set<EquipmentType>> {
  const items = await db.equipmentItems.filter((i) => i.status === 'ACTIVE' && i.integrity !== 'DAMAGED').toArray();
  return new Set(items.map((i) => i.type));
}

/**
 * Ultimo riscontro dell'utente per esercizio («provata», tolta, problema segnalato, segnalazione ritirata).
 * Vale per la versione su cui è stato dato: una nuova versione del testo torna «bozza».
 */
export async function feedbackMarks(db: FitDb): Promise<Map<string, Feedback>> {
  const logs = (await db.decisionLog.filter((l) => FEEDBACK.includes(l.decision)).toArray()).sort((a, b) => a.ts.localeCompare(b.ts) || a.id.localeCompare(b.id));
  const out = new Map<string, Feedback>();
  for (const l of logs) {
    const i = l.input as { exerciseId: string; versionId: string; reason?: ProblemReason; note?: string | null };
    out.set(i.exerciseId, { decision: l.decision, versionId: i.versionId, at: l.ts, reason: i.reason, note: i.note ?? null });
  }
  return out;
}

export function statusOf(version: ExerciseVersion, mark: Pick<Feedback, 'decision' | 'versionId'> | undefined): CardStatus {
  if (!version.content) return 'IN_PREPARATION';
  if (!mark || mark.versionId !== version.id) return 'DRAFT';
  if (mark.decision === 'EXERCISE_TESTED') return 'TESTED';
  if (mark.decision === 'EXERCISE_PROBLEM_REPORTED') return 'NEEDS_REVIEW';
  return 'DRAFT';
}

/** Esercizi che l'utente non vuole vedersi proporre dal motore (D103). La scelta manuale resta libera. */
export async function excludedExercises(db: FitDb): Promise<Set<string>> {
  const logs = (await db.decisionLog.filter((l) => l.decision === 'EXERCISE_EXCLUDED' || l.decision === 'EXERCISE_INCLUDED').toArray()).sort((a, b) => a.ts.localeCompare(b.ts) || a.id.localeCompare(b.id));
  const out = new Set<string>();
  for (const l of logs) { const id = (l.input as { exerciseId: string }).exerciseId; if (l.decision === 'EXERCISE_EXCLUDED') out.add(id); else out.delete(id); }
  return out;
}

export async function libraryItems(db: FitDb): Promise<LibraryItem[]> {
  const types = await availableTypes(db);
  const marks = await feedbackMarks(db);
  const excluded = await excludedExercises(db);
  return CATALOG.map((entry) => {
    const version = currentVersion(entry.id)!;
    const mark = marks.get(entry.id);
    const status = statusOf(version, mark);
    return {
      entry, version, status, missing: missingEquipment(entry.meta, types),
      testedAt: status === 'TESTED' ? mark!.at : null,
      problem: status === 'NEEDS_REVIEW' ? { reason: mark!.reason ?? 'OTHER', note: mark!.note ?? null, at: mark!.at, versionId: mark!.versionId } : null,
      excluded: excluded.has(entry.id),
    };
  });
}

/** Segna (o toglie) «provata» sulla versione corrente. Solo aggiunte al decision log: lo storico resta. */
export async function setTested(db: FitDb, exerciseId: string, tested: boolean): Promise<void> {
  const v = requireContent(exerciseId);
  await db.decisionLog.add({
    id: uuidv7(), ts: nowIso(), engine: 'user', ruleVersion: 'library-1', input: { exerciseId, versionId: v.id },
    decision: tested ? 'EXERCISE_TESTED' : 'EXERCISE_TEST_REVOKED',
    reason: tested ? 'Scheda provata a casa: si capisce e l\'impostazione funziona (D092)' : 'Segno «provata» tolto dall\'utente',
  });
}

const requireContent = (exerciseId: string) => {
  const v = currentVersion(exerciseId);
  if (!v || !v.content) throw new DomainError('CONTENT_NOT_READY', 'La scheda di questo esercizio è ancora in preparazione');
  return v;
};

/** Segnala un problema sulla scheda corrente (D103): la scheda diventa «Da rivedere» finché Claude non la corregge. */
export async function reportProblem(db: FitDb, exerciseId: string, reason: ProblemReason, note: string | null): Promise<void> {
  const v = requireContent(exerciseId);
  const clean = note?.trim() ? note.trim().slice(0, 1000) : null;
  await db.decisionLog.add({
    id: uuidv7(), ts: nowIso(), engine: 'user', ruleVersion: 'library-2', input: { exerciseId, versionId: v.id, reason, note: clean },
    decision: 'EXERCISE_PROBLEM_REPORTED', reason: `Problema segnalato: ${PROBLEM_REASONS[reason]}`,
  });
}

export async function withdrawProblem(db: FitDb, exerciseId: string): Promise<void> {
  const v = requireContent(exerciseId);
  await db.decisionLog.add({ id: uuidv7(), ts: nowIso(), engine: 'user', ruleVersion: 'library-2', input: { exerciseId, versionId: v.id }, decision: 'EXERCISE_PROBLEM_WITHDRAWN', reason: 'Segnalazione ritirata dall\'utente' });
}

export async function setExcluded(db: FitDb, exerciseId: string, excluded: boolean): Promise<void> {
  if (!CATALOG.some((c) => c.id === exerciseId)) throw new DomainError('UNKNOWN_EXERCISE', 'Esercizio non presente nella libreria');
  await db.decisionLog.add({
    id: uuidv7(), ts: nowIso(), engine: 'user', ruleVersion: 'library-2', input: { exerciseId },
    decision: excluded ? 'EXERCISE_EXCLUDED' : 'EXERCISE_INCLUDED',
    reason: excluded ? 'L\'utente non vuole che il motore proponga questo esercizio (D103)' : 'Esercizio di nuovo proponibile',
  });
}

/** Testo delle segnalazioni aperte, da mandare a Claude per correggere le schede. */
export async function problemReportText(db: FitDb, appVersion: string): Promise<string | null> {
  const open = (await libraryItems(db)).filter((i) => i.problem);
  if (!open.length) return null;
  const lines = open.map((i) => `- ${i.entry.id} ${i.entry.displayName} (${i.version.id}) — ${PROBLEM_REASONS[i.problem!.reason]}${i.problem!.note ? `: ${i.problem!.note}` : ''} [${i.problem!.at.slice(0, 10)}]`);
  return `Segnalazioni sulle schede FitPRO (app ${appVersion}), ${open.length}:\n${lines.join('\n')}`;
}
