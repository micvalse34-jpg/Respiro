import { nowIso, tzOffset, uuidv7 } from '../domain/ids';
import { profileErrors, sameProfile, type ProfileInput } from '../domain/profile';
import type { ProfileVersion } from '../domain/types';
import { DomainError } from './errors';
import type { FitDb } from './schema';

export async function getCurrentProfile(db: FitDb): Promise<ProfileVersion | null> {
  return (await db.profileVersions.orderBy('recordedAt').last()) ?? null;
}

export async function countProfileVersions(db: FitDb): Promise<number> {
  return db.profileVersions.count();
}

/**
 * Salvataggio non distruttivo: ogni modifica crea una nuova versione; le precedenti restano invariate.
 * Se nulla è cambiato non scrive niente ('unchanged').
 */
export async function saveProfile(db: FitDb, input: ProfileInput): Promise<{ outcome: 'saved' | 'unchanged'; profile: ProfileVersion }> {
  const errors = profileErrors(input);
  if (errors.length) throw new DomainError('INVALID_PROFILE', errors.join(' '));
  return db.transaction('rw', db.profileVersions, async () => {
    const cur = await getCurrentProfile(db);
    if (cur && sameProfile(cur, input)) return { outcome: 'unchanged' as const, profile: cur };
    const p: ProfileVersion = { id: uuidv7(), ...input, recordedAt: nowIso(), tzOffsetMin: tzOffset() };
    await db.profileVersions.add(p);
    return { outcome: 'saved' as const, profile: p };
  });
}
