import Dexie from 'dexie';
import { nowIso, tzOffset, uuidv7 } from '../domain/ids';
import type {
  ConfigurationSnapshot, ExercisePrescription, SetPerformance, Side, WorkoutSession, CloseReason, SessionStatus, RestRecord } from '../domain/types';
import { DomainError } from './errors';
import { KNOWLEDGE_EXERCISES, KNOWLEDGE_VERSIONS } from './knowledge';
import { FitDb } from './schema';

// Soglie del controllo di plausibilità (ADV06). PROVISIONAL: da calibrare, non validate.
export const PLAUSIBILITY = { maxReps: 60, maxDurationS: 600 } as const;

export const SEED = {
  bandRow: { exerciseId: 'ex-021', versionId: 'ex-021-v1' },
  splitSquat: { exerciseId: 'ex-003', versionId: 'ex-003-v1' },
  plank: { exerciseId: 'ex-035', versionId: 'ex-035-v1' },
} as const;

/** Inserisce gli esercizi e le versioni mancanti. Non modifica mai quelli presenti (versioni immutabili). */
export async function seedKnowledge(db: FitDb): Promise<void> {
  await db.transaction('rw', db.exercises, db.exerciseVersions, async () => {
    const haveEx = new Set((await db.exercises.toCollection().primaryKeys()) as string[]);
    const haveVer = new Set((await db.exerciseVersions.toCollection().primaryKeys()) as string[]);
    const ex = KNOWLEDGE_EXERCISES.filter((e) => !haveEx.has(e.id));
    const ver = KNOWLEDGE_VERSIONS.filter((v) => !haveVer.has(v.id));
    if (ex.length) await db.exercises.bulkAdd(ex);
    if (ver.length) await db.exerciseVersions.bulkAdd(ver);
  });
}

/**
 * Crea una seduta di PROVA (sessionType 'POC') con tre prescrizioni (reps bilaterale, reps unilaterale, durata).
 * Serve ai test su dispositivo e a verificare lo Storico; non è un allenamento generato dal motore.
 * bandIds: elastici censiti da riportare nello snapshot del Band Row (nessuno → snapshot assente).
 */
export async function startPocSession(db: FitDb, bandIds: string[] = []): Promise<WorkoutSession> {
  const t = nowIso();
  const session: WorkoutSession = {
    id: uuidv7(), sessionType: 'POC', status: 'IN_PROGRESS', startedAt: t,
    tzOffsetMin: tzOffset(), endedAt: null, updatedAt: t, closeReason: null,
  };
  const base = { sessionId: session.id, origin: 'ENGINE' as const, createdAt: t };
  const prescriptions: ExercisePrescription[] = [
    { ...base, id: uuidv7(), exerciseId: SEED.bandRow.exerciseId, exerciseVersionId: SEED.bandRow.versionId, order: 1, prescribedSets: 3, repMin: 8, repMax: 15, targetDurationS: null, targetRir: 2, sidesPerSet: ['BILATERAL'],
      configurationSnapshot: bandIds.length ? { configurationId: null, bandIds, anchor: 'door', anchorHeightCm: null, distanceCm: null, notes: 'Seduta di prova' } : null },
    { ...base, id: uuidv7(), exerciseId: SEED.splitSquat.exerciseId, exerciseVersionId: SEED.splitSquat.versionId, order: 2, prescribedSets: 2, repMin: 6, repMax: 12, targetDurationS: null, targetRir: 2, sidesPerSet: ['LEFT', 'RIGHT'], configurationSnapshot: null },
    { ...base, id: uuidv7(), exerciseId: SEED.plank.exerciseId, exerciseVersionId: SEED.plank.versionId, order: 3, prescribedSets: 2, repMin: null, repMax: null, targetDurationS: 30, targetRir: null, sidesPerSet: ['BILATERAL'], configurationSnapshot: null },
  ];
  await db.transaction('rw', db.sessions, db.prescriptions, db.decisionLog, db.equipmentItems, async () => {
    for (const id of bandIds) if (!(await db.equipmentItems.get(id))) throw new DomainError('UNKNOWN_EQUIPMENT', `Elastico ${id} inesistente`);
    await db.sessions.add(session);
    await db.prescriptions.bulkAdd(prescriptions);
    await db.decisionLog.add({ id: uuidv7(), ts: t, engine: 'poc', ruleVersion: 'poc-1', input: null, decision: 'SESSION_CREATED', reason: 'Seduta di prova (strumenti di verifica)' });
  });
  return session;
}

/** Aggiunge un esercizio fuori programma (origine USER_ADDED, M2). */
export async function addUserPrescription(db: FitDb, sessionId: string, exerciseVersionId: string): Promise<ExercisePrescription> {
  return db.transaction('rw', db.sessions, db.prescriptions, db.exerciseVersions, async () => {
    const s = await db.sessions.get(sessionId);
    if (!s || s.status !== 'IN_PROGRESS') throw new DomainError('SESSION_NOT_OPEN', 'La seduta non è in corso');
    const v = await db.exerciseVersions.get(exerciseVersionId);
    if (!v) throw new DomainError('UNKNOWN_VERSION', 'Versione esercizio inesistente');
    const order = (await db.prescriptions.where('sessionId').equals(sessionId).count()) + 1;
    const p: ExercisePrescription = {
      id: uuidv7(), sessionId, exerciseId: v.exerciseId, exerciseVersionId: v.id, order, origin: 'USER_ADDED',
      prescribedSets: 0, repMin: null, repMax: null, targetDurationS: null, targetRir: null,
      sidesPerSet: v.unilateral ? ['LEFT', 'RIGHT'] : ['BILATERAL'], configurationSnapshot: null, createdAt: nowIso(),
    };
    await db.prescriptions.add(p);
    await db.sessions.update(sessionId, { updatedAt: p.createdAt });
    return p;
  });
}

export interface RecordSetInput {
  id: string; // generato dalla UI prima del primo tentativo: un nuovo tentativo non crea duplicati
  sessionId: string;
  prescriptionId: string;
  setIndex: number;
  side: Side | null;
  status: 'PERFORMED' | 'INTERRUPTED';
  reps: number | null;
  durationS: number | null;
  rir: number | null;
  rpe: number | null;
  techniqueQuality: SetPerformance['techniqueQuality'];
  discomfort: boolean | null;
  confirmedImplausible?: boolean;
  /** Configurazione realmente usata in questa serie, se diversa da quella prescritta (13 §6). */
  configurationSnapshot?: ConfigurationSnapshot | null;
  /** Recupero prima di questa serie, dal timer (D101). */
  rest?: RestRecord | null;
}

export type RecordSetResult = { outcome: 'saved' | 'already_saved'; set: SetPerformance };

/**
 * Salvataggio di una serie. La promessa si risolve SOLO dopo il commit della transazione:
 * è l'unico evento che autorizza la UI a mostrare «salvato».
 */
export async function recordSet(db: FitDb, input: RecordSetInput): Promise<RecordSetResult> {
  if (input.reps !== null && (!Number.isInteger(input.reps) || input.reps < 0)) throw new DomainError('INVALID_REPS', 'Ripetizioni non valide');
  if (input.rir !== null && (input.rir < 0 || input.rir > 10)) throw new DomainError('INVALID_RIR', 'RIR fuori scala');
  if (input.rpe !== null && (input.rpe < 1 || input.rpe > 10)) throw new DomainError('INVALID_RPE', 'RPE fuori scala');
  if (input.rest && [input.rest.suggestedS, input.rest.addedS, input.rest.elapsedS, input.rest.intervalS ?? 0].some((x) => !Number.isFinite(x) || x < 0 || x > 3600 * 6)) throw new DomainError('INVALID_REST', 'Recupero non valido');
  const implausible = (input.reps ?? 0) > PLAUSIBILITY.maxReps || (input.durationS ?? 0) > PLAUSIBILITY.maxDurationS;
  if (implausible && !input.confirmedImplausible) throw new DomainError('IMPLAUSIBLE_VALUE', 'Valore insolito: confermare o correggere');

  return db.transaction('rw', db.sessions, db.prescriptions, db.sets, async () => {
    const existing = await db.sets.get(input.id);
    if (existing) return { outcome: 'already_saved' as const, set: existing };
    const session = await db.sessions.get(input.sessionId);
    if (!session || session.status !== 'IN_PROGRESS') throw new DomainError('SESSION_NOT_OPEN', 'La seduta non è in corso');
    const p = await db.prescriptions.get(input.prescriptionId);
    if (!p || p.sessionId !== input.sessionId) throw new DomainError('PRESCRIPTION_MISMATCH', 'Prescrizione non appartenente alla seduta');
    const t = nowIso();
    const set: SetPerformance = {
      id: input.id, sessionId: input.sessionId, prescriptionId: input.prescriptionId, exerciseId: p.exerciseId,
      setIndex: input.setIndex, side: input.side, status: input.status, reps: input.reps, durationS: input.durationS,
      rir: input.rir, rpe: input.rpe, techniqueQuality: input.techniqueQuality, discomfort: input.discomfort,
      configurationSnapshot: input.configurationSnapshot !== undefined ? input.configurationSnapshot : p.configurationSnapshot, plausibility: implausible ? 'CONFIRMED_BY_USER' : 'OK',
      performedAt: t, tzOffsetMin: tzOffset(),
      ...(input.rest ? { rest: input.rest } : {}),
    };
    await db.sets.add(set);
    await db.sessions.update(input.sessionId, { updatedAt: t });
    return { outcome: 'saved' as const, set };
  });
}

export async function getOpenSessions(db: FitDb): Promise<WorkoutSession[]> {
  return db.sessions.where('status').equals('IN_PROGRESS').sortBy('startedAt');
}

export interface SessionDetail { session: WorkoutSession; prescriptions: ExercisePrescription[]; sets: SetPerformance[] }

export async function getSessionDetail(db: FitDb, sessionId: string): Promise<SessionDetail | null> {
  return db.transaction('r', db.sessions, db.prescriptions, db.sets, async () => {
    const session = await db.sessions.get(sessionId);
    if (!session) return null;
    const prescriptions = await db.prescriptions.where('sessionId').equals(sessionId).sortBy('order');
    const sets = await db.sets.where('sessionId').equals(sessionId).toArray();
    sets.sort((a, b) => a.performedAt.localeCompare(b.performedAt));
    return { session, prescriptions, sets };
  });
}

/** Posizione di ripresa: prima prescrizione con serie prescritte non ancora registrate. */
export function resumePoint(d: SessionDetail): { prescriptionId: string; setIndex: number; side: Side } | null {
  for (const p of d.prescriptions) {
    for (let i = 1; i <= p.prescribedSets; i++) {
      for (const side of p.sidesPerSet) {
        const done = d.sets.some((s) => s.prescriptionId === p.id && s.setIndex === i && (s.side ?? 'BILATERAL') === side && s.status !== 'NOT_PERFORMED');
        if (!done) return { prescriptionId: p.id, setIndex: i, side };
      }
    }
  }
  return null;
}

/**
 * Chiusura della seduta. Non cancella né modifica le osservazioni: aggiunge NOT_PERFORMED per le serie
 * prescritte mancanti e determina lo stato. Regola di stato PROVISIONAL (da approvare in F1):
 * nessuna serie eseguita né interrotta → CANCELLED; tutte eseguite → COMPLETED; altrimenti PARTIALLY_COMPLETED.
 */
export async function closeSession(db: FitDb, sessionId: string, reason: CloseReason): Promise<SessionStatus> {
  return db.transaction('rw', db.sessions, db.prescriptions, db.sets, db.decisionLog, async () => {
    const session = await db.sessions.get(sessionId);
    if (!session) throw new DomainError('NOT_FOUND', 'Seduta inesistente');
    if (session.status !== 'IN_PROGRESS') return session.status;
    const prescriptions = await db.prescriptions.where('sessionId').equals(sessionId).toArray();
    const sets = await db.sets.where('sessionId').equals(sessionId).toArray();
    const t = nowIso();
    const missing: SetPerformance[] = [];
    for (const p of prescriptions) {
      for (let i = 1; i <= p.prescribedSets; i++) {
        for (const side of p.sidesPerSet) {
          const performed = sets.some((s) => s.prescriptionId === p.id && s.setIndex === i && (s.side ?? 'BILATERAL') === side && s.status === 'PERFORMED');
          const interrupted = sets.some((s) => s.prescriptionId === p.id && s.setIndex === i && (s.side ?? 'BILATERAL') === side && s.status === 'INTERRUPTED');
          if (!performed && !interrupted) missing.push({
            id: uuidv7(), sessionId, prescriptionId: p.id, exerciseId: p.exerciseId, setIndex: i,
            side: side === 'BILATERAL' ? 'BILATERAL' : side, status: 'NOT_PERFORMED', reps: null, durationS: null,
            rir: null, rpe: null, techniqueQuality: null, discomfort: null, configurationSnapshot: null,
            plausibility: 'OK', performedAt: t, tzOffsetMin: tzOffset(),
          });
        }
      }
    }
    const performedCount = sets.filter((s) => s.status === 'PERFORMED').length;
    const workedCount = performedCount + sets.filter((s) => s.status === 'INTERRUPTED').length;
    const status: SessionStatus = workedCount === 0 ? 'CANCELLED' : missing.length === 0 && !sets.some((s) => s.status === 'INTERRUPTED') ? 'COMPLETED' : 'PARTIALLY_COMPLETED';
    if (missing.length) await db.sets.bulkAdd(missing);
    await db.sessions.update(sessionId, { status, endedAt: t, updatedAt: t, closeReason: reason });
    await db.decisionLog.add({ id: uuidv7(), ts: t, engine: 'poc', ruleVersion: 'poc-close-1', input: { performedCount, missing: missing.length, reason }, decision: status, reason: 'Regola di chiusura PROVISIONAL' });
    return status;
  });
}

export async function tableCounts(db: FitDb): Promise<Record<string, number>> {
  const out: Record<string, number> = {};
  for (const t of db.tables) out[t.name] = await t.count();
  return out;
}

export { Dexie };

/**
 * Lunghezza a riposo dei tubi Odoland: 115 cm, dichiarata dall'utente il 24/11/2026 (serve alla misura facoltativa
 * della tensione, D106). Compila solo i tubi del kit ancora senza lunghezza; non sovrascrive mai un valore inserito.
 */
export async function fillDeclaredTubeLength(db: FitDb): Promise<number> {
  const key = 'fact-tube-rest-length-115';
  if (await db.meta.get(key)) return 0;
  return db.transaction('rw', db.equipmentItems, db.decisionLog, db.meta, async () => {
    const t = nowIso();
    const tubes = await db.equipmentItems.filter((i) => i.type === 'RESISTANCE_BAND' && i.brandModel === 'Odoland' && i.restLengthCm === null).toArray();
    for (const it of tubes) await db.equipmentItems.update(it.id, { restLengthCm: 115, updatedAt: t });
    if (tubes.length) await db.decisionLog.add({ id: uuidv7(), ts: t, engine: 'system', ruleVersion: 'facts-1', input: { ids: tubes.map((x) => x.id), restLengthCm: 115 }, decision: 'DECLARED_FACT_APPLIED', reason: 'Lunghezza a riposo dei tubi (115 cm) dichiarata dall\'utente' });
    await db.meta.put({ key, value: t });
    return tubes.length;
  });
}
