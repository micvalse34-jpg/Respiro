import Dexie, { type Table } from 'dexie';
import { uuidv7 } from '../domain/ids';
import type {
  BandOrdering, DecisionLogEntry, DomainTrial, ProgressionEvent, EquipmentItem, Exercise, ExercisePrescription, ExerciseVersion,
  MetaEntry, ProfileVersion, SetPerformance, WorkoutSession,
} from '../domain/types';

// Versione dello schema del database (non della app). v1–v2: Persistence POC. v3: F1. v4: vertical slice Band Row (proposte di progressione).
// v5: prove dei domini funzionali (D105, valutazione iniziale).
export const CURRENT_SCHEMA_VERSION = 5;
export const MIN_IMPORTABLE_SCHEMA_VERSION = 1;

/** Tabelle con dati utente/osservazioni: definiscono "database popolato" e il perimetro del backup. */
export const DATA_TABLES = [
  'equipmentItems', 'bandOrderings', 'profileVersions', 'exercises', 'exerciseVersions', 'sessions',
  'prescriptions', 'sets', 'progressionEvents', 'decisionLog', 'domainTrials',
] as const;
/** Tabelle dei backup di formato 3–5 (schema 4): senza le prove dei domini. */
export const DATA_TABLES_V4 = DATA_TABLES.filter((t) => t !== 'domainTrials');
export type DataTable = (typeof DATA_TABLES)[number];

export const STORES_V1 = {
  meta: 'key',
  equipmentItems: 'id',
  exercises: 'id',
  exerciseVersions: 'id, exerciseId',
  sessions: 'id, status, startedAt',
  prescriptions: 'id, sessionId, [sessionId+order]',
  sets: 'id, sessionId, prescriptionId, [prescriptionId+setIndex]',
  decisionLog: 'id, ts',
};

// v2: indice per lo storico di un esercizio (query per exerciseId + data) con backfill dei record esistenti.
export const STORES_V2 = {
  ...STORES_V1,
  sets: 'id, sessionId, prescriptionId, [prescriptionId+setIndex], [exerciseId+performedAt]',
};

// v3: attrezzatura censita (D068), ordinamenti degli elastici, versioni del profilo.
export const STORES_V3 = {
  ...STORES_V2,
  equipmentItems: 'id, type, status',
  bandOrderings: 'id, bandType, declaredAt',
  profileVersions: 'id, recordedAt',
};

// v4: proposte di progressione (D078). Solo aggiunta di una tabella.
export const STORES_V4 = {
  ...STORES_V3,
  progressionEvents: 'id, exerciseId, sessionId, createdAt, status',
};

// v5: prove dei domini funzionali (D105). Solo aggiunta di una tabella.
export const STORES_V5 = {
  ...STORES_V4,
  domainTrials: 'id, domainId, runId, performedAt',
};

/** Segnaposto creato dal POC (schema v1–v2): diventa un oggetto dismesso, eliminabile con i dati di prova. */
export const POC_PLACEHOLDER_ID = 'eq-band-01';

/** Porta un oggetto attrezzatura del POC (campo label obbligatorio, pochi attributi) alla forma v3. Usato anche dall'import di backup vecchi. */
export function upgradeEquipmentV2(old: Record<string, unknown>, now: string): EquipmentItem {
  const isPlaceholder = old.id === POC_PLACEHOLDER_ID;
  const createdAt = (old.createdAt as string) ?? now;
  return {
    id: old.id as string,
    type: old.type as EquipmentItem['type'],
    physicalLabel: null,
    description: (old.label as string | undefined)?.trim() || null,
    color: (old.color as string | null) ?? null,
    brandModel: null,
    declaredResistance: (old.declaredResistance as string | null) ?? null,
    restLengthCm: null,
    integrity: null,
    quantity: 1,
    status: isPlaceholder ? 'RETIRED' : 'ACTIVE',
    notes: isPlaceholder ? 'Segnaposto creato dal Persistence POC' : null,
    createdAt,
    updatedAt: createdAt,
    retiredAt: isPlaceholder ? now : null,
  };
}

export type Durability = 'strict' | 'relaxed' | 'default';

export class FitDb extends Dexie {
  meta!: Table<MetaEntry, string>;
  equipmentItems!: Table<EquipmentItem, string>;
  bandOrderings!: Table<BandOrdering, string>;
  profileVersions!: Table<ProfileVersion, string>;
  exercises!: Table<Exercise, string>;
  exerciseVersions!: Table<ExerciseVersion, string>;
  sessions!: Table<WorkoutSession, string>;
  prescriptions!: Table<ExercisePrescription, string>;
  sets!: Table<SetPerformance, string>;
  progressionEvents!: Table<ProgressionEvent, string>;
  decisionLog!: Table<DecisionLogEntry, string>;
  domainTrials!: Table<DomainTrial, string>;

  constructor(name = 'fitpro', durability: Durability = 'strict') {
    // 'strict': il commit si risolve solo dopo la scrittura su disco (Chrome usa 'relaxed' per default).
    super(name, durability === 'default' ? {} : { chromeTransactionDurability: durability });
    this.version(1).stores(STORES_V1);
    this.version(2).stores(STORES_V2).upgrade(async (tx) => {
      const prescriptions = await tx.table('prescriptions').toArray();
      const byId = new Map(prescriptions.map((p) => [p.id, p.exerciseId]));
      await tx.table('sets').toCollection().modify((s: Record<string, unknown>) => {
        if (s.exerciseId == null) s.exerciseId = byId.get(s.prescriptionId as string) ?? null;
      });
    });
    // v3: solo aggiunte; nessuna serie, seduta o prescrizione viene toccata (compatibile con sedute IN_PROGRESS, D064).
    this.version(3).stores(STORES_V3).upgrade(async (tx) => {
      const now = new Date().toISOString();
      const items = await tx.table('equipmentItems').toArray();
      for (const old of items) {
        if ('physicalLabel' in old) continue; // già nella forma v3
        await tx.table('equipmentItems').put(upgradeEquipmentV2(old, now));
      }
      await tx.table('decisionLog').add({
        id: uuidv7(), ts: now, engine: 'system', ruleVersion: 'schema-3', input: { equipmentItems: items.length },
        decision: 'SCHEMA_MIGRATED_TO_3', reason: 'Fase F1: archivio definitivo (attrezzatura censita, ordinamenti elastici, profilo)',
      });
    });
    this.version(4).stores(STORES_V4).upgrade(async (tx) => {
      await tx.table('decisionLog').add({
        id: uuidv7(), ts: new Date().toISOString(), engine: 'system', ruleVersion: 'schema-4', input: null,
        decision: 'SCHEMA_MIGRATED_TO_4', reason: 'Vertical slice Band Row: proposte di progressione',
      });
    });
    // v5: solo aggiunta di una tabella; compatibile con sedute IN_PROGRESS (D064).
    this.version(5).stores(STORES_V5).upgrade(async (tx) => {
      await tx.table('decisionLog').add({
        id: uuidv7(), ts: new Date().toISOString(), engine: 'system', ruleVersion: 'schema-5', input: null,
        decision: 'SCHEMA_MIGRATED_TO_5', reason: 'Profilo dei domini funzionali: prove della valutazione (D105)',
      });
    });
  }
}

/** Database con la sola definizione v1: usato dai test di migrazione e dall'autotest su dispositivo. */
export class FitDbV1 extends Dexie {
  constructor(name: string) {
    super(name);
    this.version(1).stores(STORES_V1);
  }
}

/** Database fermo allo schema v2 (versione installata durante il POC): test e autotest della migrazione v2→v3. */
export class FitDbV2 extends Dexie {
  constructor(name: string) {
    super(name);
    this.version(1).stores(STORES_V1);
    this.version(2).stores(STORES_V2);
  }
}

/** Database fermo allo schema v3 (versione 0.2.0 installata in F1): test della migrazione v3→v4. */
export class FitDbV3 extends Dexie {
  constructor(name: string) {
    super(name);
    this.version(1).stores(STORES_V1);
    this.version(2).stores(STORES_V2);
    this.version(3).stores(STORES_V3);
  }
}
