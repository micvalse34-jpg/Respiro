// Vertical slice Band Row: seduta libera con un esercizio, valutazione a fine seduta, proposta da accettare o rifiutare.
import { compare, exposureConfig, sameBands } from '../domain/comparability';
import { nowIso, tzOffset, uuidv7 } from '../domain/ids';
import { evaluate, propose, PROGRESSION_RULE_VERSION, repeatedDiscomfort, type Exposure, type ProgressionContext } from '../domain/progression';
import type { ConfigurationSnapshot, ProgressionEvent, RejectionReason, WorkoutSession } from '../domain/types';
import { currentOrderings, listEquipment, orderingIsCurrent } from './equipmentRepo';
import { DomainError } from './errors';
import { BAND_ROW_DEFAULTS, BAND_ROW_ID, checkSetup, SAFETY_CHECK_DAYS, safetyCheckRequired, snapshotOf, startFreeSession } from './freeSessionRepo';
import type { FitDb } from './schema';

// Funzioni comuni spostate in freeSessionRepo (seduta libera con tutta la libreria, D098): riesportate per compatibilità.
export { BAND_ROW_DEFAULTS, BAND_ROW_ID, SAFETY_CHECK_DAYS, safetyCheckRequired, snapshotOf };

const checkConfig = (db: FitDb, cfg: ConfigurationSnapshot) => checkSetup(db, { setup: 'TUBE_DOOR' }, cfg);

/** Seduta libera con il solo Band Row (vertical slice). Stesse regole e stessa prescrizione di default della 0.3. */
export async function startBandRowSession(db: FitDb, cfg: ConfigurationSnapshot, safetyConfirmed = false): Promise<WorkoutSession> {
  return startFreeSession(db, { exerciseId: BAND_ROW_ID, config: cfg }, safetyConfirmed);
}

/** Esposizioni chiuse al Band Row, dalla più recente; opzionalmente fino a una certa seduta inclusa. */
export async function bandRowExposures(db: FitDb, upToSessionId?: string): Promise<Exposure[]> {
  const pres = (await db.prescriptions.filter((p) => p.exerciseId === BAND_ROW_ID).toArray());
  const sessions = new Map((await db.sessions.bulkGet(pres.map((p) => p.sessionId))).filter(Boolean).map((s) => [s!.id, s!]));
  let limit: string | null = null;
  if (upToSessionId) limit = sessions.get(upToSessionId)?.endedAt ?? null;
  const out: Exposure[] = [];
  for (const p of pres) {
    const s = sessions.get(p.sessionId);
    if (!s || s.sessionType !== 'FREE' || s.status === 'IN_PROGRESS' || s.status === 'CANCELLED' || !s.endedAt) continue;
    if (limit && s.endedAt > limit) continue;
    const sets = (await db.sets.where('prescriptionId').equals(p.id).toArray()).sort((a, b) => a.setIndex - b.setIndex || a.performedAt.localeCompare(b.performedAt));
    const worked = sets.filter((x) => x.status !== 'NOT_PERFORMED');
    out.push({
      sessionId: s.id, endedAt: s.endedAt, config: exposureConfig(worked.map((x) => x.configurationSnapshot)),
      prescribedSets: p.prescribedSets, repMax: p.repMax ?? BAND_ROW_DEFAULTS.repMax, targetRir: p.targetRir ?? BAND_ROW_DEFAULTS.targetRir,
      sets: sets.map((x) => ({ status: x.status, reps: x.reps, rir: x.rir, techniqueQuality: x.techniqueQuality, discomfort: x.discomfort })),
    });
  }
  return out.sort((a, b) => b.endedAt.localeCompare(a.endedAt));
}

/** Sedute che contano per la progressione: solo quelle libere (le sedute di prova sono escluse). */
async function freeSessionIds(db: FitDb): Promise<Set<string>> {
  return new Set((await db.sessions.filter((s) => s.sessionType === 'FREE').primaryKeys()) as string[]);
}

export async function bandLabel(db: FitDb): Promise<(id: string) => string> {
  const items = new Map((await db.equipmentItems.toArray()).map((i) => [i.id, i]));
  return (id) => { const i = items.get(id); return i ? [i.physicalLabel ?? 'elastico', i.color].filter(Boolean).join(' ') : 'elastico non più presente'; };
}

async function context(db: FitDb, exposures: Exposure[]): Promise<ProgressionContext> {
  const tubes = (await listEquipment(db)).filter((i) => i.type === 'RESISTANCE_BAND');
  const o = (await currentOrderings(db)).RESISTANCE_BAND;
  const usable = new Set(tubes.filter((t) => t.integrity !== 'DAMAGED').map((t) => t.id));
  const orderedTubes = orderingIsCurrent(o, tubes) ? o!.orderedIds.filter((id) => usable.has(id)).map((id) => ({ id, label: id })) : null;
  const free = await freeSessionIds(db);
  const rejections = (await db.progressionEvents.where('status').equals('REJECTED').toArray())
    .filter((e) => e.exerciseId === BAND_ROW_ID && e.rejectionReason && free.has(e.sessionId))
    .map((e) => ({ kind: e.kind, fromConfig: e.fromConfig, proposedConfig: e.proposedConfig, reason: e.rejectionReason! }));
  const oldestFirst = [...exposures].reverse();
  return {
    exposures, orderedTubes, rejections, labelOf: await bandLabel(db),
    startDistanceCm: (cfg) => oldestFirst.find((e) => e.config && sameBands(e.config, cfg) && e.config.anchor === cfg.anchor)?.config!.distanceCm ?? null,
  };
}

export interface EvaluationResult { event: ProgressionEvent | null; repeatedDiscomfort: boolean }

/** Valutazione a fine seduta. Idempotente: una seconda chiamata restituisce l'evento già registrato. */
export async function evaluateBandRowSession(db: FitDb, sessionId: string): Promise<EvaluationResult> {
  const exposures = await bandRowExposures(db, sessionId);
  const existing = (await db.progressionEvents.where('sessionId').equals(sessionId).sortBy('createdAt'));
  if (existing.length) return { event: existing[existing.length - 1]!, repeatedDiscomfort: repeatedDiscomfort(exposures) };
  if (!exposures.length || exposures[0]!.sessionId !== sessionId) return { event: null, repeatedDiscomfort: false };
  const ctx = await context(db, exposures);
  const ev = evaluate(ctx);
  if (!ev) return { event: null, repeatedDiscomfort: false };
  const event = await saveEvent(db, sessionId, exposures[0]!.config, ev, null);
  return { event, repeatedDiscomfort: repeatedDiscomfort(exposures) };
}

async function saveEvent(db: FitDb, sessionId: string, from: ConfigurationSnapshot | null, ev: ReturnType<typeof propose>, previousEventId: string | null): Promise<ProgressionEvent> {
  const proposal = ev.kind === 'INCREASE_DISTANCE' || ev.kind === 'NEXT_BAND' || ev.kind === 'ADD_BAND';
  const t = nowIso();
  const event: ProgressionEvent = {
    id: uuidv7(), exerciseId: BAND_ROW_ID, sessionId, previousEventId, ruleVersion: PROGRESSION_RULE_VERSION, kind: ev.kind,
    status: proposal ? 'PROPOSED' : 'INFO', fromConfig: from, proposedConfig: ev.proposedConfig, reason: ev.reason, evidence: ev.evidence,
    createdAt: t, tzOffsetMin: tzOffset(), decidedAt: null, rejectionReason: null,
  };
  await db.transaction('rw', db.progressionEvents, db.decisionLog, async () => {
    await db.progressionEvents.add(event);
    await db.decisionLog.add({ id: uuidv7(), ts: t, engine: 'progression', ruleVersion: PROGRESSION_RULE_VERSION, input: ev.evidence, decision: ev.kind, reason: ev.reason });
  });
  return event;
}

/**
 * Decisione dell'utente su una proposta. Il rifiuto per «spazio» o «salto troppo grande» genera subito
 * la proposta alternativa successiva (D081); gli altri rifiuti chiudono la valutazione.
 */
export async function decideProposal(db: FitDb, eventId: string, accept: boolean, reason: RejectionReason | null = null): Promise<ProgressionEvent | null> {
  const t = nowIso();
  const ev = await db.transaction('rw', db.progressionEvents, db.decisionLog, async () => {
    const e = await db.progressionEvents.get(eventId);
    if (!e) throw new DomainError('NOT_FOUND', 'Proposta inesistente');
    if (e.status !== 'PROPOSED') throw new DomainError('ALREADY_DECIDED', 'Proposta già decisa');
    if (!accept && !reason) throw new DomainError('REASON_REQUIRED', 'Indica il motivo del rifiuto');
    const updated: ProgressionEvent = { ...e, status: accept ? 'ACCEPTED' : 'REJECTED', decidedAt: t, rejectionReason: accept ? null : reason };
    await db.progressionEvents.put(updated);
    await db.decisionLog.add({ id: uuidv7(), ts: t, engine: 'user', ruleVersion: PROGRESSION_RULE_VERSION, input: { eventId, reason }, decision: accept ? 'PROPOSAL_ACCEPTED' : 'PROPOSAL_REJECTED', reason: e.reason });
    return updated;
  });
  if (accept || !(reason === 'NO_SPACE' || reason === 'JUMP_TOO_BIG') || !ev.fromConfig) return null;
  const ctx = await context(db, await bandRowExposures(db, ev.sessionId));
  return saveEvent(db, ev.sessionId, ev.fromConfig, propose(ctx, ev.fromConfig, { ...(ev.evidence as object), afterRejectionOf: ev.id }), ev.id);
}

/** Proposta ancora in attesa di decisione (al massimo una: l'ultima). */
export async function pendingProposal(db: FitDb): Promise<ProgressionEvent | null> {
  const free = await freeSessionIds(db);
  const list = (await db.progressionEvents.where('status').equals('PROPOSED').sortBy('createdAt')).filter((e) => free.has(e.sessionId));
  return list[list.length - 1] ?? null;
}

/** Configurazione da proporre all'avvio: proposta accettata più recente, altrimenti ultima usata, altrimenti default. */
export async function setupDefaults(db: FitDb): Promise<{ config: ConfigurationSnapshot; source: 'ACCEPTED_PROPOSAL' | 'LAST_SESSION' | 'DEFAULT' }> {
  const exposures = await bandRowExposures(db);
  const last = exposures.find((e) => e.config)?.config ?? null;
  const lastAt = exposures[0]?.endedAt ?? '';
  const free = await freeSessionIds(db);
  const accepted = (await db.progressionEvents.where('status').equals('ACCEPTED').sortBy('decidedAt')).filter((e) => e.exerciseId === BAND_ROW_ID && free.has(e.sessionId)).pop();
  const valid = async (c: ConfigurationSnapshot) => { try { await checkConfig(db, c); return true; } catch { return false; } };
  if (accepted?.proposedConfig && (accepted.decidedAt ?? '') >= lastAt && await valid(accepted.proposedConfig)) return { config: accepted.proposedConfig, source: 'ACCEPTED_PROPOSAL' };
  if (last && await valid(last)) return { config: last, source: 'LAST_SESSION' };
  const tubes = (await listEquipment(db)).filter((i) => i.type === 'RESISTANCE_BAND' && i.integrity !== 'DAMAGED');
  const o = (await currentOrderings(db)).RESISTANCE_BAND;
  const softest = orderingIsCurrent(o, tubes) ? o!.orderedIds.find((id) => tubes.some((t) => t.id === id)) : tubes[0]?.id;
  return { config: snapshotOf(softest ? [softest] : [], 'DOOR_MID', null), source: 'DEFAULT' };
}

export { compare };
