import type { ExercisePrescription, SetPerformance, WorkoutSession } from '../domain/types';
import { uuidv7 } from '../domain/ids';
import { FitDb } from './schema';
import { SEED, seedKnowledge } from './repository';

/** Storico sintetico: ~2,5 sedute/settimana, 3 prescrizioni, ~10 serie a seduta. Solo per prove di prestazione. */
export async function generateHistory(db: FitDb, years: number, sessionsPerWeek = 2.5): Promise<{ sessions: number; sets: number }> {
  await seedKnowledge(db);
  const total = Math.round(years * 52 * sessionsPerWeek);
  const start = Date.now() - years * 365 * 86_400_000;
  const step = (years * 365 * 86_400_000) / total;
  const ex = [SEED.bandRow, SEED.splitSquat, SEED.plank];
  let setCount = 0;
  const BATCH = 100;
  for (let b = 0; b < total; b += BATCH) {
    const sessions: WorkoutSession[] = []; const pres: ExercisePrescription[] = []; const sets: SetPerformance[] = [];
    for (let i = b; i < Math.min(total, b + BATCH); i++) {
      const t0 = start + i * step;
      const iso = new Date(t0).toISOString();
      const sid = uuidv7(t0);
      sessions.push({ id: sid, sessionType: (['A', 'B', 'C'] as const)[i % 3]!, status: 'COMPLETED', startedAt: iso, tzOffsetMin: -60, endedAt: new Date(t0 + 45 * 60_000).toISOString(), updatedAt: iso, closeReason: 'FINISHED_BY_USER' });
      ex.forEach((e, k) => {
        const pid = uuidv7(t0);
        const uni = e === SEED.splitSquat; const dur = e === SEED.plank;
        pres.push({ id: pid, sessionId: sid, exerciseId: e.exerciseId, exerciseVersionId: e.versionId, order: k + 1, origin: 'ENGINE', prescribedSets: 3, repMin: dur ? null : 8, repMax: dur ? null : 15, targetDurationS: dur ? 30 : null, targetRir: dur ? null : 2, sidesPerSet: uni ? ['LEFT', 'RIGHT'] : ['BILATERAL'], configurationSnapshot: null, createdAt: iso });
        for (let s = 1; s <= 3; s++) for (const side of uni ? (['LEFT', 'RIGHT'] as const) : (['BILATERAL'] as const)) {
          sets.push({ id: uuidv7(t0 + s * 60_000), sessionId: sid, prescriptionId: pid, exerciseId: e.exerciseId, setIndex: s, side, status: 'PERFORMED', reps: dur ? null : 8 + ((i + s) % 8), durationS: dur ? 30 : null, rir: dur ? null : 2, rpe: null, techniqueQuality: 'GOOD', discomfort: false, configurationSnapshot: null, plausibility: 'OK', performedAt: new Date(t0 + s * 60_000).toISOString(), tzOffsetMin: -60 });
        }
      });
    }
    await db.transaction('rw', db.sessions, db.prescriptions, db.sets, async () => {
      await db.sessions.bulkAdd(sessions); await db.prescriptions.bulkAdd(pres); await db.sets.bulkAdd(sets);
    });
    setCount += sets.length;
  }
  return { sessions: total, sets: setCount };
}

export async function exerciseHistory(db: FitDb, exerciseId: string, limit = 200): Promise<SetPerformance[]> {
  return db.sets.where('[exerciseId+performedAt]').between([exerciseId, ''], [exerciseId, '\uffff']).reverse().limit(limit).toArray();
}

export function percentile(values: number[], p: number): number {
  if (!values.length) return NaN;
  const s = [...values].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.ceil((p / 100) * s.length) - 1)]!;
}
