// Calibrazione della prima seduta con un esercizio con elastico (D102): dopo ogni serie l'app suggerisce come
// regolare la difficoltà per la serie successiva. Per la porta prima la distanza, poi l'elastico (preferenza dell'utente, D081).
import type { ExerciseMeta } from './library';

export type CalibrationDirection = 'HARDER' | 'EASIER' | 'KEEP';
export interface CalibrationHint { direction: CalibrationDirection; text: string }

export function calibrationHint(
  m: Pick<ExerciseMeta, 'setup' | 'measure' | 'effort'>,
  target: { repMin: number | null; repMax: number | null },
  set: { reps: number | null; rir: number | null; status: 'PERFORMED' | 'INTERRUPTED' | 'NOT_PERFORMED'; discomfort: boolean | null },
): CalibrationHint | null {
  if (m.setup === 'NONE' || m.measure !== 'REPS' || set.status !== 'PERFORMED' || set.discomfort || set.reps === null) return null;
  const tooEasy = (target.repMax !== null && set.reps > target.repMax) || (m.effort === 'RIR' && set.rir !== null && set.rir >= 5);
  const tooHard = (target.repMin !== null && set.reps < target.repMin) || (m.effort === 'RIR' && set.rir === 0);
  if (tooEasy && !tooHard) {
    return { direction: 'HARDER', text: m.setup === 'TUBE_DOOR' ? 'Troppo facile: per la prossima serie allontanati di 10–20 cm dalla porta (tocca «Cambia»).' : 'Troppo facile: per la prossima serie prova un elastico più duro (tocca «Cambia»).' };
  }
  if (tooHard && !tooEasy) {
    return { direction: 'EASIER', text: m.setup === 'TUBE_DOOR' ? 'Troppo dura: per la prossima serie avvicinati di 10–20 cm alla porta (tocca «Cambia»).' : 'Troppo dura: per la prossima serie prova un elastico più morbido (tocca «Cambia»).' };
  }
  return { direction: 'KEEP', text: m.setup === 'TUBE_DOOR' ? 'Distanza giusta: tienila.' : 'Elastico giusto: tienilo.' };
}
