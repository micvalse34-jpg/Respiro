// Classi di comparabilità tra due esposizioni (D079). Regola per esercizi con elastico e ancoraggio alla porta.
import type { Comparability, ConfigurationSnapshot } from './types';

export const DISTANCE_TOLERANCE_CM = 10; // PROVISIONAL

/** Configurazione completa per il confronto: elastici, ancoraggio e distanza tutti presenti. */
export const isComplete = (c: ConfigurationSnapshot | null): c is ConfigurationSnapshot =>
  !!c && c.bandIds.length > 0 && c.anchor !== null && c.distanceCm !== null;

export const sameBands = (a: ConfigurationSnapshot, b: ConfigurationSnapshot): boolean =>
  a.bandIds.length === b.bandIds.length && [...a.bandIds].sort().join('|') === [...b.bandIds].sort().join('|');

/**
 * A: stessi elastici, stesso ancoraggio, distanza entro ±10 cm.
 * B: stessi elastici, ancoraggio o distanza diversi.
 * C: elastici diversi.
 * D: configurazione incompleta in almeno una delle due.
 */
export function compare(a: ConfigurationSnapshot | null, b: ConfigurationSnapshot | null): Comparability {
  if (!isComplete(a) || !isComplete(b)) return 'D';
  if (!sameBands(a, b)) return 'C';
  if (a.anchor === b.anchor && Math.abs(a.distanceCm! - b.distanceCm!) <= DISTANCE_TOLERANCE_CM) return 'A';
  return 'B';
}

/** Configurazione unica di un'esposizione: se le serie eseguite hanno configurazioni diverse, nessuna (→ classe D). */
export function exposureConfig(snapshots: (ConfigurationSnapshot | null)[]): ConfigurationSnapshot | null {
  if (!snapshots.length) return null;
  const first = snapshots[0]!;
  return snapshots.every((s) => s && first && compare(s, first) === 'A' && s.distanceCm === first.distanceCm) ? first : null;
}

export const ANCHOR_NAMES: Record<string, string> = { DOOR_LOW: 'porta, in basso', DOOR_MID: 'porta, a metà', DOOR_HIGH: 'porta, in alto' };
