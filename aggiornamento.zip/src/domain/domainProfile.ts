// Profilo dei domini e regola di decisione (D105). Funzioni pure: ricevono le prove e restituiscono livelli,
// classi, rapporti, priorità e motivazioni. Nessun dato viene scritto: il profilo è sempre ricalcolabile.
import { DOMAINS, LADDERS, LEVEL_DOMAINS, ladder, type DomainId, type Ladder, type LadderStep, type MobilityClass } from './domains';
import type { DomainTrial, Side } from './types';

export const P = {
  windowDays: 42,          // finestra di fiducia
  declineGapDays: 7,       // due mancati a distanza di almeno 7 giorni per scendere
  maxPriorities: 3,
  asymConfirm: 0.10, asymStrong: 0.15,
  ratioH: { low: 0.9, high: 1.6 },
} as const;

const DAY = 86_400_000;
const dayOf = (iso: string) => iso.slice(0, 10);

/** Criterio comune per superare un gradino (D105 §I livelli). RIR mancante non è 0: non blocca, ma non conferma. */
export function passesStep(step: LadderStep, l: Pick<Ladder, 'useRir'>, r: { reps: number | null; seconds: number | null; rir: number | null; technique: DomainTrial['technique']; discomfort: boolean }): boolean {
  if (r.discomfort || r.technique === 'POOR' || r.technique === null) return false;
  if (step.reps !== undefined && (r.reps ?? 0) < step.reps) return false;
  if (step.seconds !== undefined && (r.seconds ?? 0) < step.seconds) return false;
  if (l.useRir && r.rir === 0) return false;
  return true;
}

export type Confidence = 'HIGH' | 'MEDIUM' | 'LOW';
export const CONFIDENCE_NAMES: Record<Confidence, string> = { HIGH: 'alta', MEDIUM: 'media', LOW: 'bassa' };
const minConf = (a: Confidence, b: Confidence): Confidence => (a === 'LOW' || b === 'LOW' ? 'LOW' : a === 'MEDIUM' || b === 'MEDIUM' ? 'MEDIUM' : 'HIGH');

/** estimated: nessun gradino superato, solo un limite superiore (es. livello 2 mancato → «al massimo 1»): fiducia bassa. */
export interface SideLevel { level: number | null; confidence: Confidence; estimated?: boolean }

/** Livello di una scala per un lato: il gradino più alto superato, con le regole di fiducia e di discesa. */
export function ladderLevel(trials: DomainTrial[], now: number): SideLevel {
  if (!trials.length) return { level: null, confidence: 'LOW' };
  const recent = trials.filter((t) => now - Date.parse(t.performedAt) <= P.windowDays * DAY);
  const pool = recent.length ? recent : trials;
  const passed = pool.filter((t) => t.passed && t.level !== null);
  if (!passed.length) {
    const minFailed = Math.min(...pool.filter((t) => t.level !== null).map((t) => t.level!));
    return { level: Math.max(0, minFailed - 1), confidence: 'LOW', estimated: true };
  }
  let level = Math.max(...passed.map((t) => t.level!));
  if (level > 0) {
    // Discesa solo con prove ripetute: dopo l'ultimo superamento, 2 giorni di mancato superamento a ≥7 giorni di distanza.
    const lastPass = Math.max(...passed.filter((t) => t.level! >= level).map((t) => Date.parse(t.performedAt)));
    const failDays = [...new Set(pool.filter((t) => t.level === level && t.passed === false && Date.parse(t.performedAt) > lastPass).map((t) => Date.parse(dayOf(t.performedAt))))].sort();
    if (failDays.length >= 2 && failDays[failDays.length - 1]! - failDays[0]! >= P.declineGapDays * DAY) level -= 1;
  }
  if (!recent.length) return { level, confidence: 'LOW' };
  const confirmDays = new Set(recent.filter((t) => (t.passed && t.level! >= level) || (t.passed === false && t.level === level + 1)).map((t) => dayOf(t.performedAt)));
  return { level, confidence: confirmDays.size >= 2 ? 'HIGH' : 'MEDIUM' };
}

export interface SideClass { cls: MobilityClass | null; confidence: Confidence; value: number | null }

export function thresholdClass(trials: DomainTrial[], now: number): SideClass {
  const sorted = [...trials].sort((a, b) => b.performedAt.localeCompare(a.performedAt));
  const last = sorted[0];
  if (!last || !last.mobilityClass) return { cls: null, confidence: 'LOW', value: null };
  const recent = sorted.filter((t) => now - Date.parse(t.performedAt) <= P.windowDays * DAY);
  if (!recent.length) return { cls: last.mobilityClass, confidence: 'LOW', value: last.valueCm ?? last.seconds };
  const sameDays = new Set(recent.filter((t) => t.mobilityClass === last.mobilityClass).map((t) => dayOf(t.performedAt)));
  return { cls: last.mobilityClass, confidence: sameDays.size >= 2 ? 'HIGH' : 'MEDIUM', value: last.valueCm ?? last.seconds };
}

export type DomainState = 'PRIORITY' | 'POSSIBLE' | 'NORMAL' | 'AHEAD' | 'UNKNOWN';
export const STATE_NAMES: Record<DomainState, string> = { PRIORITY: 'In priorità', POSSIBLE: 'Possibile ritardo', NORMAL: 'Normale', AHEAD: 'Avanti', UNKNOWN: 'Da valutare' };

export interface DomainProfile {
  id: DomainId; name: string;
  level: number | null;                       // domini a scala
  cls: MobilityClass | null;                  // domini a soglia
  sides: Partial<Record<Side, { level?: number | null; cls?: MobilityClass | null; value?: number | null }>>;
  confidence: Confidence;
  asymmetry: { pct: number | null; weakSide: Side | null; classDiffers: boolean } | null;
  score: number; state: DomainState; reasons: string[];
  /** Un criterio si applicherebbe ma manca la conferma di una seconda prova. */
  pending?: boolean;
  /** Livello solo stimato (nessun gradino superato): da completare con il gradino più basso. */
  estimated?: boolean;
}

export interface Ratio { id: string; name: string; value: number | null; text: string; outOfBand: boolean; lagging: DomainId | null }

export interface Profile { domains: DomainProfile[]; median: number | null; ratios: Ratio[]; priorities: DomainId[]; ruleNote: string }

const SIDES: Side[] = ['LEFT', 'RIGHT'];
const SIDE_IT: Record<Side, string> = { LEFT: 'sinistra', RIGHT: 'destra', BILATERAL: '' };

/** Asimmetria dall'ultima giornata in cui entrambi i lati hanno provato lo stesso gradino (ripetizioni o secondi). */
function asymmetryOf(trials: DomainTrial[]): { pct: number; weakSide: Side } | null {
  const byKey = new Map<string, DomainTrial[]>();
  for (const t of trials) if (t.side === 'LEFT' || t.side === 'RIGHT') { const k = `${dayOf(t.performedAt)}|${t.ladderId}|${t.level}`; byKey.set(k, [...(byKey.get(k) ?? []), t]); }
  const keys = [...byKey.keys()].sort().reverse();
  for (const k of keys) {
    const g = byKey.get(k)!;
    const l = g.find((t) => t.side === 'LEFT'); const r = g.find((t) => t.side === 'RIGHT');
    if (!l || !r) continue;
    const lv = l.reps ?? l.seconds ?? l.valueCm; const rv = r.reps ?? r.seconds ?? r.valueCm;
    if (lv == null || rv == null || Math.max(lv, rv) === 0) continue;
    return { pct: Math.abs(lv - rv) / Math.max(lv, rv), weakSide: lv < rv ? 'LEFT' : 'RIGHT' };
  }
  return null;
}

export function computeProfile(trials: DomainTrial[], now = Date.now()): Profile {
  const domains: DomainProfile[] = DOMAINS.map((d) => {
    const dt = trials.filter((t) => t.domainId === d.id && t.kind !== 'RATIO_H');
    const base: DomainProfile = { id: d.id, name: d.name, level: null, cls: null, sides: {}, confidence: 'LOW', asymmetry: null, score: 0, state: 'UNKNOWN', reasons: [] };
    if (d.kind === 'LADDER') {
      const ladders = LADDERS.filter((l) => l.domain === d.id);
      const sides: Side[] = d.perSide ? SIDES : ['BILATERAL'];
      let level: number | null = null; let conf: Confidence = 'HIGH'; let any = false;
      for (const s of sides) {
        let sideLevel: number | null = null; let sideConf: Confidence = 'HIGH';
        for (const l of ladders) {
          const r = ladderLevel(dt.filter((t) => t.ladderId === l.id && (t.side ?? 'BILATERAL') === s), now);
          if (r.level === null) { sideLevel = null; sideConf = 'LOW'; break; } // una parte non provata: lato non valutato
          sideLevel = sideLevel === null ? r.level : Math.min(sideLevel, r.level); sideConf = minConf(sideConf, r.confidence);
          if (r.estimated) base.estimated = true;
        }
        base.sides[s] = { level: sideLevel };
        if (sideLevel === null) { level = null; conf = 'LOW'; any = false; break; }
        any = true; level = level === null ? sideLevel : Math.min(level, sideLevel); conf = minConf(conf, sideConf);
      }
      base.level = any ? level : null; base.confidence = any ? conf : 'LOW';
      if (d.perSide) {
        const a = asymmetryOf(dt);
        const ll = base.sides.LEFT?.level; const rl = base.sides.RIGHT?.level;
        const levelDiff = ll != null && rl != null && ll !== rl;
        base.asymmetry = a || levelDiff ? { pct: a?.pct ?? null, weakSide: levelDiff ? (ll! < rl! ? 'LEFT' : 'RIGHT') : a!.weakSide, classDiffers: levelDiff } : null;
      }
    } else if (d.kind === 'THRESHOLD') {
      const sides: Side[] = d.perSide ? SIDES : ['BILATERAL'];
      const order: MobilityClass[] = ['CARENTE', 'LIMITATA', 'ADEGUATA'];
      let worst: MobilityClass | null = null; let conf: Confidence = 'HIGH'; let complete = true;
      for (const s of sides) {
        const r = thresholdClass(dt.filter((t) => (t.side ?? 'BILATERAL') === s), now);
        base.sides[s] = { cls: r.cls, value: r.value };
        if (!r.cls) { complete = false; continue; }
        worst = worst === null || order.indexOf(r.cls) < order.indexOf(worst) ? r.cls : worst;
        conf = minConf(conf, r.confidence);
      }
      base.cls = complete ? worst : null; base.confidence = complete ? conf : 'LOW';
      if (d.perSide && complete) {
        const lc = base.sides.LEFT!.cls!; const rc = base.sides.RIGHT!.cls!;
        const a = asymmetryOf(dt);
        if (lc !== rc || (a && a.pct > P.asymConfirm)) base.asymmetry = { pct: a?.pct ?? null, weakSide: lc !== rc ? (order.indexOf(lc) < order.indexOf(rc) ? 'LEFT' : 'RIGHT') : a!.weakSide, classDiffers: lc !== rc };
      }
    }
    return base;
  });
  const byId = new Map(domains.map((x) => [x.id, x]));

  // Riferimento: mediana dei livelli di forza e core con fiducia almeno media.
  const lv = LEVEL_DOMAINS.map((id) => byId.get(id)!).filter((x) => x.level !== null && x.confidence !== 'LOW').map((x) => x.level!).sort((a, b) => a - b);
  const median = lv.length ? (lv.length % 2 ? lv[(lv.length - 1) / 2]! : (lv[lv.length / 2 - 1]! + lv[lv.length / 2]!) / 2) : null;

  // Rapporti.
  const ratios: Ratio[] = [];
  const h = [...trials].filter((t) => t.kind === 'RATIO_H' && t.reps != null && t.pressReps).sort((a, b) => b.performedAt.localeCompare(a.performedAt))[0];
  if (h) {
    const v = h.reps! / h.pressReps!;
    const lag: DomainId | null = v < P.ratioH.low ? 'T-OR' : v > P.ratioH.high ? 'P-OR' : null;
    ratios.push({ id: 'H', name: 'Tirata / spinta orizzontale', value: Math.round(v * 100) / 100, text: `${h.reps} ripetizioni di rematore contro ${h.pressReps} di spinta al petto, stesso elastico e stessa distanza`, outOfBand: lag !== null, lagging: lag });
  } else ratios.push({ id: 'H', name: 'Tirata / spinta orizzontale', value: null, text: 'Da misurare', outOfBand: false, lagging: null });
  const diff = (id: string, name: string, a: DomainId, b: DomainId, min: number, lagIfLow: DomainId) => {
    const A = byId.get(a)!; const B = byId.get(b)!;
    if (A.level === null || B.level === null) { ratios.push({ id, name, value: null, text: 'Da misurare', outOfBand: false, lagging: null }); return; }
    const v = A.level - B.level;
    ratios.push({ id, name, value: v, text: `Livello ${A.level} contro ${B.level}`, outOfBand: v < min, lagging: v < min ? lagIfLow : null });
  };
  diff('V', 'Tirata / spinta verticale', 'T-VE', 'P-VE', 0 - 0.5, 'T-VE');           // fuori fascia da −1
  diff('PA', 'Catena posteriore / anteriore delle gambe', 'G-ANC', 'G-GIN', -0.5, 'G-ANC');
  diff('SE', 'Estensori / anti-estensione del core', 'C-SCH', 'C-EST', -1.5, 'C-SCH');  // fuori fascia da −2
  {
    const abd = ladder('G-LAT-ABD'); const add = ladder('G-LAT-ADD');
    const lvOf = (l: Ladder) => Math.min(...SIDES.map((s) => ladderLevel(trials.filter((t) => t.ladderId === l.id && t.side === s), now).level ?? Infinity));
    const a = lvOf(abd); const b = lvOf(add);
    if (Number.isFinite(a) && Number.isFinite(b)) ratios.push({ id: 'AA', name: 'Abduttori / adduttori', value: a - b, text: `Livello ${a} contro ${b}`, outOfBand: Math.abs(a - b) >= 2, lagging: Math.abs(a - b) >= 2 ? 'G-LAT' : null });
    else ratios.push({ id: 'AA', name: 'Abduttori / adduttori', value: null, text: 'Da misurare', outOfBand: false, lagging: null });
  }

  // Punteggi e motivazioni.
  for (const x of domains) {
    if (x.level !== null && median !== null && x.confidence !== 'LOW' && x.level <= median - 1) {
      x.score += Math.floor(median - x.level); x.reasons.push(`Livello ${x.level} contro mediana ${median}`);
    }
    if (x.estimated) { x.pending = true; x.reasons.push(`Stima: nessun gradino superato, al massimo livello ${x.level}. Completa la scala dal gradino più basso`); }
    if (x.cls === 'CARENTE') { x.score += 2; x.reasons.push('Mobilità o equilibrio carente'); }
    else if (x.cls === 'LIMITATA' && x.confidence === 'HIGH') { x.score += 1; x.reasons.push('Limitata, confermata da due prove'); }
    else if (x.cls === 'LIMITATA') { x.pending = true; x.reasons.push('Limitata'); }
    if (x.asymmetry) {
      const pct = x.asymmetry.pct !== null ? Math.round(x.asymmetry.pct * 100) : null;
      const strong = x.asymmetry.classDiffers || (pct !== null && x.asymmetry.pct! > P.asymStrong);
      const weak = SIDE_IT[x.asymmetry.weakSide!];
      if (strong && x.confidence === 'HIGH') { x.score += 1; x.reasons.push(`Lato ${weak} più debole${pct !== null ? ` del ${pct}%` : ''}`); }
      else if (strong || (pct !== null && x.asymmetry.pct! > P.asymConfirm)) { x.pending = true; x.reasons.push(`Lato ${weak} più debole${pct !== null ? ` del ${pct}%` : ''}: da confermare`); }
    }
  }
  for (const r of ratios) if (r.lagging) { const x = byId.get(r.lagging)!; x.score += 1; x.reasons.push(`${r.name}: ${r.text.toLowerCase()}, fuori fascia`); }

  // Stati: massimo 3 priorità tra i domini con fiducia alta; con fiducia media «possibile ritardo» (+1 serie).
  const ranked = domains.filter((x) => x.score > 0 && x.confidence === 'HIGH').sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
  const priorities = ranked.slice(0, P.maxPriorities).map((x) => x.id);
  for (const x of domains) {
    const known = x.level !== null || x.cls !== null;
    if (!known) x.state = 'UNKNOWN';
    else if (priorities.includes(x.id)) x.state = 'PRIORITY';
    else if (x.score > 0 || x.pending) x.state = x.confidence === 'HIGH' && !x.pending ? 'NORMAL' : 'POSSIBLE';
    else if (x.level !== null && median !== null && x.confidence === 'HIGH' && x.level >= median + 1) { x.state = 'AHEAD'; x.reasons.push(`Livello ${x.level} sopra la mediana ${median}: mantenimento`); }
    else x.state = 'NORMAL';
    if ((x.score > 0 || x.pending) && x.confidence !== 'HIGH' && known) x.reasons.push('Serve una seconda prova per confermare');
  }
  return { domains, median, ratios, priorities, ruleNote: 'Regola domains-1 (D105), valori PROVISIONAL' };
}
