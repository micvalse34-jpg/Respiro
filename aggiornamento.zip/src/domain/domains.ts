// Modello dei domini funzionali (D105, documento «Modello dei domini funzionali e scale di difficoltà»).
// Solo definizioni: nessuna dipendenza da React o dal database. Tutti i numeri sono PROVISIONAL.
export const DOMAIN_RULE_VERSION = 'domains-1';

export type DomainId =
  | 'P-OR' | 'P-VE' | 'T-OR' | 'T-VE' | 'G-GIN' | 'G-ANC' | 'G-UNI' | 'G-LAT'
  | 'C-EST' | 'C-ROT' | 'C-LAT' | 'C-SCH'
  | 'M-CAV' | 'M-ANC' | 'M-POS' | 'M-TOR' | 'M-SPA' | 'E-EQ' | 'F-FIA';

export type DomainKind = 'LADDER' | 'THRESHOLD' | 'TREND';
export type BandFamily = 'TUBE' | 'LOOP';

/** Un gradino della scala: variante + obiettivo. band = n-esimo elastico nell'ordine dell'utente (1 = più morbido). */
export interface LadderStep {
  level: 1 | 2 | 3 | 4 | 5;
  exerciseId: string;
  label: string;
  reps?: number;
  seconds?: number;
  band?: { family: BandFamily; index: number; door: boolean };
}

/** Una scala. perSide: ogni lato ha il suo livello. useRir: si chiede il RIR (criterio: almeno 1 ripetizione ancora possibile). */
export interface Ladder { id: string; domain: DomainId; name: string; perSide: boolean; useRir: boolean; steps: LadderStep[] }

export interface DomainDef { id: DomainId; name: string; group: 'FORZA' | 'CORE' | 'MOBILITÀ' | 'EQUILIBRIO' | 'FIATO'; kind: DomainKind; perSide: boolean }

export const DOMAINS: DomainDef[] = [
  { id: 'P-OR', name: 'Spinta orizzontale', group: 'FORZA', kind: 'LADDER', perSide: false },
  { id: 'P-VE', name: 'Spinta verticale', group: 'FORZA', kind: 'LADDER', perSide: false },
  { id: 'T-OR', name: 'Tirata orizzontale', group: 'FORZA', kind: 'LADDER', perSide: false },
  { id: 'T-VE', name: 'Tirata verticale', group: 'FORZA', kind: 'LADDER', perSide: false },
  { id: 'G-GIN', name: 'Gambe: squat', group: 'FORZA', kind: 'LADDER', perSide: false },
  { id: 'G-ANC', name: 'Gambe: anca e femorali', group: 'FORZA', kind: 'LADDER', perSide: false },
  { id: 'G-UNI', name: 'Una gamba sola', group: 'FORZA', kind: 'LADDER', perSide: true },
  { id: 'G-LAT', name: 'Anca laterale', group: 'FORZA', kind: 'LADDER', perSide: true },
  { id: 'C-EST', name: 'Core contro l\'estensione', group: 'CORE', kind: 'LADDER', perSide: false },
  { id: 'C-ROT', name: 'Core contro la rotazione', group: 'CORE', kind: 'LADDER', perSide: true },
  { id: 'C-LAT', name: 'Core laterale', group: 'CORE', kind: 'LADDER', perSide: true },
  { id: 'C-SCH', name: 'Estensori della schiena', group: 'CORE', kind: 'LADDER', perSide: false },
  { id: 'M-CAV', name: 'Mobilità della caviglia', group: 'MOBILITÀ', kind: 'THRESHOLD', perSide: true },
  { id: 'M-ANC', name: 'Mobilità dell\'anca', group: 'MOBILITÀ', kind: 'THRESHOLD', perSide: true },
  { id: 'M-POS', name: 'Retro della coscia', group: 'MOBILITÀ', kind: 'THRESHOLD', perSide: true },
  { id: 'M-TOR', name: 'Mobilità del torace', group: 'MOBILITÀ', kind: 'THRESHOLD', perSide: true },
  { id: 'M-SPA', name: 'Mobilità della spalla', group: 'MOBILITÀ', kind: 'THRESHOLD', perSide: false },
  { id: 'E-EQ', name: 'Equilibrio', group: 'EQUILIBRIO', kind: 'THRESHOLD', perSide: true },
  { id: 'F-FIA', name: 'Fiato', group: 'FIATO', kind: 'TREND', perSide: false },
];
export const domainDef = (id: DomainId) => DOMAINS.find((d) => d.id === id)!;
/** I 12 domini di forza e core: la loro mediana è il riferimento. */
export const LEVEL_DOMAINS = DOMAINS.filter((d) => d.kind === 'LADDER').map((d) => d.id);

const tube = (index: number, door: boolean) => ({ family: 'TUBE' as const, index, door });
const loop = (index: number) => ({ family: 'LOOP' as const, index, door: false });
const bandSteps = (exerciseId: string, base: string, door: boolean, reps = 10): LadderStep[] =>
  ([1, 2, 3, 4, 5] as const).map((level) => ({ level, exerciseId, label: `${base}, elastico E${level}`, reps, band: tube(level, door) }));

export const LADDERS: Ladder[] = [
  { id: 'P-OR', domain: 'P-OR', name: 'Piegamenti', perSide: false, useRir: true, steps: [
    { level: 1, exerciseId: 'ex-016', label: 'Piegamenti al muro', reps: 12 },
    { level: 2, exerciseId: 'ex-016', label: 'Piegamenti inclinati su tavolo (circa 75 cm)', reps: 10 },
    { level: 3, exerciseId: 'ex-016', label: 'Piegamenti inclinati su appoggio basso (circa 45 cm)', reps: 10 },
    { level: 4, exerciseId: 'ex-017', label: 'Piegamenti a terra', reps: 10 },
    { level: 5, exerciseId: 'ex-017', label: 'Piegamenti a terra con discesa di 3 secondi', reps: 10 },
  ] },
  { id: 'P-VE', domain: 'P-VE', name: 'Spinta sopra la testa', perSide: false, useRir: true, steps: bandSteps('ex-019', 'Spinta sopra la testa', false) },
  { id: 'T-OR', domain: 'T-OR', name: 'Rematore', perSide: false, useRir: true, steps: bandSteps('ex-021', 'Rematore in posizione di riferimento', true) },
  { id: 'T-VE', domain: 'T-VE', name: 'Tirata verso il basso', perSide: false, useRir: true, steps: bandSteps('ex-024', 'Tirata verso il basso in ginocchio, posizione di riferimento', true) },
  { id: 'G-GIN', domain: 'G-GIN', name: 'Squat', perSide: false, useRir: true, steps: [
    { level: 1, exerciseId: 'ex-001', label: 'Squat fino a sederti sulla sedia', reps: 12 },
    { level: 2, exerciseId: 'ex-001', label: 'Squat a corpo libero', reps: 15 },
    { level: 3, exerciseId: 'ex-002', label: 'Squat con elastico E2', reps: 12, band: tube(2, false) },
    { level: 4, exerciseId: 'ex-002', label: 'Squat con elastico E4', reps: 12, band: tube(4, false) },
    { level: 5, exerciseId: 'ex-002', label: 'Squat con elastico E5, discesa di 3 secondi', reps: 10, band: tube(5, false) },
  ] },
  { id: 'G-ANC', domain: 'G-ANC', name: 'Ponte e stacco', perSide: false, useRir: true, steps: [
    { level: 1, exerciseId: 'ex-010', label: 'Ponte per i glutei', reps: 15 },
    { level: 2, exerciseId: 'ex-010', label: 'Ponte con 2 secondi in alto', reps: 12 },
    { level: 3, exerciseId: 'ex-010', label: 'Ponte su una gamba (10 per lato)', reps: 10 },
    { level: 4, exerciseId: 'ex-008', label: 'Stacco rumeno con elastico E3', reps: 10, band: tube(3, false) },
    { level: 5, exerciseId: 'ex-008', label: 'Stacco rumeno con elastico E5', reps: 10, band: tube(5, false) },
  ] },
  { id: 'G-UNI', domain: 'G-UNI', name: 'Split squat e affondi', perSide: true, useRir: true, steps: [
    { level: 1, exerciseId: 'ex-003', label: 'Split squat con una mano all\'appoggio', reps: 8 },
    { level: 2, exerciseId: 'ex-003', label: 'Split squat', reps: 8 },
    { level: 3, exerciseId: 'ex-004', label: 'Affondo indietro', reps: 8 },
    { level: 4, exerciseId: 'ex-003', label: 'Split squat con discesa di 3 secondi', reps: 10 },
    { level: 5, exerciseId: 'ex-004', label: 'Affondo indietro con elastico E3', reps: 8, band: tube(3, false) },
  ] },
  { id: 'G-LAT-ABD', domain: 'G-LAT', name: 'Abduttori', perSide: true, useRir: true, steps: [
    { level: 1, exerciseId: 'ex-049', label: 'Apertura della gamba su un fianco', reps: 15 },
    { level: 2, exerciseId: 'ex-015', label: 'Passi laterali, anello 1 (X-Light)', reps: 15, band: loop(1) },
    { level: 3, exerciseId: 'ex-015', label: 'Passi laterali, anello 2 (Light)', reps: 15, band: loop(2) },
    { level: 4, exerciseId: 'ex-015', label: 'Passi laterali, anello 3 (Medium)', reps: 15, band: loop(3) },
    { level: 5, exerciseId: 'ex-015', label: 'Passi laterali, anello 4 (Heavy)', reps: 15, band: loop(4) },
  ] },
  { id: 'G-LAT-ADD', domain: 'G-LAT', name: 'Adduttori', perSide: true, useRir: true, steps: bandSteps('ex-052', 'Adduzione in piedi in posizione di riferimento', true, 12) },
  { id: 'C-EST', domain: 'C-EST', name: 'Plank e dead bug', perSide: false, useRir: false, steps: [
    { level: 1, exerciseId: 'ex-035', label: 'Plank sulle ginocchia', seconds: 30 },
    { level: 2, exerciseId: 'ex-033', label: 'Dead bug completo (10 per lato)', reps: 10 },
    { level: 3, exerciseId: 'ex-035', label: 'Plank', seconds: 30 },
    { level: 4, exerciseId: 'ex-035', label: 'Plank', seconds: 45 },
    { level: 5, exerciseId: 'ex-035', label: 'Plank con un piede sollevato (20 s per lato)', seconds: 20 },
  ] },
  { id: 'C-ROT', domain: 'C-ROT', name: 'Bird dog e Pallof press', perSide: true, useRir: true, steps: [
    { level: 1, exerciseId: 'ex-034', label: 'Bird dog', reps: 8 },
    { level: 2, exerciseId: 'ex-037', label: 'Pallof press, elastico E1', reps: 10, band: tube(1, true) },
    { level: 3, exerciseId: 'ex-037', label: 'Pallof press, elastico E2', reps: 10, band: tube(2, true) },
    { level: 4, exerciseId: 'ex-037', label: 'Pallof press, elastico E3', reps: 10, band: tube(3, true) },
    { level: 5, exerciseId: 'ex-037', label: 'Pallof press, elastico E4 con 3 s a braccia tese', reps: 10, band: tube(4, true) },
  ] },
  { id: 'C-LAT', domain: 'C-LAT', name: 'Plank laterale', perSide: true, useRir: false, steps: [
    { level: 1, exerciseId: 'ex-036', label: 'Plank laterale sulle ginocchia', seconds: 20 },
    { level: 2, exerciseId: 'ex-036', label: 'Plank laterale sulle ginocchia', seconds: 40 },
    { level: 3, exerciseId: 'ex-036', label: 'Plank laterale', seconds: 20 },
    { level: 4, exerciseId: 'ex-036', label: 'Plank laterale', seconds: 30 },
    { level: 5, exerciseId: 'ex-036', label: 'Plank laterale', seconds: 45 },
  ] },
  { id: 'C-SCH', domain: 'C-SCH', name: 'Estensione della schiena', perSide: false, useRir: false, steps: [
    { level: 1, exerciseId: 'ex-034', label: 'Bird dog (8 per lato)', reps: 8 },
    { level: 2, exerciseId: 'ex-056', label: 'Estensione da prono, braccia lungo i fianchi', seconds: 20 },
    { level: 3, exerciseId: 'ex-056', label: 'Estensione da prono, braccia lungo i fianchi', seconds: 30 },
    { level: 4, exerciseId: 'ex-056', label: 'Estensione da prono, braccia in avanti', seconds: 30 },
    { level: 5, exerciseId: 'ex-056', label: 'Estensione da prono, braccia in avanti', seconds: 45 },
  ] },
];
export const ladder = (id: string) => LADDERS.find((l) => l.id === id)!;

// --- Soglie funzionali (mobilità ed equilibrio) ----------------------------------------------------------
export type MobilityClass = 'CARENTE' | 'LIMITATA' | 'ADEGUATA';
export const CLASS_NAMES: Record<MobilityClass, string> = { CARENTE: 'carente', LIMITATA: 'limitata', ADEGUATA: 'adeguata' };

export interface ThresholdDef {
  domain: DomainId; exerciseId: string; name: string; instruction: string;
  /** cm o s: classe calcolata dal numero; CHOICE: l'utente sceglie la descrizione corrispondente. */
  input: { kind: 'NUMBER'; unit: 'cm' | 's'; max: number; classify: (v: number) => MobilityClass }
    | { kind: 'CHOICE'; options: Record<MobilityClass, string> };
}

export const THRESHOLDS: ThresholdDef[] = [
  { domain: 'M-CAV', exerciseId: 'ex-039', name: 'Ginocchio al muro',
    instruction: 'Piede davanti alla parete, ginocchio che tocca il muro e tallone sempre a terra. Allontana il piede di 1 cm alla volta: misura la distanza massima tra alluce e muro.',
    input: { kind: 'NUMBER', unit: 'cm', max: 25, classify: (v) => (v < 5 ? 'CARENTE' : v < 10 ? 'LIMITATA' : 'ADEGUATA') } },
  { domain: 'M-SPA', exerciseId: 'ex-043', name: 'Braccia sopra la testa',
    instruction: 'Supino, ginocchia piegate e schiena bassa appoggiata. Porta le braccia tese sopra la testa senza inarcare la schiena.',
    input: { kind: 'CHOICE', options: { CARENTE: 'Restano sollevate più di una spanna', LIMITATA: 'Arrivano quasi a terra', ADEGUATA: 'A terra senza inarcare' } } },
  { domain: 'M-POS', exerciseId: 'ex-054', name: 'Retro della coscia con cinghia',
    instruction: 'Supino, una gamba distesa a terra. Solleva l\'altra tesa aiutandoti con la cinghia, senza piegare il ginocchio.',
    input: { kind: 'CHOICE', options: { CARENTE: 'Meno di metà strada verso la verticale', LIMITATA: 'Oltre metà, ma non verticale', ADEGUATA: 'Verticale (circa 90°)' } } },
  { domain: 'M-ANC', exerciseId: 'ex-040', name: 'Passaggio 90/90',
    instruction: 'Seduto a terra con le gambe a 90/90: passa da un lato all\'altro tenendo il busto dritto.',
    input: { kind: 'CHOICE', options: { CARENTE: 'Non riesco', LIMITATA: 'Solo con le mani a terra', ADEGUATA: 'Senza mani' } } },
  { domain: 'M-TOR', exerciseId: 'ex-042', name: 'Libro aperto',
    instruction: 'Su un fianco, ginocchia piegate una sull\'altra. Apri il braccio di sopra verso il lato opposto seguendolo con lo sguardo.',
    input: { kind: 'CHOICE', options: { CARENTE: 'La spalla resta lontana dal tappetino', LIMITATA: 'Quasi appoggiata', ADEGUATA: 'Appoggiata senza staccare le ginocchia' } } },
  { domain: 'E-EQ', exerciseId: 'ex-006', name: 'Equilibrio su una gamba',
    instruction: 'In piedi su una gamba accanto a un appoggio, occhi aperti. Conta i secondi fino a 30 o fino a quando appoggi il piede.',
    input: { kind: 'NUMBER', unit: 's', max: 30, classify: (v) => (v < 10 ? 'CARENTE' : v < 30 ? 'LIMITATA' : 'ADEGUATA') } },
];
export const threshold = (d: DomainId) => THRESHOLDS.find((t) => t.domain === d)!;

// --- Valutazione iniziale in 3 fasi (D097 rivista, D108): le fasi si contano in sedute, non in settimane --------
/** Al massimo 3 prove per visita (circa 10 minuti); la fase successiva si apre quando la precedente è completa. */
export const PROBES_PER_VISIT = 3;
export type ProbeKind = 'LADDER' | 'THRESHOLD' | 'RATIO_H';
export interface Probe { id: string; kind: ProbeKind; ref: string; name: string; phase: 1 | 2 | 3 }

export const PROBES: Probe[] = [
  { id: 'w1-cav', kind: 'THRESHOLD', ref: 'M-CAV', name: 'Ginocchio al muro', phase: 1 },
  { id: 'w1-eq', kind: 'THRESHOLD', ref: 'E-EQ', name: 'Equilibrio su una gamba', phase: 1 },
  { id: 'w1-spa', kind: 'THRESHOLD', ref: 'M-SPA', name: 'Braccia sopra la testa', phase: 1 },
  { id: 'w1-gin', kind: 'LADDER', ref: 'G-GIN', name: 'Scala dello squat', phase: 1 },
  { id: 'w1-por', kind: 'LADDER', ref: 'P-OR', name: 'Scala dei piegamenti', phase: 1 },
  { id: 'w1-est', kind: 'LADDER', ref: 'C-EST', name: 'Plank', phase: 1 },
  { id: 'w2-tor', kind: 'LADDER', ref: 'T-OR', name: 'Scala del rematore', phase: 2 },
  { id: 'w2-rat', kind: 'RATIO_H', ref: 'T-OR/P-OR', name: 'Rematore contro spinta al petto', phase: 2 },
  { id: 'w2-anc', kind: 'LADDER', ref: 'G-ANC', name: 'Scala del ponte e dello stacco', phase: 2 },
  { id: 'w2-uni', kind: 'LADDER', ref: 'G-UNI', name: 'Split squat (per lato)', phase: 2 },
  { id: 'w2-lat', kind: 'LADDER', ref: 'C-LAT', name: 'Plank laterale (per lato)', phase: 2 },
  { id: 'w2-tor2', kind: 'THRESHOLD', ref: 'M-TOR', name: 'Libro aperto (per lato)', phase: 2 },
  { id: 'w2-pos', kind: 'THRESHOLD', ref: 'M-POS', name: 'Retro della coscia (per lato)', phase: 2 },
  { id: 'w3-pve', kind: 'LADDER', ref: 'P-VE', name: 'Spinta sopra la testa', phase: 3 },
  { id: 'w3-tve', kind: 'LADDER', ref: 'T-VE', name: 'Tirata verso il basso', phase: 3 },
  { id: 'w3-rot', kind: 'LADDER', ref: 'C-ROT', name: 'Pallof press (per lato)', phase: 3 },
  { id: 'w3-abd', kind: 'LADDER', ref: 'G-LAT-ABD', name: 'Passi laterali (per lato)', phase: 3 },
  { id: 'w3-add', kind: 'LADDER', ref: 'G-LAT-ADD', name: 'Adduzione con elastico (per lato)', phase: 3 },
  { id: 'w3-sch', kind: 'LADDER', ref: 'C-SCH', name: 'Estensione della schiena', phase: 3 },
  { id: 'w3-anc', kind: 'THRESHOLD', ref: 'M-ANC', name: 'Passaggi 90/90 (per lato)', phase: 3 },
];

/** Posizione di riferimento per gli elastici alla porta: elastico appena teso a braccia distese + 20 cm (PROVISIONAL). */
export const REFERENCE_OFFSET_CM = 20;
