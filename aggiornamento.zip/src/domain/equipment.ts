// Regole pure dell'attrezzatura (nessuna dipendenza da React o dal database).
import { ELASTIC_TYPES, type EquipmentItem, type EquipmentType, type ElasticType, type Integrity } from './types';

export const isElastic = (t: EquipmentType): t is ElasticType => (ELASTIC_TYPES as readonly string[]).includes(t);

export const TYPE_NAMES: Record<EquipmentType, { one: string; many: string }> = {
  RESISTANCE_BAND: { one: 'Elastico a tubo', many: 'Elastici a tubo (con moschettoni)' },
  LOOP_BAND: { one: 'Elastico ad anello', many: 'Elastici ad anello (loop)' },
  FIGURE8_BAND: { one: 'Elastico a 8', many: 'Elastici a 8' },
  HANDLE: { one: 'Maniglia', many: 'Maniglie' },
  ANKLE_STRAP: { one: 'Cavigliera', many: 'Cavigliere' },
  DOOR_ANCHOR: { one: 'Ancoraggio per porta', many: 'Ancoraggi per porta' },
  FITBALL: { one: 'Fitball', many: 'Fitball' },
  PILATES_BALL: { one: 'Palla Pilates', many: 'Palle Pilates' },
  YOGA_BLOCK: { one: 'Mattoncino yoga', many: 'Mattoncini yoga' },
  YOGA_STRAP: { one: 'Cinghia yoga', many: 'Cinghie yoga' },
  FOAM_ROLLER: { one: 'Rullo in schiuma (foam roller)', many: 'Rulli in schiuma' },
  MASSAGE_BALL: { one: 'Pallina da massaggio', many: 'Palline da massaggio' },
  YOGA_MAT: { one: 'Tappetino', many: 'Tappetini' },
  OTHER: { one: 'Altro', many: 'Altro' },
};

export const INTEGRITY_NAMES: Record<Integrity, string> = { OK: 'Integro', WORN: 'Usurato', DAMAGED: 'Danneggiato' };

const LABEL_RE = /^E([1-9]\d{0,2})$/;

/** «e3», «E 3», «3» → «E3». Restituisce null se il testo non è un'etichetta valida (E1…E999). */
export function normalizeLabel(input: string): string | null {
  const s = input.trim().toUpperCase().replace(/\s+/g, '');
  const withE = /^\d+$/.test(s) ? `E${s}` : s;
  return LABEL_RE.test(withE) ? withE : null;
}

export const labelNumber = (label: string | null): number => {
  const m = label ? LABEL_RE.exec(label) : null;
  return m ? Number(m[1]) : Number.POSITIVE_INFINITY;
};

/** Prima etichetta libera, considerando anche gli oggetti dismessi (un'etichetta non va mai riusata finché l'oggetto esiste). */
export function nextFreeLabel(items: Pick<EquipmentItem, 'physicalLabel'>[]): string {
  const used = new Set(items.map((i) => labelNumber(i.physicalLabel)));
  let n = 1;
  while (used.has(n)) n++;
  return `E${n}`;
}

/** Controlli su un nuovo ordinamento: deve contenere esattamente gli elastici attivi di quel tipo, senza ripetizioni. */
export function orderingErrors(bandType: ElasticType, orderedIds: string[], items: EquipmentItem[]): string[] {
  const errors: string[] = [];
  const active = items.filter((i) => i.type === bandType && i.status === 'ACTIVE');
  const activeIds = new Set(active.map((i) => i.id));
  if (new Set(orderedIds).size !== orderedIds.length) errors.push('Un elastico compare più di una volta.');
  for (const id of orderedIds) if (!activeIds.has(id)) errors.push(`Elemento ${id} non è un ${TYPE_NAMES[bandType].one.toLowerCase()} in uso.`);
  const missing = active.filter((i) => !orderedIds.includes(i.id));
  if (missing.length) errors.push(`Mancano: ${missing.map((i) => i.physicalLabel ?? i.id).join(', ')}.`);
  if (active.length < 2) errors.push('Servono almeno due elastici dello stesso tipo per stabilire un ordine.');
  return errors;
}

/**
 * Attrezzatura dell'utente: kit Odoland (contenuto e schede del produttore forniti il 23/11/2026) e piccoli attrezzi
 * dichiarati lo stesso giorno. Le sacche di trasporto del kit non sono attrezzatura di allenamento e non sono incluse.
 * Gli elastici sono elencati per tipo dal valore nominale più basso al più alto, così le etichette E1…E11
 * seguono l'ordine del produttore. La resistenza è il testo del produttore (valore nominale, a un allungamento
 * non dichiarato): resta un dato dichiarato e non è usata come carico. L'ordine reale lo conferma l'utente (D068).
 * I colori NON sono confrontabili tra tipi: il verde è il più morbido tra gli anelli e il quarto tra i tubi.
 */
export interface KitEntry { type: EquipmentType; count: number | null; color?: string; declaredResistance?: string; restLengthCm?: number; brandModel?: string; description?: string }
export const STARTER_KIT: KitEntry[] = [
  { type: 'RESISTANCE_BAND', count: 1, color: 'giallo', declaredResistance: '4,6 kg nominali (10 lb)', restLengthCm: 115, brandModel: 'Odoland' },
  { type: 'RESISTANCE_BAND', count: 1, color: 'rosso', declaredResistance: '9,1 kg nominali (20 lb)', restLengthCm: 115, brandModel: 'Odoland' },
  { type: 'RESISTANCE_BAND', count: 1, color: 'blu', declaredResistance: '13,7 kg nominali (30 lb)', restLengthCm: 115, brandModel: 'Odoland' },
  { type: 'RESISTANCE_BAND', count: 1, color: 'verde', declaredResistance: '18,2 kg nominali (40 lb)', restLengthCm: 115, brandModel: 'Odoland' },
  { type: 'RESISTANCE_BAND', count: 1, color: 'nero', declaredResistance: '22,7 kg nominali (50 lb)', restLengthCm: 115, brandModel: 'Odoland' },
  { type: 'LOOP_BAND', count: 1, color: 'verde', declaredResistance: 'X-Light, 10 lb (≈4,5 kg nominali)', restLengthCm: 60, brandModel: 'Odoland' },
  { type: 'LOOP_BAND', count: 1, color: 'blu', declaredResistance: 'Light, 20 lb (≈9,1 kg nominali)', restLengthCm: 60, brandModel: 'Odoland' },
  { type: 'LOOP_BAND', count: 1, color: 'giallo', declaredResistance: 'Medium, 30 lb (≈13,6 kg nominali)', restLengthCm: 60, brandModel: 'Odoland' },
  { type: 'LOOP_BAND', count: 1, color: 'rosso', declaredResistance: 'Heavy, 40 lb (≈18,1 kg nominali)', restLengthCm: 60, brandModel: 'Odoland' },
  { type: 'LOOP_BAND', count: 1, color: 'nero', declaredResistance: 'X-Heavy, 50 lb (≈22,7 kg nominali)', restLengthCm: 60, brandModel: 'Odoland' },
  { type: 'FIGURE8_BAND', count: 1, color: 'nero', brandModel: 'Odoland' }, // colore dalla foto del produttore; resistenza non dichiarata
  { type: 'HANDLE', count: 2, brandModel: 'Odoland' },
  { type: 'ANKLE_STRAP', count: 2, brandModel: 'Odoland' },
  { type: 'DOOR_ANCHOR', count: 1, brandModel: 'Odoland' },
  { type: 'FITBALL', count: 1, description: 'diametro 65 cm' },
  { type: 'PILATES_BALL', count: 1, description: 'diametro 25 cm' },
  { type: 'YOGA_BLOCK', count: 2 },
  { type: 'YOGA_STRAP', count: 1 },
  { type: 'FOAM_ROLLER', count: 1 },
  { type: 'MASSAGE_BALL', count: 1, description: 'a doppia sfera (peanut) 8 cm' },
  { type: 'MASSAGE_BALL', count: 1, description: 'a doppia sfera (peanut) 12 cm' },
  { type: 'MASSAGE_BALL', count: 1, description: 'a riccio 9 cm' },
];
