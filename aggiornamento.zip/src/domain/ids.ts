// UUIDv7 (RFC 9562): ordinabile per tempo, generabile offline senza coordinamento.
// Monotono anche nello stesso millisecondo (RFC 9562 §6.2, metodo 1: contatore a 12 bit nei bit «rand_a»),
// così due decisioni registrate di seguito restano nell'ordine giusto (DEF-13).
let lastMs = -1;
let counter = 0;
export function uuidv7(now: number = Date.now()): string {
  let ms = Math.floor(now);
  if (ms <= lastMs) { ms = lastMs; counter += 1; if (counter > 0xfff) { ms += 1; counter = 0; } }
  else counter = Math.floor(Math.random() * 0x800); // parte da metà intervallo: lascia spazio agli incrementi
  lastMs = ms;
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  const ts = BigInt(ms);
  for (let i = 0; i < 6; i++) bytes[i] = Number((ts >> BigInt(8 * (5 - i))) & 0xffn);
  bytes[6] = 0x70 | ((counter >> 8) & 0x0f);
  bytes[7] = counter & 0xff;
  bytes[8] = (bytes[8]! & 0x3f) | 0x80;
  const h = [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

export const nowIso = (): string => new Date().toISOString();
export const tzOffset = (): number => new Date().getTimezoneOffset();
