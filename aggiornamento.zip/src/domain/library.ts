// Libreria esercizi: classificazione (20, 26) e regole pure. Nessuna dipendenza da React o dal database.
// La classificazione serve al motore (F3) per scegliere gli esercizi; il contenuto (istruzioni) arriva a ondate (D095).
import type { EquipmentType } from './types';

/** Schema motorio principale (03 §2). Aggiunti BALANCE e ISOLATION (monoarticolari) per non forzare esercizi in pattern impropri. */
export type Pattern =
  | 'SQUAT' | 'LUNGE' | 'HINGE' | 'HIP_EXTENSION' | 'KNEE_FLEXION'
  | 'HORIZONTAL_PUSH' | 'VERTICAL_PUSH' | 'HORIZONTAL_PULL' | 'VERTICAL_PULL'
  | 'CORE_DYNAMIC' | 'ANTI_EXTENSION' | 'ANTI_ROTATION' | 'ANTI_LATERAL_FLEXION'
  | 'LOCOMOTION' | 'MOBILITY_CONTROL' | 'ANKLE_PLANTAR_FLEXION' | 'BALANCE' | 'ISOLATION';

/** Distretti muscolari (03 §2), più cuffia dei rotatori, flessori dell'anca e muscoli del piede. Nessuna percentuale. */
export type Muscle =
  | 'QUADS' | 'GLUTE_MAX' | 'GLUTE_MED' | 'HAMSTRINGS' | 'ADDUCTORS' | 'CALVES' | 'HIP_FLEXORS'
  | 'CHEST' | 'LATS' | 'MID_BACK' | 'ERECTORS' | 'DELT_ANT' | 'DELT_LAT' | 'DELT_POST' | 'ROTATOR_CUFF'
  | 'BICEPS' | 'TRICEPS' | 'FOREARMS' | 'CORE' | 'FOOT';

export type Joint = 'ANKLE' | 'HIP' | 'THORACIC' | 'SPINE' | 'SHOULDER' | 'HAMSTRINGS_LENGTH';
export type ExerciseFunction = 'STRENGTH' | 'HYPERTROPHY' | 'MOBILITY' | 'MOTOR_CONTROL' | 'STABILITY' | 'BALANCE' | 'CONDITIONING';

/** Gruppo mostrato nella Libreria (filtro semplice per l'utente). */
export type LibraryGroup = 'LEGS' | 'PUSH' | 'PULL' | 'ARMS_SHOULDERS' | 'CORE' | 'MOBILITY' | 'BALANCE' | 'CONDITIONING';

/** Che cosa va impostato prima di iniziare: decide il modulo di configurazione e la comparabilità. */
export type SetupKind =
  | 'TUBE_DOOR'  // elastici a tubo con ancoraggio alla porta: elastici + altezza + distanza dalla porta
  | 'TUBE_FREE'  // elastici a tubo senza porta (sotto i piedi): solo elastici
  | 'LOOP'       // elastico ad anello: quale anello
  | 'NONE';      // corpo libero o piccoli attrezzi

export type DoorAnchor = 'DOOR_LOW' | 'DOOR_MID' | 'DOOR_HIGH';

/** Appoggi della casa: non sono attrezzi da censire. */
export type HouseNeed = 'WALL' | 'SUPPORT';

export interface ExerciseMeta {
  group: LibraryGroup;
  pattern: Pattern;
  primary: Muscle[];
  secondary: Muscle[];
  joints: Joint[];               // per la mobilità; vuoto altrimenti
  functions: ExerciseFunction[];
  equipment: EquipmentType[];    // tipi necessari, da cercare tra gli attrezzi in uso
  needs: HouseNeed[];
  setup: SetupKind;
  anchor: DoorAnchor | null;     // solo TUBE_DOOR
  complexity: 1 | 2 | 3;         // 1 semplice, 2 media, 3 alta
  unilateral: boolean;           // una serie = lato sinistro + lato destro
  repsPerSide: boolean;          // movimento alternato: le ripetizioni si contano per lato in un'unica serie
  measure: 'REPS' | 'DURATION';
  effort: 'RIR' | 'NONE';        // RIR richiesto in registrazione (D084) solo dove ha senso
  defaults: { sets: [number, number]; reps: [number, number] | null; durationS: [number, number] | null; rir: [number, number] | null };
}

export const GROUP_NAMES: Record<LibraryGroup, string> = {
  LEGS: 'Gambe', PUSH: 'Spinte', PULL: 'Tirate', ARMS_SHOULDERS: 'Braccia e spalle', CORE: 'Core',
  MOBILITY: 'Mobilità', BALANCE: 'Equilibrio', CONDITIONING: 'Fiato',
};

export const MUSCLE_NAMES: Record<Muscle, string> = {
  QUADS: 'quadricipiti', GLUTE_MAX: 'grande gluteo', GLUTE_MED: 'medio gluteo', HAMSTRINGS: 'femorali', ADDUCTORS: 'adduttori',
  CALVES: 'polpacci', HIP_FLEXORS: 'flessori dell\'anca', CHEST: 'pettorali', LATS: 'dorsali', MID_BACK: 'trapezio e romboidi',
  ERECTORS: 'muscoli lungo la colonna', DELT_ANT: 'deltoide anteriore', DELT_LAT: 'deltoide laterale', DELT_POST: 'deltoide posteriore',
  ROTATOR_CUFF: 'cuffia dei rotatori', BICEPS: 'bicipiti', TRICEPS: 'tricipiti', FOREARMS: 'avambracci', CORE: 'addominali e core', FOOT: 'muscoli del piede',
};

export const JOINT_NAMES: Record<Joint, string> = {
  ANKLE: 'caviglia', HIP: 'anca', THORACIC: 'torace', SPINE: 'colonna', SHOULDER: 'spalla', HAMSTRINGS_LENGTH: 'retro della coscia',
};

export const NEED_NAMES: Record<HouseNeed, string> = { WALL: 'una parete libera', SUPPORT: 'un appoggio stabile (tavolo, ripiano, schienale robusto)' };

export const ANCHOR_LABEL: Record<DoorAnchor, string> = { DOOR_LOW: 'in basso', DOOR_MID: 'a metà altezza', DOOR_HIGH: 'in alto' };

/** Tipi di attrezzo in uso dell'utente → attrezzi mancanti per l'esercizio (vuoto = eseguibile). */
export function missingEquipment(meta: Pick<ExerciseMeta, 'equipment'>, available: ReadonlySet<EquipmentType>): EquipmentType[] {
  return meta.equipment.filter((t) => !available.has(t));
}

/** Testo dell'obiettivo di una serie, es. «8–15 ripetizioni» o «20–40 secondi per lato». */
export function targetText(meta: ExerciseMeta): string {
  const side = meta.unilateral || meta.repsPerSide ? ' per lato' : '';
  if (meta.measure === 'DURATION' && meta.defaults.durationS) return `${meta.defaults.durationS[0]}–${meta.defaults.durationS[1]} secondi${side}`;
  if (meta.defaults.reps) return `${meta.defaults.reps[0]}–${meta.defaults.reps[1]} ripetizioni${side}`;
  return '';
}

/** Controlli di coerenza della classificazione: usati dai test della libreria. */
export function metaErrors(m: ExerciseMeta): string[] {
  const e: string[] = [];
  if (m.measure === 'REPS' && !m.defaults.reps) e.push('misura a ripetizioni senza intervallo di ripetizioni');
  if (m.measure === 'DURATION' && !m.defaults.durationS) e.push('misura a tempo senza intervallo di durata');
  if (m.effort === 'RIR' && !m.defaults.rir) e.push('RIR richiesto senza intervallo di RIR');
  if (m.effort === 'NONE' && m.defaults.rir) e.push('RIR indicato per un esercizio senza RIR');
  if (m.unilateral && m.repsPerSide) e.push('unilaterale e alternato insieme');
  if (m.setup === 'TUBE_DOOR' && (!m.anchor || !m.equipment.includes('DOOR_ANCHOR') || !m.equipment.includes('RESISTANCE_BAND'))) e.push('ancoraggio alla porta incompleto');
  if (m.setup !== 'TUBE_DOOR' && m.anchor) e.push('altezza di ancoraggio senza porta');
  if (m.setup === 'TUBE_FREE' && !m.equipment.includes('RESISTANCE_BAND')) e.push('elastico a tubo mancante');
  if (m.setup === 'LOOP' && !m.equipment.includes('LOOP_BAND')) e.push('elastico ad anello mancante');
  if (m.group !== 'MOBILITY' && m.group !== 'BALANCE' && m.group !== 'CONDITIONING' && m.primary.length === 0) e.push('nessun muscolo principale');
  if (m.group === 'MOBILITY' && m.joints.length === 0) e.push('mobilità senza articolazione');
  if (m.defaults.sets[0] > m.defaults.sets[1]) e.push('serie: intervallo invertito');
  return e;
}
