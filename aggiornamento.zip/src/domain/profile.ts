// Regole pure del profilo. I limiti servono solo a intercettare errori di battitura: non sono soglie cliniche.
import type { ExperienceLevel, ProfileVersion } from './types';

export const EXPERIENCE_NAMES: Record<ExperienceLevel, string> = {
  NONE: 'Nessuna esperienza di allenamento con sovraccarichi',
  LESS_THAN_6_MONTHS: 'Meno di 6 mesi',
  FROM_6_TO_24_MONTHS: 'Da 6 mesi a 2 anni',
  MORE_THAN_24_MONTHS: 'Più di 2 anni',
};

export type ProfileInput = Omit<ProfileVersion, 'id' | 'recordedAt' | 'tzOffsetMin'>;

export function profileErrors(p: ProfileInput, now = new Date()): string[] {
  const e: string[] = [];
  const y = now.getFullYear();
  if (p.birthYear !== null && (!Number.isInteger(p.birthYear) || p.birthYear < 1900 || p.birthYear > y)) e.push(`Anno di nascita: inserire un anno tra 1900 e ${y}.`);
  if (p.heightCm !== null && (!Number.isFinite(p.heightCm) || p.heightCm < 100 || p.heightCm > 250)) e.push('Altezza: inserire un valore tra 100 e 250 cm.');
  if (p.weightKg !== null && (!Number.isFinite(p.weightKg) || p.weightKg < 30 || p.weightKg > 300)) e.push('Peso: inserire un valore tra 30 e 300 kg.');
  return e;
}

const KEYS: (keyof ProfileInput)[] = ['birthYear', 'heightCm', 'weightKg', 'experience', 'usualActivities', 'notes'];
export const sameProfile = (a: ProfileInput, b: ProfileInput): boolean => KEYS.every((k) => a[k] === b[k]);

/** Testo vuoto → null (dato mancante, mai stringa vuota). */
export const textOrNull = (s: string): string | null => (s.trim() === '' ? null : s.trim());
/** Numero da campo di testo: vuoto → null; virgola decimale accettata; non numerico → NaN (lo segnalano i controlli). */
export const numberOrNull = (s: string): number | null => (s.trim() === '' ? null : Number(s.trim().replace(',', '.')));
