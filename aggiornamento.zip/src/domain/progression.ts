// Doppia progressione con proposta (D078–D082). Funzioni pure: nessun accesso a database o interfaccia.
// Le soglie sono PROVISIONAL (D039): da calibrare con i dati reali.
import { compare, sameBands } from './comparability';
import type { ConfigurationSnapshot, ProposalKind, RejectionReason, SetStatus, SetPerformance } from './types';

export const PROGRESSION_RULE_VERSION = 'band-row-1';
export const DISTANCE_STEP_CM = 10;        // D081: primo passo = allontanarsi dalla porta
export const CONFIRMING_EXPOSURES = 2;      // D080: due sedute consecutive in classe A
export const MAX_BANDS_COMBINED = 2;

export interface ExposureSet { status: SetStatus; reps: number | null; rir: number | null; techniqueQuality: SetPerformance['techniqueQuality']; discomfort: boolean | null }
export interface Exposure {
  sessionId: string;
  endedAt: string;
  config: ConfigurationSnapshot | null; // null se incompleta o cambiata durante la seduta
  prescribedSets: number;
  repMax: number;
  targetRir: number;
  sets: ExposureSet[];
}
export interface TubeInfo { id: string; label: string }
export interface PastRejection { kind: ProposalKind; fromConfig: ConfigurationSnapshot | null; proposedConfig: ConfigurationSnapshot | null; reason: RejectionReason }
export interface ProgressionContext {
  exposures: Exposure[];               // dalla più recente, solo sedute chiuse con questo esercizio
  orderedTubes: TubeInfo[] | null;     // tubi in uso e non danneggiati, dal più morbido; null se l'ordine manca o va aggiornato
  startDistanceCm: (cfg: ConfigurationSnapshot) => number | null; // distanza della prima seduta con questi elastici e ancoraggio
  rejections: PastRejection[];
  labelOf: (id: string) => string;
}
export interface Evaluation {
  kind: ProposalKind;
  proposedConfig: ConfigurationSnapshot | null;
  reason: string;
  evidence: Record<string, unknown>;
}

/** Motivi per cui un'esposizione NON raggiunge l'obiettivo (lista vuota = obiettivo raggiunto). */
export function unmetConditions(e: Exposure): string[] {
  const out: string[] = [];
  const performed = e.sets.filter((s) => s.status === 'PERFORMED');
  if (e.sets.some((s) => s.status === 'INTERRUPTED')) out.push('una serie è stata interrotta');
  if (performed.length < e.prescribedSets) out.push(`serie eseguite ${performed.length} su ${e.prescribedSets}`);
  performed.forEach((s, i) => {
    const n = i + 1;
    if (s.reps === null || s.reps < e.repMax) out.push(`serie ${n}: ${s.reps ?? '—'} ripetizioni su ${e.repMax}`);
    if (s.rir === null) out.push(`serie ${n}: RIR non indicato`);
    else if (s.rir < e.targetRir) out.push(`serie ${n}: RIR ${s.rir}, serve almeno ${e.targetRir}`);
    if (s.techniqueQuality === 'POOR') out.push(`serie ${n}: tecnica scarsa`);
  });
  return out;
}

const hasDiscomfort = (e: Exposure) => e.sets.some((s) => s.discomfort === true);

/** Fastidio in almeno 2 delle ultime 3 sedute: suggerire il parere di un professionista (D082). */
export const repeatedDiscomfort = (exposures: Exposure[]): boolean => exposures.slice(0, 3).filter(hasDiscomfort).length >= 2;

const bandsText = (ids: string[], ctx: ProgressionContext) => ids.map(ctx.labelOf).join(' + ');

export function evaluate(ctx: ProgressionContext): Evaluation | null {
  const [cur, prev] = ctx.exposures;
  if (!cur) return null;
  const evidence: Record<string, unknown> = { ruleVersion: PROGRESSION_RULE_VERSION, current: cur.sessionId, previous: prev?.sessionId ?? null };
  const keep = (reason: string, extra: Record<string, unknown> = {}): Evaluation => ({ kind: 'MAINTAIN', proposedConfig: null, reason, evidence: { ...evidence, ...extra } });

  if (hasDiscomfort(cur)) {
    return { kind: 'BLOCKED_DISCOMFORT', proposedConfig: null, evidence,
      reason: 'Hai segnalato un fastidio: oggi nessuna proposta di aumentare la difficoltà. Alla prossima seduta mantieni la stessa configurazione.' };
  }
  if (!cur.config) return keep('Configurazione incompleta o cambiata durante la seduta: questa seduta non si può confrontare (classe D). Mantieni la configurazione.', { comparability: 'D' });
  const unmet = unmetConditions(cur);
  if (unmet.length) {
    return keep(`Continua così. Per proporti un aumento servono ${cur.prescribedSets} serie da ${cur.repMax} ripetizioni con RIR almeno ${cur.targetRir}, in due sedute di fila con la stessa configurazione. Oggi: ${unmet.slice(0, 3).join('; ')}.`, { unmet });
  }
  if (!prev) return keep('Obiettivo raggiunto! Serve una conferma: se alla prossima seduta, con la stessa configurazione, lo raggiungi di nuovo, ti proporrò un aumento.');
  const cls = compare(prev.config, cur.config);
  evidence.comparability = cls;
  if (cls !== 'A') return keep(`Obiettivo raggiunto! La seduta precedente aveva una configurazione diversa (classe ${cls}): serve una conferma alla prossima seduta con la stessa configurazione.`);
  const prevUnmet = unmetConditions(prev);
  if (prevUnmet.length || hasDiscomfort(prev)) return keep('Obiettivo raggiunto! Nella seduta precedente non era ancora raggiunto: serve una conferma alla prossima seduta con la stessa configurazione.', { previousUnmet: prevUnmet });
  return propose(ctx, cur.config, evidence);
}

/** Primo passo disponibile (D081): distanza → elastico successivo → combinazione solo oltre l'elastico più duro (D081-bis, da approvare). */
export function propose(ctx: ProgressionContext, cfg: ConfigurationSnapshot, evidence: Record<string, unknown>): Evaluation {
  const rejected = (kind: ProposalKind, reason: RejectionReason, test: (r: PastRejection) => boolean) =>
    ctx.rejections.some((r) => r.kind === kind && r.reason === reason && r.fromConfig && sameBands(r.fromConfig, cfg) && r.fromConfig.anchor === cfg.anchor && test(r));
  const base = { configurationId: null, anchorHeightCm: null, notes: null };

  // 1. Allontanarsi dalla porta, salvo spazio dichiarato insufficiente per questa distanza.
  const newDistance = cfg.distanceCm! + DISTANCE_STEP_CM;
  if (!rejected('INCREASE_DISTANCE', 'NO_SPACE', (r) => (r.proposedConfig?.distanceCm ?? Infinity) <= newDistance)) {
    return { kind: 'INCREASE_DISTANCE', evidence, proposedConfig: { ...base, bandIds: [...cfg.bandIds], anchor: cfg.anchor, distanceCm: newDistance },
      reason: `Obiettivo raggiunto in due sedute di fila. Proposta: stessi elastici (${bandsText(cfg.bandIds, ctx)}), allontanati dalla porta di ${DISTANCE_STEP_CM} cm (da ${cfg.distanceCm} a ${newDistance} cm). L'elastico sarà più teso.` };
  }
  if (!ctx.orderedTubes) {
    return { kind: 'NONE_AVAILABLE', proposedConfig: null, evidence,
      reason: 'Per proporti un elastico più duro serve l\'ordine dei tubi dal più morbido al più duro: completalo in Profilo → Attrezzatura. Intanto mantieni la configurazione.' };
  }
  const order = ctx.orderedTubes.map((t) => t.id);
  const start = ctx.startDistanceCm(cfg) ?? cfg.distanceCm!;
  // 2. Elastico successivo, alla distanza di partenza.
  if (cfg.bandIds.length === 1) {
    const idx = order.indexOf(cfg.bandIds[0]!);
    const next = idx >= 0 ? order[idx + 1] : undefined;
    if (next) {
      if (rejected('NEXT_BAND', 'JUMP_TOO_BIG', (r) => r.proposedConfig?.bandIds.includes(next) ?? false)) {
        // Con il kit dell'utente i tubi combinati danno gli stessi valori nominali del tubo successivo (es. E1+E2 = E3):
        // una combinazione non sarebbe un passo più piccolo. Nessuna proposta, si ripropone alla prossima conferma.
        return { kind: 'NONE_AVAILABLE', proposedConfig: null, evidence,
          reason: `Non c'è un passo più piccolo del passaggio a ${ctx.labelOf(next)}: con i tuoi tubi una combinazione equivale all'elastico successivo. Mantieni la configurazione attuale; te lo riproporrò quando confermerai di nuovo l'obiettivo.` };
      }
      return { kind: 'NEXT_BAND', evidence, proposedConfig: { ...base, bandIds: [next], anchor: cfg.anchor, distanceCm: start },
        reason: `Obiettivo raggiunto in due sedute di fila e non puoi allontanarti di più. Proposta: passa da ${ctx.labelOf(cfg.bandIds[0]!)} a ${ctx.labelOf(next)} e torna alla distanza di partenza (${start} cm). È normale ripartire da 8–10 ripetizioni.` };
    }
  }
  // 3. Combinazione, solo oltre l'elastico più duro: si aggiunge il tubo più morbido.
  if (cfg.bandIds.length < MAX_BANDS_COMBINED) {
    const add = order.find((id) => !cfg.bandIds.includes(id));
    if (add) {
      const ids = [...cfg.bandIds, add];
      return { kind: 'ADD_BAND', evidence, proposedConfig: { ...base, bandIds: ids, anchor: cfg.anchor, distanceCm: start },
        reason: `Hai raggiunto l'elastico più duro. Proposta: usa insieme ${bandsText(ids, ctx)}, alla distanza di partenza (${start} cm). È normale ripartire da 8–10 ripetizioni.` };
    }
  }
  return { kind: 'NONE_AVAILABLE', proposedConfig: null, evidence,
    reason: 'Hai raggiunto la configurazione più impegnativa prevista per questo esercizio. Mantienila: più avanti valuteremo una variante più difficile.' };
}
