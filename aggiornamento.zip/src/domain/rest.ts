// Recupero tra le serie (D101, valori PROVISIONAL da 26: «recupero 60–120 s, adattabile»).
// Regola deterministica e spiegabile: tipo di esercizio + quanto è stata dura l'ultima serie.
import type { ExerciseMeta } from './library';
import type { Side } from './types';

export const REST_STEP_S = 30;        // pulsante «+30 s»
export const BETWEEN_SIDES_S = 15;    // tra lato sinistro e destro della stessa serie
export const HARD_SET_EXTRA_S = 30;   // ultima serie con RIR 0–1

export type RestKind = 'MAIN' | 'COMPLEMENTARY' | 'CORE' | 'MOBILITY' | 'CONDITIONING';
export const REST_BASE_S: Record<RestKind, number> = { MAIN: 90, COMPLEMENTARY: 60, CORE: 45, MOBILITY: 30, CONDITIONING: 45 };

export function restKind(m: Pick<ExerciseMeta, 'group' | 'pattern'>): RestKind {
  if (m.group === 'MOBILITY' || m.group === 'BALANCE') return 'MOBILITY';
  if (m.group === 'CONDITIONING') return 'CONDITIONING';
  if (m.group === 'CORE') return 'CORE';
  if (m.pattern === 'ISOLATION' || m.pattern === 'ANKLE_PLANTAR_FLEXION' || m.group === 'ARMS_SHOULDERS') return 'COMPLEMENTARY';
  return 'MAIN';
}

export interface RestAdvice { seconds: number; reason: string }

/** Recupero suggerito dopo la serie appena registrata. */
export function suggestRest(m: Pick<ExerciseMeta, 'group' | 'pattern' | 'effort'>, last: { side: Side | null; rir: number | null }, nextSide: Side): RestAdvice {
  if (last.side === 'LEFT' && nextSide === 'RIGHT') return { seconds: BETWEEN_SIDES_S, reason: 'Pausa breve, poi l\'altro lato' };
  const kind = restKind(m);
  const base = REST_BASE_S[kind];
  if (m.effort === 'RIR' && last.rir !== null && last.rir <= 1) return { seconds: base + HARD_SET_EXTRA_S, reason: 'Serie molto dura: 30 secondi in più' };
  const why: Record<RestKind, string> = {
    MAIN: 'Esercizio principale', COMPLEMENTARY: 'Esercizio complementare', CORE: 'Esercizio per il core',
    MOBILITY: 'Mobilità o equilibrio', CONDITIONING: 'Esercizio di fiato',
  };
  return { seconds: base, reason: why[kind] };
}
