// Recupero reale (D111): misurato al tocco di «Inizio la serie»; altrimenti stimato togliendo dall'intervallo tra
// le registrazioni la durata stimata della serie. Funzione pura, testata.
import type { RestRecord } from './types';

/** Durata stimata di una serie: circa 3 s a ripetizione, oppure i secondi dichiarati, più 5 s per prepararsi. */
export const estimateSetSeconds = (v: { reps: number | null; durationS: number | null }): number =>
  (v.durationS ?? (v.reps ?? 0) * 3) + 5;

export interface RestTiming { startedAt: number; suggestedS: number; addedS: number; setStartedAt: number | null }

export function restRecord(t: RestTiming, savedAt: number, set: { reps: number | null; durationS: number | null }): RestRecord {
  const totalS = t.suggestedS + t.addedS;
  const intervalS = Math.max(0, Math.round((savedAt - t.startedAt) / 1000));
  if (t.setStartedAt !== null) {
    const elapsedS = Math.max(0, Math.round((t.setStartedAt - t.startedAt) / 1000));
    return { suggestedS: t.suggestedS, addedS: t.addedS, elapsedS, skipped: elapsedS < totalS, intervalS, measured: 'TAP' };
  }
  const elapsedS = Math.max(0, intervalS - estimateSetSeconds(set));
  return { suggestedS: t.suggestedS, addedS: t.addedS, elapsedS, skipped: elapsedS < totalS, intervalS, measured: 'ESTIMATED' };
}
