// Ricerca negli esercizi: senza accenti né maiuscole, tutte le parole devono comparire (nome italiano, nome inglese,
// gruppo, muscoli, articolazioni, attrezzi). «femorali» trova anche lo stacco rumeno.
import { TYPE_NAMES } from './equipment';
import { GROUP_NAMES, JOINT_NAMES, MUSCLE_NAMES, type ExerciseMeta } from './library';

export const normalize = (s: string): string => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();

export function searchText(e: { displayName: string; canonicalName: string; meta: ExerciseMeta }): string {
  const m = e.meta;
  return normalize([
    e.displayName, e.canonicalName, GROUP_NAMES[m.group],
    ...m.primary.map((x) => MUSCLE_NAMES[x]), ...m.secondary.map((x) => MUSCLE_NAMES[x]), ...m.joints.map((x) => JOINT_NAMES[x]),
    ...m.equipment.map((t) => `${TYPE_NAMES[t].one} ${TYPE_NAMES[t].many}`), m.needs.includes('WALL') ? 'parete muro' : '',
  ].join(' '));
}

export function matches(query: string, haystack: string): boolean {
  const words = normalize(query).split(' ').filter(Boolean);
  return words.every((w) => haystack.includes(w));
}
