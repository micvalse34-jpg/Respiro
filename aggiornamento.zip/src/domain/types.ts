// Sottoinsieme del modello 21_DATA_MODEL_END_TO_END con le estensioni M2 approvate (D6).
// Regola trasversale: dato mancante = null, mai 0 o stringa vuota.
import type { ExerciseMeta } from './library';

export type Iso = string; // timestamp ISO 8601 in UTC
export type Id = string;  // UUIDv7 generato sul client

export type SessionStatus =
  | 'GENERATED'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'PARTIALLY_COMPLETED'
  | 'CANCELLED';

export type PrescriptionOrigin = 'ENGINE' | 'USER_ADDED' | 'SUBSTITUTION';
export type Side = 'LEFT' | 'RIGHT' | 'BILATERAL';
export type SetStatus = 'PERFORMED' | 'INTERRUPTED' | 'NOT_PERFORMED';
export type CloseReason = 'FINISHED_BY_USER' | 'CLOSED_ON_REOPEN';

export interface ConfigurationSnapshot {
  configurationId: Id | null;
  bandIds: Id[];
  anchor: string | null;
  anchorHeightCm: number | null;
  distanceCm: number | null;
  notes: string | null;
}

// --- Attrezzatura (04, D068) -------------------------------------------------------------
// Elastici: ogni oggetto ha un'etichetta fisica numerata (E1, E2…) e un ordine dichiarato
// dall'utente dal più morbido al più duro. Nessuna conversione in kg (D028).
export const ELASTIC_TYPES = ['RESISTANCE_BAND', 'LOOP_BAND', 'FIGURE8_BAND'] as const;
export const ACCESSORY_TYPES = [
  'HANDLE', 'ANKLE_STRAP', 'DOOR_ANCHOR', 'FITBALL', 'PILATES_BALL', 'YOGA_BLOCK', 'YOGA_STRAP', 'FOAM_ROLLER', 'MASSAGE_BALL', 'YOGA_MAT', 'OTHER',
] as const;
export type ElasticType = (typeof ELASTIC_TYPES)[number];
export type AccessoryType = (typeof ACCESSORY_TYPES)[number];
export type EquipmentType = ElasticType | AccessoryType;
export type Integrity = 'OK' | 'WORN' | 'DAMAGED';
export type EquipmentStatus = 'ACTIVE' | 'RETIRED';

export interface EquipmentItem {
  id: Id;
  type: EquipmentType;          // immutabile
  physicalLabel: string | null; // «E3»: obbligatoria per gli elastici, immutabile; null per gli accessori
  description: string | null;
  color: string | null;
  brandModel: string | null;
  declaredResistance: string | null; // testo del produttore così com'è, mai convertito in kg
  restLengthCm: number | null;
  integrity: Integrity | null;       // null = non verificato
  quantity: number | null;           // elastici sempre 1 (oggetto singolo); accessori anche >1; null = numero non indicato
  status: EquipmentStatus;           // RETIRED: non più in uso, conservato per lo storico
  notes: string | null;
  createdAt: Iso;
  updatedAt: Iso;
  retiredAt: Iso | null;
}

/** Ordine dichiarato dall'utente, dal più morbido al più duro. Solo aggiunte: l'ultimo per tipo è quello valido. */
export interface BandOrdering {
  id: Id;
  bandType: ElasticType;
  orderedIds: Id[];
  method: 'USER_DECLARED';
  declaredAt: Iso;
  tzOffsetMin: number;
  note: string | null;
}

// --- Profilo (01, 21, 25 §4 parte anagrafica) ----------------------------------------------
// Solo aggiunte: ogni salvataggio con modifiche crea una nuova versione (storico non distruttivo, D032).
export type ExperienceLevel = 'NONE' | 'LESS_THAN_6_MONTHS' | 'FROM_6_TO_24_MONTHS' | 'MORE_THAN_24_MONTHS';

export interface ProfileVersion {
  id: Id;
  birthYear: number | null;
  heightCm: number | null;
  weightKg: number | null;
  experience: ExperienceLevel | null;
  usualActivities: string | null;
  notes: string | null;
  recordedAt: Iso;
  tzOffsetMin: number;
}

export interface Exercise { id: Id; canonicalName: string; createdAt: Iso }

// A/B/C: sedute del motore (fasi successive). FREE: seduta libera scelta dall'utente (vertical slice). POC: prova.
export type SessionType = 'A' | 'B' | 'C' | 'FREE' | 'POC';

/**
 * Contenuto tecnico dell'esercizio, scritto da Claude con fonti citate (D092). Resta sempre DRAFT nella versione:
 * «provata» è una decisione dell'utente registrata a parte (decision log), non una proprietà del testo.
 * VALIDATED è conservato solo per compatibilità con i backup: non viene più usato.
 * I campi facoltativi sono assenti nella versione 2 del Band Row (slice).
 */
export interface ExerciseContent {
  displayName: string;
  status: 'DRAFT' | 'VALIDATED';
  setup: string[];
  cues: string[];
  commonErrors: string[];
  safetyChecks: string[];
  defaultAnchor: 'DOOR_LOW' | 'DOOR_MID' | 'DOOR_HIGH' | null;
  purpose?: string;            // a che cosa serve, in una frase
  stopIf?: string[];           // quando fermarsi (nessuna diagnosi)
  easier?: string[];           // regressioni
  harder?: string[];           // progressioni
  variants?: { name: string; description: string }[];
  sources?: string[];          // identificativi del registro fonti della libreria
}

export interface ExerciseVersion {
  id: Id;
  exerciseId: Id;
  version: number;
  unilateral: boolean;
  measure: 'REPS' | 'DURATION';
  breathing: string | null;         // null = scheda in preparazione
  content?: ExerciseContent | null; // assente nelle versioni del POC; null = scheda in preparazione
  meta?: ExerciseMeta | null;       // classificazione (F2); assente nelle versioni precedenti
  createdAt: Iso;
}

export interface WorkoutSession {
  id: Id;
  sessionType: SessionType;
  status: SessionStatus;
  startedAt: Iso;
  tzOffsetMin: number; // offset locale al momento dell'evento (minuti, convenzione Date.getTimezoneOffset)
  endedAt: Iso | null;
  updatedAt: Iso;
  closeReason: CloseReason | null;
}

export interface ExercisePrescription {
  id: Id;
  sessionId: Id;
  exerciseId: Id;
  exerciseVersionId: Id;
  order: number;
  origin: PrescriptionOrigin;
  prescribedSets: number;
  repMin: number | null;
  repMax: number | null;
  targetDurationS: number | null;
  targetRir: number | null;
  sidesPerSet: Side[]; // ['BILATERAL'] oppure ['LEFT','RIGHT']
  configurationSnapshot: ConfigurationSnapshot | null;
  createdAt: Iso;
}

export interface SetPerformance {
  id: Id;
  sessionId: Id;
  prescriptionId: Id;
  exerciseId: Id; // denormalizzato in schema v2 (backfill nella migrazione)
  setIndex: number;
  side: Side | null;
  status: SetStatus;
  reps: number | null;
  durationS: number | null;
  rir: number | null;   // null = non rilevato, mai 0 implicito
  rpe: number | null;
  techniqueQuality: 'GOOD' | 'ACCEPTABLE' | 'POOR' | null;
  discomfort: boolean | null;
  configurationSnapshot: ConfigurationSnapshot | null;
  plausibility: 'OK' | 'CONFIRMED_BY_USER';
  performedAt: Iso;
  tzOffsetMin: number;
  /** Recupero PRIMA di questa serie, come registrato dal timer (D101). Assente nelle serie fino alla 0.4.0 o senza timer. */
  rest?: RestRecord | null;
}

/**
 * Dato del timer di recupero (D101, D111). elapsedS = recupero reale: dall'avvio del timer al tocco di «Inizio la serie»
 * (measured = TAP), anche oltre la fine del timer; se il tocco manca, stimato dall'intervallo tra le registrazioni meno
 * la durata stimata della serie (measured = ESTIMATED). addedS = secondi chiesti con «+30 s». skipped = serie iniziata
 * prima della fine. intervalS = intervallo tra le due registrazioni (dato grezzo, comprende l'esecuzione della serie).
 */
export interface RestRecord { suggestedS: number; addedS: number; elapsedS: number; skipped: boolean; intervalS?: number; measured?: 'TAP' | 'ESTIMATED' }

export interface DecisionLogEntry {
  id: Id;
  ts: Iso;
  engine: string;
  ruleVersion: string;
  input: unknown;
  decision: string;
  reason: string;
}

export interface MetaEntry { key: string; value: unknown }

// --- Progressione proposta (D078–D082) ------------------------------------------------------
export type Comparability = 'A' | 'B' | 'C' | 'D';
export type ProposalKind =
  | 'MAINTAIN'            // nessuna modifica: informazione, nessuna decisione richiesta
  | 'BLOCKED_DISCOMFORT'  // fastidio segnalato: nessuna proposta di aumento
  | 'INCREASE_DISTANCE'   // +10 cm dalla porta
  | 'NEXT_BAND'           // elastico successivo nell'ordine dell'utente, alla distanza di partenza
  | 'ADD_BAND'            // combinazione: aggiunta del tubo più morbido
  | 'NONE_AVAILABLE';     // nessuna progressione di configurazione disponibile
export type ProposalStatus = 'INFO' | 'PROPOSED' | 'ACCEPTED' | 'REJECTED';
export type RejectionReason = 'NO_SPACE' | 'JUMP_TOO_BIG' | 'NOT_READY' | 'OTHER';

export interface ProgressionEvent {
  id: Id;
  exerciseId: Id;
  sessionId: Id;                 // seduta valutata
  previousEventId: Id | null;    // proposta alternativa nata da un rifiuto
  ruleVersion: string;
  kind: ProposalKind;
  status: ProposalStatus;
  fromConfig: ConfigurationSnapshot | null;
  proposedConfig: ConfigurationSnapshot | null;
  reason: string;                // spiegazione mostrata all'utente
  evidence: unknown;             // sedute confrontate, classe di comparabilità, condizioni verificate
  createdAt: Iso;
  tzOffsetMin: number;
  decidedAt: Iso | null;
  rejectionReason: RejectionReason | null;
}

/**
 * Prova di un dominio funzionale (D105, D097 rivista): dato MISURATO. Il livello del dominio è un dato DERIVATO,
 * ricalcolato dalle prove con la versione della regola; le prove non si modificano mai.
 */
export interface DomainTrial {
  id: Id;
  runId: Id | null;              // gruppo di prove della stessa valutazione
  probeId: string | null;        // prova del piano in 3 settimane
  domainId: string;
  ladderId: string | null;
  kind: 'LADDER' | 'THRESHOLD' | 'RATIO_H';
  side: Side | null;
  level: number | null;          // gradino tentato (scale)
  passed: boolean | null;        // criterio superato (scale)
  reps: number | null;
  seconds: number | null;
  valueCm: number | null;        // soglie in cm; distanza di riferimento per gli elastici alla porta
  mobilityClass: 'CARENTE' | 'LIMITATA' | 'ADEGUATA' | null;
  rir: number | null;            // null = non indicato, mai 0
  technique: 'GOOD' | 'ACCEPTABLE' | 'POOR' | null;
  discomfort: boolean;
  bandIds: string[];             // elastici realmente usati (ID dell'attrezzatura)
  pressReps: number | null;      // solo rapporto orizzontale: ripetizioni della spinta al petto
  source: 'ASSESSMENT' | 'TRAINING';
  ruleVersion: string;
  performedAt: Iso;
  tzOffsetMin: number;
}
