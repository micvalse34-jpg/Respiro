import { Capacitor } from '@capacitor/core';

// Due modi di eseguire la stessa app: dentro l'app Android (Capacitor) o in una scheda/PWA di Chrome.
export const isNativeApp = (): boolean => Capacitor.isNativePlatform();

/**
 * Esporta un file di testo. Nell'app Android: scrive il file nella cache privata e apre il menu «Condividi»
 * del telefono (Drive, Files, email…). Nel browser: condivisione web o download.
 * Restituisce true solo se l'utente ha completato l'azione (per quanto il sistema lo consente).
 */
export async function exportTextFile(name: string, text: string, mode: 'share' | 'download' = 'share'): Promise<boolean> {
  if (isNativeApp()) {
    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    const { Share } = await import('@capacitor/share');
    const res = await Filesystem.writeFile({ path: name, data: text, directory: Directory.Cache, encoding: Encoding.UTF8 });
    await Share.share({ title: 'Backup FitPRO', files: [res.uri], dialogTitle: 'Salva il backup' });
    return true;
  }
  if (mode === 'share') {
    const file = new File([text], name, { type: 'application/json' });
    if (!navigator.canShare?.({ files: [file] })) throw new Error('Condivisione di file non supportata: usa «Scarica»');
    await navigator.share({ files: [file], title: 'Backup FitPRO' });
    return true;
  }
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  const a = document.createElement('a'); a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  return true;
}

export async function nativeDeviceInfo(): Promise<Record<string, unknown> | null> {
  if (!isNativeApp()) return null;
  const { Device } = await import('@capacitor/device');
  const i = await Device.getInfo();
  return { model: i.model, manufacturer: i.manufacturer, osVersion: i.osVersion, androidSdkVersion: i.androidSDKVersion ?? null, webViewVersion: i.webViewVersion };
}

/** Collega il tasto «indietro» di Android. Nel browser non fa nulla. Restituisce la funzione per scollegarlo. */
export async function onAndroidBack(handler: () => void): Promise<() => void> {
  if (!isNativeApp()) return () => undefined;
  const { App } = await import('@capacitor/app');
  const l = await App.addListener('backButton', handler);
  return () => { void l.remove(); };
}

/** Manda l'app in secondo piano (come il tasto Home), senza chiuderla. */
export async function minimizeApp(): Promise<void> {
  if (!isNativeApp()) return;
  const { App } = await import('@capacitor/app');
  await App.minimizeApp();
}

/** Condivide un testo breve (es. le segnalazioni sulle schede): menu «Condividi» nell'app, appunti nel browser. */
export async function shareText(title: string, text: string): Promise<'shared' | 'copied'> {
  if (isNativeApp()) {
    const { Share } = await import('@capacitor/share');
    await Share.share({ title, text, dialogTitle: title });
    return 'shared';
  }
  await navigator.clipboard.writeText(text);
  return 'copied';
}
