// Avviso di fine recupero (D101).
// - App aperta: vibrazione e un breve suono dal telefono stesso.
// - Schermo spento o app in secondo piano: notifica locale programmata all'inizio del recupero e cancellata
//   un attimo prima della fine se l'app è in primo piano (così non arrivano due avvisi).
// Nel browser: solo vibrazione web (dove disponibile) e suono.
import { isNativeApp } from './platform';

const NOTIFICATION_ID = 4101;
const CHANNEL = 'recupero';
let prepared: Promise<boolean> | null = null;

/** Chiede una volta il permesso per le notifiche e crea il canale con vibrazione. true = notifiche disponibili. */
export function prepareRestAlarm(): Promise<boolean> {
  if (!isNativeApp()) return Promise.resolve(false);
  prepared ??= (async () => {
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      let p = await LocalNotifications.checkPermissions();
      if (p.display === 'prompt' || p.display === 'prompt-with-rationale') p = await LocalNotifications.requestPermissions();
      if (p.display !== 'granted') return false;
      await LocalNotifications.createChannel({ id: CHANNEL, name: 'Fine del recupero', description: 'Avviso quando il recupero tra le serie è finito', importance: 5, vibration: true, visibility: 1 });
      return true;
    } catch { return false; }
  })();
  return prepared;
}

/** Programma (o riprogramma) l'avviso di sistema per l'istante indicato. */
export async function scheduleRestEnd(atMs: number): Promise<void> {
  if (!(await prepareRestAlarm())) return;
  try {
    const { LocalNotifications } = await import('@capacitor/local-notifications');
    await LocalNotifications.cancel({ notifications: [{ id: NOTIFICATION_ID }] });
    await LocalNotifications.schedule({
      notifications: [{
        id: NOTIFICATION_ID, title: 'Recupero finito', body: 'Puoi iniziare la prossima serie.', channelId: CHANNEL,
        schedule: { at: new Date(atMs), allowWhileIdle: true },
      }],
    });
  } catch { /* l'avviso in app resta comunque */ }
}

export async function cancelRestEnd(): Promise<void> {
  if (!isNativeApp()) return;
  try {
    const { LocalNotifications } = await import('@capacitor/local-notifications');
    await LocalNotifications.cancel({ notifications: [{ id: NOTIFICATION_ID }] });
  } catch { /* noop */ }
}

/** Avviso con l'app aperta: vibrazione + tre brevi bip. */
export async function ringInApp(): Promise<void> {
  try {
    if (isNativeApp()) {
      const { Haptics } = await import('@capacitor/haptics');
      await Haptics.vibrate({ duration: 700 });
    } else navigator.vibrate?.([300, 150, 300]);
  } catch { /* noop */ }
  try {
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    [0, 0.25, 0.5].forEach((t) => {
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.frequency.value = 880; g.gain.value = 0.15;
      o.connect(g); g.connect(ctx.destination);
      o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.15);
    });
    setTimeout(() => void ctx.close(), 1200);
  } catch { /* noop */ }
}
