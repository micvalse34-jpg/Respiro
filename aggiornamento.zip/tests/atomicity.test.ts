import { describe, expect, it } from 'vitest';
import { recordSet } from '../src/data/repository';
import { runSave, type SaveState } from '../src/app/saveState';
import { isQuotaError } from '../src/data/errors';
import { dbWithSession, setInput } from './helpers';

describe('POC-02 atomicità del salvataggio della serie', () => {
  it('errore dopo l\'inserimento della serie: nessun record parziale', async () => {
    const { db, session, prescriptions: [row] } = await dbWithSession();
    const before = (await db.sessions.get(session.id))!.updatedAt;
    db.sessions.hook('updating', () => { throw new Error('FAULT_INJECTED_ON_SESSION_UPDATE'); });
    await expect(recordSet(db, setInput(session.id, row!.id))).rejects.toThrow();
    expect(await db.sets.count()).toBe(0);
    expect((await db.sessions.get(session.id))!.updatedAt).toBe(before);
  });
});

describe('POC-12 errore di quota simulato', () => {
  it('QuotaExceededError: stato finale error, mai saved, nessun record', async () => {
    const { db, session, prescriptions: [row] } = await dbWithSession();
    db.sets.hook('creating', () => { throw new DOMException('Simulated quota', 'QuotaExceededError'); });
    const states: SaveState[] = [];
    const r = await runSave('a1', () => recordSet(db, setInput(session.id, row!.id)), (s) => states.push(s));
    expect(r).toBeNull();
    expect(states.map((s) => s.kind)).toEqual(['saving', 'error']);
    expect(await db.sets.count()).toBe(0);
    const last = states.at(-1) as Extract<SaveState, { kind: 'error' }>;
    expect(isQuotaError({ name: last.code }) || /quota/i.test(last.message)).toBe(true);
  });
});

describe('Stato «salvato» solo dopo il commit', () => {
  it('saved non viene emesso finché la promessa di commit non si risolve', async () => {
    let resolve!: () => void;
    const pending = new Promise<void>((r) => { resolve = r; });
    const states: string[] = [];
    const run = runSave('a2', () => pending, (s) => states.push(s.kind));
    await new Promise((r) => setTimeout(r, 20));
    expect(states).toEqual(['saving']);
    resolve(); await run;
    expect(states).toEqual(['saving', 'saved']);
  });

  it('commit fallito: nessun saved, errore con codice', async () => {
    const states: SaveState[] = [];
    await runSave('a3', () => Promise.reject(Object.assign(new Error('x'), { code: 'SESSION_NOT_OPEN' })), (s) => states.push(s));
    expect(states.map((s) => s.kind)).toEqual(['saving', 'error']);
  });
});
