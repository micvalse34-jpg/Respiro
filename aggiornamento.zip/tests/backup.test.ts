import { describe, expect, it } from 'vitest';
import { BACKUP_FORMAT_VERSION, backupAgeDays, contentHash, exportBackup, importBackup, needsBackupReminder, validateBackup, type BackupFile } from '../src/data/backup';
import { canonicalStringify, sha256Hex } from '../src/data/canonical';
import { closeSession, recordSet } from '../src/data/repository';
import { FitDb } from '../src/data/schema';
import { dbWithSession, freshDb, setInput } from './helpers';

async function populated() {
  const x = await dbWithSession();
  const [row, split, plank] = x.prescriptions;
  await recordSet(x.db, setInput(x.session.id, row!.id, { rir: null }));
  await recordSet(x.db, setInput(x.session.id, split!.id, { side: 'LEFT' }));
  await recordSet(x.db, setInput(x.session.id, plank!.id, { reps: null, durationS: 31 }));
  await closeSession(x.db, x.session.id, 'FINISHED_BY_USER');
  return x.db;
}
const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));
async function resign(b: BackupFile): Promise<BackupFile> { return { ...b, checksum: await sha256Hex(canonicalStringify(b.tables)) }; }

describe('POC-08 export → import su installazione pulita', () => {
  it('contenuto identico (hash canonico) e null preservati', async () => {
    const src = await populated();
    const b = await exportBackup(src, 'test');
    const text = JSON.stringify(b);
    const dst = new FitDb(`dst-${Date.now()}`); await dst.open();
    const rep = await validateBackup(text);
    expect(rep.errors).toEqual([]);
    await importBackup(dst, rep, { confirmReplace: false });
    expect(await contentHash(dst)).toBe(await contentHash(src));
    expect((await dst.sets.filter((s) => s.rir === null && s.status === 'PERFORMED').count())).toBeGreaterThan(0);
  });
});

describe('POC-09 file non validi: rifiutati, database invariato', () => {
  const cases: [string, (b: BackupFile) => Promise<string>][] = [
    ['JSON corrotto', async (b) => JSON.stringify(b).replace('{', '{{')],
    ['file troncato', async (b) => JSON.stringify(b).slice(0, 500)],
    ['contenuto alterato (checksum)', async (b) => { const c = clone(b); (c.tables.sets[0] as Record<string, unknown>).reps = 99; return JSON.stringify(c); }],
    ['schema più recente', async (b) => JSON.stringify({ ...b, schemaVersion: 99 })],
    ['formato sconosciuto', async (b) => JSON.stringify({ ...b, format: 'altro' })],
    ['versione di formato futura', async (b) => JSON.stringify({ ...b, formatVersion: BACKUP_FORMAT_VERSION + 1 })],
    ['formato 1 dichiarato su file di formato 2', async (b) => JSON.stringify({ ...b, formatVersion: 1 })],
    ['tabella mancante', async (b) => { const c = clone(b); delete (c.tables as Record<string, unknown>).sets; return JSON.stringify(await resign(c)); }],
    ['record invalido', async (b) => { const c = clone(b); (c.tables.sets[0] as Record<string, unknown>).rir = 'due'; return JSON.stringify(await resign(c)); }],
    ['ID duplicato', async (b) => { const c = clone(b); c.tables.sets.push(clone(c.tables.sets[0]!)); c.counts.sets = c.tables.sets.length; return JSON.stringify(await resign(c)); }],
    ['relazione rotta', async (b) => { const c = clone(b); (c.tables.sets[0] as Record<string, unknown>).prescriptionId = 'inesistente'; return JSON.stringify(await resign(c)); }],
    ['conteggi incoerenti', async (b) => { const c = clone(b); c.counts.sets = 999; return JSON.stringify(c); }],
  ];
  for (const [label, make] of cases) {
    it(label, async () => {
      const src = await populated();
      const target = await populated();
      const before = await contentHash(target);
      const rep = await validateBackup(await make(await exportBackup(src, 'test')));
      expect(rep.ok).toBe(false);
      expect(rep.errors.length).toBeGreaterThan(0);
      await expect(importBackup(target, rep, { confirmReplace: true })).rejects.toMatchObject({ code: 'INVALID_BACKUP' });
      expect(await contentHash(target)).toBe(before);
    });
  }
});

describe('POC-10 import su database popolato', () => {
  it('senza conferma esplicita: rifiutato, invariato', async () => {
    const src = await populated(); const target = await populated();
    const before = await contentHash(target);
    const rep = await validateBackup(JSON.stringify(await exportBackup(src, 't')));
    await expect(importBackup(target, rep, { confirmReplace: false })).rejects.toMatchObject({ code: 'NEEDS_CONFIRMATION' });
    expect(await contentHash(target)).toBe(before);
  });
  it('con conferma: sostituzione integrale', async () => {
    const src = await populated(); const target = await populated();
    const rep = await validateBackup(JSON.stringify(await exportBackup(src, 't')));
    await importBackup(target, rep, { confirmReplace: true });
    expect(await contentHash(target)).toBe(await contentHash(src));
  });
  for (const fault of ['after_clear', 'after_first_table'] as const) {
    it(`guasto durante l'import (${fault}): database invariato`, async () => {
      const src = await populated(); const target = await populated();
      const before = await contentHash(target);
      const rep = await validateBackup(JSON.stringify(await exportBackup(src, 't')));
      await expect(importBackup(target, rep, { confirmReplace: true, faultInjection: fault })).rejects.toThrow(/FAULT_INJECTED/);
      expect(await contentHash(target)).toBe(before);
    });
  }
  it('con seduta in corso: import rifiutato', async () => {
    const src = await populated();
    const { db } = await dbWithSession();
    const rep = await validateBackup(JSON.stringify(await exportBackup(src, 't')));
    await expect(importBackup(db, rep, { confirmReplace: true })).rejects.toMatchObject({ code: 'SESSION_OPEN' });
  });
  it('backup di schema v1 (serie senza exerciseId) viene portato a v2', async () => {
    const src = await populated();
    const b = clone(await exportBackup(src, 't'));
    b.schemaVersion = 1;
    for (const s of b.tables.sets) delete (s as Record<string, unknown>).exerciseId;
    const rep = await validateBackup(JSON.stringify(await resign(b)));
    expect(rep.errors).toEqual([]);
    const dst = await freshDb(); await dst.exercises.clear(); await dst.exerciseVersions.clear(); await dst.equipmentItems.clear();
    await importBackup(dst, rep, { confirmReplace: true });
    expect(await dst.sets.filter((s) => !s.exerciseId).count()).toBe(0);
  });
});

describe('D3 promemoria di backup', () => {
  const now = Date.parse('2026-11-23T12:00:00Z');
  it('nessun backup con dati presenti → promemoria', () => expect(needsBackupReminder(null, true, now)).toBe(true));
  it('nessun dato → nessun promemoria', () => expect(needsBackupReminder(null, false, now)).toBe(false));
  it('7 giorni → no; 8 giorni → sì', () => {
    expect(needsBackupReminder('2026-11-16T12:00:00Z', true, now)).toBe(false);
    expect(needsBackupReminder('2026-11-15T11:00:00Z', true, now)).toBe(true);
    expect(backupAgeDays('2026-11-15T11:00:00Z', now)).toBe(8);
  });
});

describe('Etichetta dell\'ultimo backup per giorni di calendario', () => {
  it('ieri sera → stamattina: 1 giorno («ieri»), non 0', () => {
    const sera = new Date(2026, 10, 23, 21, 56).getTime();
    const mattina = new Date(2026, 10, 24, 9, 13).getTime();
    expect(backupAgeDays(new Date(sera).toISOString(), mattina)).toBe(1);
    expect(backupAgeDays(new Date(mattina - 60_000).toISOString(), mattina)).toBe(0);
  });
});
