import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import { describe, expect, it } from 'vitest';
import { BACKUP_FORMAT_VERSION, contentHash, exportBackup, importBackup, isPopulated, validateBackup, type BackupFile } from '../src/data/backup';
import { canonicalStringify, sha256Hex } from '../src/data/canonical';
import { displayModeLabel } from '../src/data/diagnostics';
import {
  addEquipment, addStarterKit, censusStatus, currentOrderings, deleteEquipment, equipmentReferences, listEquipment,
  rankOf, saveOrdering, setEquipmentStatus, updateEquipment, type EquipmentInput,
} from '../src/data/equipmentRepo';
import { countSessions, deleteTestData, getHistoryDetail, listSessionSummaries } from '../src/data/historyRepo';
import { countProfileVersions, getCurrentProfile, saveProfile } from '../src/data/profileRepo';
import { closeSession, getOpenSessions, recordSet, SEED, startPocSession } from '../src/data/repository';
import { CURRENT_SCHEMA_VERSION, FitDb, FitDbV2, POC_PLACEHOLDER_ID } from '../src/data/schema';
import { nextFreeLabel, normalizeLabel } from '../src/domain/equipment';
import type { ProfileInput } from '../src/domain/profile';
import { freshDb, setInput } from './helpers';

const band = (label: string, over: Partial<EquipmentInput> = {}): EquipmentInput => ({
  type: 'RESISTANCE_BAND', physicalLabel: label, description: null, color: null, brandModel: null, declaredResistance: null,
  restLengthCm: null, integrity: null, quantity: 1, notes: null, ...over,
});
const profile = (over: Partial<ProfileInput> = {}): ProfileInput => ({
  birthYear: 1988, heightCm: 178, weightKg: null, experience: 'FROM_6_TO_24_MONTHS', usualActivities: 'Yoga', notes: null, ...over,
});
const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));
async function resign(b: BackupFile): Promise<BackupFile> { return { ...b, checksum: await sha256Hex(canonicalStringify(b.tables)) }; }

/** DB completo F1: profilo con 2 versioni, kit, ordinamento, una seduta di prova chiusa con snapshot elastico. */
async function f1Db() {
  const db = await freshDb();
  await saveProfile(db, profile());
  await saveProfile(db, profile({ weightKg: 74.5 }));
  await addStarterKit(db);
  const tubes = (await listEquipment(db)).filter((i) => i.type === 'RESISTANCE_BAND');
  await updateEquipment(db, tubes[0]!.id, { color: 'giallo' });
  await saveOrdering(db, 'RESISTANCE_BAND', [...tubes].reverse().map((t) => t.id));
  const s = await startPocSession(db, [tubes[0]!.id]);
  const [row] = await db.prescriptions.where('sessionId').equals(s.id).sortBy('order');
  await recordSet(db, setInput(s.id, row!.id, { rir: null }));
  await closeSession(db, s.id, 'FINISHED_BY_USER');
  return { db, tubes, session: s };
}

describe('DEF-03 etichetta della modalità di visualizzazione', () => {
  it('nell\'app Android non risulta più «browser (scheda)»', () => {
    expect(displayModeLabel(true, false)).toBe('app Android (Capacitor)');
    expect(displayModeLabel(false, true)).toBe('standalone (PWA installata)');
    expect(displayModeLabel(false, false)).toBe('browser (scheda)');
  });
});

describe('DM07 migrazione v2→v3 con seduta IN_PROGRESS e attrezzatura del POC', () => {
  it('nessuna osservazione toccata, segnaposto dismesso, seduta riprendibile', async () => {
    const name = `mig3-${Date.now()}`;
    const v2 = new FitDbV2(name); await v2.open();
    const t = new Date().toISOString();
    await v2.table('exercises').add({ id: SEED.bandRow.exerciseId, canonicalName: 'Band Row', createdAt: t });
    await v2.table('exerciseVersions').add({ id: SEED.bandRow.versionId, exerciseId: SEED.bandRow.exerciseId, version: 1, unilateral: false, measure: 'REPS', breathing: 'x', createdAt: t });
    await v2.table('equipmentItems').add({ id: POC_PLACEHOLDER_ID, type: 'RESISTANCE_BAND', label: 'Banda 1 (etichetta da censire)', color: null, declaredResistance: null, createdAt: t });
    await v2.table('equipmentItems').add({ id: 'eq-x', type: 'LOOP_BAND', label: 'Loop rosso', color: 'rosso', declaredResistance: 'Heavy', createdAt: t });
    await v2.table('sessions').add({ id: 's1', sessionType: 'POC', status: 'IN_PROGRESS', startedAt: t, tzOffsetMin: -60, endedAt: null, updatedAt: t, closeReason: null });
    await v2.table('prescriptions').add({ id: 'p1', sessionId: 's1', exerciseId: SEED.bandRow.exerciseId, exerciseVersionId: SEED.bandRow.versionId, order: 1, origin: 'ENGINE', prescribedSets: 3, repMin: 8, repMax: 15, targetDurationS: null, targetRir: 2, sidesPerSet: ['BILATERAL'], configurationSnapshot: { configurationId: null, bandIds: [POC_PLACEHOLDER_ID], anchor: 'door', anchorHeightCm: 100, distanceCm: 120, notes: null }, createdAt: t });
    const set = { id: 'set1', sessionId: 's1', prescriptionId: 'p1', exerciseId: SEED.bandRow.exerciseId, setIndex: 1, side: 'BILATERAL', status: 'PERFORMED', reps: 11, durationS: null, rir: null, rpe: null, techniqueQuality: 'GOOD', discomfort: null, configurationSnapshot: null, plausibility: 'OK', performedAt: t, tzOffsetMin: -60 };
    await v2.table('sets').add(set);
    v2.close();

    const db = new FitDb(name); await db.open();
    expect(db.verno).toBe(CURRENT_SCHEMA_VERSION);
    expect(await db.sets.get('set1')).toEqual(set);
    expect(await getOpenSessions(db)).toHaveLength(1);
    const ph = (await db.equipmentItems.get(POC_PLACEHOLDER_ID))!;
    expect(ph.status).toBe('RETIRED'); expect(ph.physicalLabel).toBeNull();
    const loop = (await db.equipmentItems.get('eq-x'))!;
    expect(loop).toMatchObject({ status: 'ACTIVE', description: 'Loop rosso', color: 'rosso', declaredResistance: 'Heavy', physicalLabel: null, integrity: null, restLengthCm: null });
    expect(await db.decisionLog.filter((l) => l.decision === 'SCHEMA_MIGRATED_TO_3').count()).toBe(1);
    await recordSet(db, setInput('s1', 'p1', { setIndex: 2 }));
    expect(await db.sets.count()).toBe(2);
  });
});

describe('DM12 profilo: versioni non distruttive, NULL preservati', () => {
  it('ogni modifica crea una versione, nessuna modifica non scrive, le precedenti restano', async () => {
    const db = await freshDb();
    expect(await getCurrentProfile(db)).toBeNull();
    const a = await saveProfile(db, profile());
    expect(a.outcome).toBe('saved'); expect(a.profile.weightKg).toBeNull();
    expect((await saveProfile(db, profile())).outcome).toBe('unchanged');
    const b = await saveProfile(db, profile({ heightCm: 179 }));
    expect(await countProfileVersions(db)).toBe(2);
    expect((await getCurrentProfile(db))!.id).toBe(b.profile.id);
    expect(await db.profileVersions.get(a.profile.id)).toEqual(a.profile);
  });
  it('valori fuori intervallo rifiutati senza scrivere', async () => {
    const db = await freshDb();
    await expect(saveProfile(db, profile({ heightCm: 17.8 }))).rejects.toMatchObject({ code: 'INVALID_PROFILE' });
    await expect(saveProfile(db, profile({ birthYear: Number.NaN }))).rejects.toMatchObject({ code: 'INVALID_PROFILE' });
    expect(await countProfileVersions(db)).toBe(0);
  });
});

describe('DM13 attrezzatura: etichette (D068) e integrità dello storico', () => {
  it('etichette normalizzate e prima etichetta libera', () => {
    expect(normalizeLabel(' e 3 ')).toBe('E3'); expect(normalizeLabel('7')).toBe('E7');
    expect(normalizeLabel('E0')).toBeNull(); expect(normalizeLabel('giallo')).toBeNull();
    expect(nextFreeLabel([{ physicalLabel: 'E1' }, { physicalLabel: 'E3' }, { physicalLabel: null }])).toBe('E2');
  });
  it('etichetta obbligatoria e unica, anche rispetto agli elastici dismessi', async () => {
    const db = await freshDb();
    await expect(addEquipment(db, band(''))).rejects.toMatchObject({ code: 'INVALID_LABEL' });
    const e1 = await addEquipment(db, band('e1', { color: 'giallo' }));
    expect(e1.physicalLabel).toBe('E1'); expect(e1.declaredResistance).toBeNull();
    await setEquipmentStatus(db, e1.id, 'RETIRED');
    await expect(addEquipment(db, band('E1'))).rejects.toMatchObject({ code: 'LABEL_IN_USE' });
  });
  it('tipo ed etichetta non modificabili; testo del produttore conservato così com\'è', async () => {
    const db = await freshDb();
    const e = await addEquipment(db, band('E2'));
    const u = await updateEquipment(db, e.id, { declaredResistance: '15-20 lb', color: 'rosso', physicalLabel: 'E9', type: 'LOOP_BAND' } as never);
    expect(u).toMatchObject({ physicalLabel: 'E2', type: 'RESISTANCE_BAND', declaredResistance: '15-20 lb', color: 'rosso' });
  });
  it('kit Odoland: E1–E5 tubi, E6–E10 anelli, E11 a 8, dati del produttore come testo, nessun kg calcolato dall\'app', async () => {
    const db = await freshDb();
    expect(await addStarterKit(db)).toBe(22);
    const items = await listEquipment(db);
    const el = items.filter((i) => i.physicalLabel);
    expect(el.map((i) => i.physicalLabel)).toEqual(Array.from({ length: 11 }, (_, i) => `E${i + 1}`));
    expect(el.slice(0, 5).map((i) => i.color)).toEqual(['giallo', 'rosso', 'blu', 'verde', 'nero']);
    expect(el.slice(5, 10).map((i) => i.color)).toEqual(['verde', 'blu', 'giallo', 'rosso', 'nero']);
    expect(el[0]!.declaredResistance).toBe('4,6 kg nominali (10 lb)');
    expect(el[5]!.restLengthCm).toBe(60);
    expect(el[10]).toMatchObject({ type: 'FIGURE8_BAND', color: 'nero', declaredResistance: null });
    expect(items.filter((i) => i.type === 'MASSAGE_BALL').map((i) => i.description).sort()).toEqual(['a doppia sfera (peanut) 12 cm', 'a doppia sfera (peanut) 8 cm', 'a riccio 9 cm']);
    expect(items.find((i) => i.type === 'YOGA_BLOCK')!.quantity).toBe(2);
    expect(items.find((i) => i.type === 'FITBALL')!.description).toBe('diametro 65 cm');
    expect(items.every((i) => i.integrity === null)).toBe(true);
    expect(await db.bandOrderings.count()).toBe(0); // l'ordine lo conferma l'utente (D068)
    expect(items.find((i) => i.type === 'HANDLE')!.quantity).toBe(2);
    await expect(addStarterKit(db)).rejects.toMatchObject({ code: 'KIT_EXISTS' });
  });
  it('un oggetto usato in una seduta non si elimina; uno mai usato sì', async () => {
    const { db, tubes } = await f1Db();
    expect((await equipmentReferences(db, tubes[0]!.id)).prescriptions).toBe(1);
    await expect(deleteEquipment(db, tubes[0]!.id)).rejects.toMatchObject({ code: 'IN_USE' });
    const extra = await addEquipment(db, band('E20'));
    await deleteEquipment(db, extra.id);
    expect(await db.equipmentItems.get(extra.id)).toBeUndefined();
  });
});

describe('DM14 ordinamento degli elastici (D068)', () => {
  it('completo, senza ripetizioni, solo elastici attivi dello stesso tipo', async () => {
    const db = await freshDb();
    await addStarterKit(db);
    const tubes = (await listEquipment(db)).filter((i) => i.type === 'RESISTANCE_BAND');
    const loops = (await listEquipment(db)).filter((i) => i.type === 'LOOP_BAND');
    await expect(saveOrdering(db, 'RESISTANCE_BAND', tubes.slice(0, 4).map((t) => t.id))).rejects.toMatchObject({ code: 'INVALID_ORDERING' });
    await expect(saveOrdering(db, 'RESISTANCE_BAND', [...tubes.slice(0, 4), loops[0]!].map((t) => t.id))).rejects.toMatchObject({ code: 'INVALID_ORDERING' });
    await expect(saveOrdering(db, 'RESISTANCE_BAND', [...tubes.slice(0, 4), tubes[0]!].map((t) => t.id))).rejects.toMatchObject({ code: 'INVALID_ORDERING' });
    expect(await db.bandOrderings.count()).toBe(0);
  });
  it('versionato: il nuovo ordine non cancella il precedente; un elastico aggiunto rende l\'ordine da aggiornare', async () => {
    const db = await freshDb();
    await addStarterKit(db);
    const tubes = (await listEquipment(db)).filter((i) => i.type === 'RESISTANCE_BAND');
    const first = await saveOrdering(db, 'RESISTANCE_BAND', tubes.map((t) => t.id));
    await new Promise((r) => setTimeout(r, 5));
    await saveOrdering(db, 'RESISTANCE_BAND', [...tubes].reverse().map((t) => t.id));
    expect(await db.bandOrderings.get(first.id)).toEqual(first);
    const cur = (await currentOrderings(db)).RESISTANCE_BAND;
    expect(rankOf(tubes[4]!.id, cur, tubes)).toBe(1);
    expect((await censusStatus(db)).typesToOrder).toEqual(['LOOP_BAND']);
    await addEquipment(db, band('E12'));
    const now = (await listEquipment(db)).filter((i) => i.type === 'RESISTANCE_BAND');
    expect(rankOf(tubes[4]!.id, cur, now)).toBeNull();
    expect((await censusStatus(db)).typesToOrder).toContain('RESISTANCE_BAND');
  });
});

describe('Storico (pagina)', () => {
  it('elenco con conteggi e durata, sedute di prova filtrabili, dettaglio con etichette degli elastici', async () => {
    const { db, tubes, session } = await f1Db();
    expect(await listSessionSummaries(db, { includeTest: false })).toHaveLength(0);
    const [s] = await listSessionSummaries(db, { includeTest: true });
    expect(s).toMatchObject({ performed: 1, interrupted: 0, notPerformed: 8, exercises: 3 });
    expect(s!.durationMin).not.toBeNull();
    const d = (await getHistoryDetail(db, session.id))!;
    expect(d.blocks.map((b) => b.name)).toEqual(['Rematore con elastico', 'Split squat (affondo da fermo)', 'Plank sugli avambracci']); // 0.4.0: nomi italiani della libreria
    expect(d.equipment.get(tubes[0]!.id)!.physicalLabel).toBe('E1');
    expect(d.blocks[0]!.sets.find((x) => x.status === 'PERFORMED')!.rir).toBeNull();
  });
});

describe('DM15 eliminazione dei dati di prova', () => {
  it('tocca solo le sedute di prova; profilo, attrezzatura, ordinamenti ed esercizi restano', async () => {
    const { db } = await f1Db();
    const keep = async () => ({ p: await db.profileVersions.toArray(), e: await db.equipmentItems.toArray(), o: await db.bandOrderings.toArray(), x: await db.exercises.toArray() });
    const before = await keep();
    const r = await deleteTestData(db);
    expect(r.sessions).toBe(1); expect(r.sets).toBe(9);
    expect(await countSessions(db)).toEqual({ real: 0, test: 0 });
    expect(await db.prescriptions.count()).toBe(0);
    expect(await keep()).toEqual(before);
    expect(await db.decisionLog.filter((l) => l.decision === 'TEST_DATA_DELETED').count()).toBe(1);
  });
  it('rifiutata con una seduta di prova aperta, nulla cancellato', async () => {
    const db = await freshDb();
    await startPocSession(db);
    await expect(deleteTestData(db)).rejects.toMatchObject({ code: 'SESSION_OPEN' });
    expect(await db.sessions.count()).toBe(1);
  });
});

describe('DM08–DM11 backup formato 2', () => {
  it('DM08 export → import: contenuto identico con profilo, attrezzatura e ordinamenti', async () => {
    const { db } = await f1Db();
    const b = await exportBackup(db, 'test');
    expect(b.formatVersion).toBe(BACKUP_FORMAT_VERSION);
    expect(b.counts).toMatchObject({ profileVersions: 2, bandOrderings: 1, equipmentItems: 22 });
    const dst = new FitDb(`dst-${Date.now()}`); await dst.open();
    const rep = await validateBackup(JSON.stringify(b));
    expect(rep.errors).toEqual([]);
    await importBackup(dst, rep, { confirmReplace: false });
    expect(await contentHash(dst)).toBe(await contentHash(db));
  });

  it('DM10 su un database con sola attrezzatura serve la conferma (dati dell\'utente da proteggere)', async () => {
    const db = await freshDb();
    await addStarterKit(db);
    expect(await isPopulated(db)).toBe(true);
    const src = await f1Db();
    const rep = await validateBackup(JSON.stringify(await exportBackup(src.db, 't')));
    await expect(importBackup(db, rep, { confirmReplace: false })).rejects.toMatchObject({ code: 'NEEDS_CONFIRMATION' });
  });

  const bad: [string, (b: BackupFile) => void][] = [
    ['etichetta duplicata', (b) => { const el = b.tables.equipmentItems.filter((x) => x.physicalLabel) as Record<string, unknown>[]; el[1]!.physicalLabel = el[0]!.physicalLabel; }],
    ['ordinamento con elastico inesistente', (b) => { (b.tables.bandOrderings[0] as { orderedIds: string[] }).orderedIds[0] = 'nessuno'; }],
    ['snapshot con elastico inesistente', (b) => { const p = b.tables.prescriptions.find((x) => x.configurationSnapshot) as { configurationSnapshot: { bandIds: string[] } }; p.configurationSnapshot.bandIds = ['nessuno']; }],
    ['profilo con campo sconosciuto', (b) => { (b.tables.profileVersions[0] as Record<string, unknown>).diagnosi = 'x'; }],
    ['elastico in uso senza etichetta', (b) => { const e = b.tables.equipmentItems.find((x) => x.type === 'LOOP_BAND') as Record<string, unknown>; e.physicalLabel = null; }],
  ];
  for (const [label, mutate] of bad) {
    it(`DM09 rifiutato, database invariato: ${label}`, async () => {
      const { db } = await f1Db();
      const before = await contentHash(db);
      const c = clone(await exportBackup(db, 't')); mutate(c);
      const rep = await validateBackup(JSON.stringify(await resign(c)));
      expect(rep.ok).toBe(false);
      await expect(importBackup(db, rep, { confirmReplace: true })).rejects.toMatchObject({ code: 'INVALID_BACKUP' });
      expect(await contentHash(db)).toBe(before);
    });
  }

  it('DM11 un backup del POC (formato 1, schema 2) si importa nello schema 3', async () => {
    const t = '2026-11-23T15:29:00.000Z';
    const tables = {
      equipmentItems: [{ id: POC_PLACEHOLDER_ID, type: 'RESISTANCE_BAND', label: 'Banda 1 (etichetta da censire)', color: null, declaredResistance: null, createdAt: t }],
      exercises: [{ id: SEED.bandRow.exerciseId, canonicalName: 'Band Row', createdAt: t }],
      exerciseVersions: [{ id: SEED.bandRow.versionId, exerciseId: SEED.bandRow.exerciseId, version: 1, unilateral: false, measure: 'REPS', breathing: 'x', createdAt: t }],
      sessions: [{ id: 's', sessionType: 'POC', status: 'COMPLETED', startedAt: t, tzOffsetMin: -60, endedAt: t, updatedAt: t, closeReason: 'FINISHED_BY_USER' }],
      prescriptions: [{ id: 'p', sessionId: 's', exerciseId: SEED.bandRow.exerciseId, exerciseVersionId: SEED.bandRow.versionId, order: 1, origin: 'ENGINE', prescribedSets: 1, repMin: 8, repMax: 15, targetDurationS: null, targetRir: 2, sidesPerSet: ['BILATERAL'], configurationSnapshot: { configurationId: null, bandIds: [POC_PLACEHOLDER_ID], anchor: 'door', anchorHeightCm: 100, distanceCm: 120, notes: null }, createdAt: t }],
      sets: [{ id: 'x', sessionId: 's', prescriptionId: 'p', exerciseId: SEED.bandRow.exerciseId, setIndex: 1, side: 'BILATERAL', status: 'PERFORMED', reps: 10, durationS: null, rir: 2, rpe: null, techniqueQuality: 'GOOD', discomfort: null, configurationSnapshot: null, plausibility: 'OK', performedAt: t, tzOffsetMin: -60 }],
      decisionLog: [],
    };
    const file = { format: 'fitpro-backup', formatVersion: 1, schemaVersion: 2, appVersion: '0.1.0', exportedAt: t, installId: 'i', counts: Object.fromEntries(Object.entries(tables).map(([k, v]) => [k, v.length])), checksum: await sha256Hex(canonicalStringify(tables)), tables };
    const rep = await validateBackup(JSON.stringify(file));
    expect(rep.errors).toEqual([]);
    const db = new FitDb(`f1import-${Date.now()}`); await db.open();
    await importBackup(db, rep, { confirmReplace: false });
    expect((await db.equipmentItems.get(POC_PLACEHOLDER_ID))!.status).toBe('RETIRED');
    expect(await db.profileVersions.count()).toBe(0);
    expect((await db.sets.get('x'))!.reps).toBe(10);
    db.close(); await Dexie.delete(db.name);
  });
});
