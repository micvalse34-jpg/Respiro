// Test della fase F2, versione 0.4.0: libreria (D092, D093, D095), seduta libera con tutta la libreria (D098), backup formato 4.
import { createHash } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { BACKUP_FORMAT_VERSION, contentHash, exportBackup, importBackup, validateBackup, type BackupFile } from '../src/data/backup';
import { canonicalStringify, sha256Hex } from '../src/data/canonical';
import { addEquipment, addStarterKit, listEquipment, saveOrdering } from '../src/data/equipmentRepo';
import { addFreeExercise, checkSetup, initialConfig, snapshotOf, startFreeSession, trainableVersion } from '../src/data/freeSessionRepo';
import { getHistoryDetail } from '../src/data/historyRepo';
import { currentVersion, KNOWLEDGE_EXERCISES, KNOWLEDGE_VERSIONS } from '../src/data/knowledge';
import { CATALOG } from '../src/data/libraryCatalog';
import { SOURCES, WAVE1 } from '../src/data/libraryContent';
import { availableTypes, libraryItems, setTested, statusOf } from '../src/data/libraryRepo';
import { closeSession, recordSet, seedKnowledge } from '../src/data/repository';
import { FitDb } from '../src/data/schema';
import { bandRowExposures, evaluateBandRowSession, setupDefaults } from '../src/data/sliceRepo';
import { uuidv7 } from '../src/domain/ids';
import { metaErrors, missingEquipment } from '../src/domain/library';
import { freshDb } from './helpers';

const LEGACY_IDS = ['ex-021-v1', 'ex-003-v1', 'ex-035-v1', 'ex-021-v2'];
/** Impronta delle versioni pubblicate fino alla 0.3.3, calcolata sul file della 0.3.3: non devono cambiare mai (D032). */
const LEGACY_HASH = '62dd15b3a898ccd22050f3561b885d2febb7c4fa22499a6df6f196c0cf72c5b7';

const set = (sessionId: string, prescriptionId: string, over: Record<string, unknown> = {}) => ({
  id: uuidv7(), sessionId, prescriptionId, setIndex: 1, side: 'BILATERAL' as const, status: 'PERFORMED' as const, reps: 10, durationS: null,
  rir: 2, rpe: null, techniqueQuality: null, discomfort: false, ...over,
});

async function kitDb() {
  const db = await freshDb();
  await addStarterKit(db);
  const all = await listEquipment(db);
  const tubes = all.filter((i) => i.type === 'RESISTANCE_BAND');
  const loops = all.filter((i) => i.type === 'LOOP_BAND');
  await saveOrdering(db, 'RESISTANCE_BAND', tubes.map((t) => t.id));
  await saveOrdering(db, 'LOOP_BAND', loops.map((t) => t.id));
  return { db, tubes, loops };
}

describe('F2-LIB catalogo e schede', () => {
  it('53 esercizi (52 + EX056 della 0.4.2), identificativi unici, classificazione coerente, varianti non duplicate', () => {
    expect(CATALOG).toHaveLength(53);
    expect(new Set(CATALOG.map((c) => c.id)).size).toBe(53);
    expect(currentVersion('ex-056')!.id).toBe('ex-056-v1'); // nessuna versione «0.4.0» inventata a posteriori
    for (const c of CATALOG) expect([c.id, metaErrors(c.meta)]).toEqual([c.id, []]);
    for (const id of ['ex-011', 'ex-022', 'ex-038']) expect(CATALOG.some((c) => c.id === id)).toBe(false); // diventati varianti (D093)
    for (const id of ['ex-051', 'ex-052', 'ex-053', 'ex-054', 'ex-055']) expect(CATALOG.some((c) => c.id === id)).toBe(true);
  });
  it('ondata 1: 18 schede complete secondo 26 e 10 (2–3 indicazioni, respirazione, errori, sicurezza, fonti esistenti)', () => {
    const ids = Object.keys(WAVE1);
    expect(ids).toHaveLength(18);
    for (const id of ids) {
      const entry = CATALOG.find((c) => c.id === id)!;
      const { content: c, breathing } = WAVE1[id]!;
      expect(entry, id).toBeDefined();
      expect(c.displayName).toBe(entry.displayName);
      expect(c.cues.length, id).toBeGreaterThanOrEqual(2); expect(c.cues.length, id).toBeLessThanOrEqual(3);
      expect(c.setup.length, id).toBeGreaterThanOrEqual(1);
      expect(c.commonErrors.length, id).toBeGreaterThanOrEqual(2);
      expect((c.stopIf ?? []).length, id).toBeGreaterThanOrEqual(1);
      expect(c.purpose, id).toBeTruthy();
      expect(breathing.length, id).toBeGreaterThan(10);
      expect(breathing.toLowerCase(), id).not.toMatch(/non trattenere|mai |valsalva/); // 10, 17 §11
      for (const s of c.sources ?? []) expect(SOURCES[s], `${id}: fonte ${s}`).toBeDefined();
      expect(c.sources!.length, id).toBeGreaterThanOrEqual(1);
      if (entry.meta.setup === 'TUBE_DOOR') expect(c.defaultAnchor, id).toBe(entry.meta.anchor);
    }
  });
  it('versioni della 0.3.3 invariate; il rematore ha una versione 3 con la respirazione corretta', () => {
    const legacy = LEGACY_IDS.map((id) => KNOWLEDGE_VERSIONS.find((v) => v.id === id));
    const legacyOrdered = KNOWLEDGE_VERSIONS.filter((v) => LEGACY_IDS.includes(v.id));
    expect(legacy.every(Boolean)).toBe(true);
    const hash = createHash('sha256').update(JSON.stringify(legacyOrdered) + JSON.stringify(KNOWLEDGE_EXERCISES.slice(0, 3))).digest('hex');
    expect(hash).toBe(LEGACY_HASH);
    const br = currentVersion('ex-021')!;
    expect(br.id).toBe('ex-021-v3');
    expect(br.breathing).not.toMatch(/trattenere/);
    expect(currentVersion('ex-012')!.content).toBeNull(); // scheda in arrivo (terza ondata)
  });
  it('caricamento delle schede idempotente: le versioni già presenti non vengono riscritte', async () => {
    const db = await freshDb();
    const n = await db.exerciseVersions.count();
    expect(n).toBe(KNOWLEDGE_VERSIONS.length);
    await db.exerciseVersions.update('ex-021-v3', { breathing: 'modificata a mano' });
    await seedKnowledge(db);
    expect(await db.exerciseVersions.count()).toBe(n);
    expect((await db.exerciseVersions.get('ex-021-v3'))!.breathing).toBe('modificata a mano');
  });
});

describe('F2-EQ attrezzatura e disponibilità', () => {
  it('esercizi a terra disponibili solo con il tappetino; danneggiati esclusi', async () => {
    const { db } = await kitDb();
    const plank = CATALOG.find((c) => c.id === 'ex-035')!;
    expect(missingEquipment(plank.meta, await availableTypes(db))).toEqual(['YOGA_MAT']);
    await addEquipment(db, { type: 'YOGA_MAT', physicalLabel: null, description: null, color: null, brandModel: null, declaredResistance: null, restLengthCm: null, integrity: null, quantity: 1, notes: null });
    expect(missingEquipment(plank.meta, await availableTypes(db))).toEqual([]);
    const items = await libraryItems(db);
    expect(items.filter((i) => i.status !== 'IN_PREPARATION')).toHaveLength(36); // 18 della 0.4.0 + EX056 + 17 della 0.4.3
    expect(items.find((i) => i.entry.id === 'ex-053')!.missing).toEqual([]); // fitball + tappetino
  });
});

describe('F2-TESTED segno «provata» (D092)', () => {
  it('provata, tolta, e di nuovo bozza su una versione diversa del testo', async () => {
    const db = await freshDb();
    await setTested(db, 'ex-001', true);
    expect((await libraryItems(db)).find((i) => i.entry.id === 'ex-001')!.status).toBe('TESTED');
    await setTested(db, 'ex-001', false);
    expect((await libraryItems(db)).find((i) => i.entry.id === 'ex-001')!.status).toBe('DRAFT');
    expect(statusOf(currentVersion('ex-001')!, { versionId: 'ex-001-v0', decision: 'EXERCISE_TESTED' })).toBe('DRAFT');
    await expect(setTested(db, 'ex-012', true)).rejects.toMatchObject({ code: 'CONTENT_NOT_READY' });
    expect(await db.decisionLog.filter((l) => l.decision.startsWith('EXERCISE_TEST')).count()).toBe(2); // solo aggiunte
  });
});

describe('F2-FREE seduta libera con più esercizi (D098)', () => {
  it('corpo libero, unilaterale e a tempo nella stessa seduta: lati, durata e serie mancanti corretti', async () => {
    const db = await freshDb();
    const s = await startFreeSession(db, { exerciseId: 'ex-001', config: null });
    const split = await addFreeExercise(db, s.id, { exerciseId: 'ex-003', config: null });
    const plank = await addFreeExercise(db, s.id, { exerciseId: 'ex-035', config: null });
    const [squat] = await db.prescriptions.where('sessionId').equals(s.id).sortBy('order');
    expect(squat).toMatchObject({ prescribedSets: 3, repMin: 8, repMax: 15, targetRir: 2, sidesPerSet: ['BILATERAL'], origin: 'USER_ADDED', exerciseVersionId: 'ex-001-v1' });
    expect(split).toMatchObject({ sidesPerSet: ['LEFT', 'RIGHT'], repMin: 6, repMax: 12, order: 2 });
    expect(plank).toMatchObject({ targetDurationS: 40, repMin: null, targetRir: null, order: 3 });
    await recordSet(db, set(s.id, squat!.id));
    await recordSet(db, set(s.id, split.id, { side: 'LEFT' }));
    await recordSet(db, set(s.id, split.id, { side: 'RIGHT' }));
    await recordSet(db, set(s.id, plank.id, { reps: null, durationS: 32, rir: null }));
    expect(await closeSession(db, s.id, 'FINISHED_BY_USER')).toBe('PARTIALLY_COMPLETED');
    const np = await db.sets.where('sessionId').equals(s.id).filter((x) => x.status === 'NOT_PERFORMED').toArray();
    expect(np.length).toBe(2 + 4 + 2); // squat 2, split 2 serie × 2 lati, plank 2
    const h = (await getHistoryDetail(db, s.id))!;
    expect(h.blocks.map((b) => b.name)).toEqual(['Squat a corpo libero', 'Split squat (affondo da fermo)', 'Plank sugli avambracci']);
    expect((await evaluateBandRowSession(db, s.id)).event).toBeNull(); // nessun rematore: nessuna valutazione
  });
  it('regole di impostazione: scheda in arrivo, esercizio doppio, elastici non adatti, controllo di sicurezza', async () => {
    const { db, tubes, loops } = await kitDb();
    await expect(startFreeSession(db, { exerciseId: 'ex-012', config: snapshotOf([tubes[0]!.id], 'DOOR_LOW', 80) })).rejects.toMatchObject({ code: 'CONTENT_NOT_READY' });
    await expect(startFreeSession(db, { exerciseId: 'ex-001', config: snapshotOf([tubes[0]!.id], null, null) })).rejects.toMatchObject({ code: 'UNEXPECTED_CONFIG' });
    await expect(startFreeSession(db, { exerciseId: 'ex-019', config: snapshotOf([tubes[0]!.id], 'DOOR_MID', 80) })).rejects.toMatchObject({ code: 'UNEXPECTED_CONFIG' });
    await expect(startFreeSession(db, { exerciseId: 'ex-019', config: snapshotOf([loops[0]!.id], null, null) })).rejects.toMatchObject({ code: 'INVALID_BAND' });
    await expect(startFreeSession(db, { exerciseId: 'ex-019', config: snapshotOf([tubes[0]!.id], null, null) })).rejects.toMatchObject({ code: 'SAFETY_CHECK_REQUIRED' });
    await expect(checkSetup(db, { setup: 'LOOP' }, snapshotOf([tubes[0]!.id], null, null))).rejects.toMatchObject({ code: 'INVALID_BAND' });
    await checkSetup(db, { setup: 'LOOP' }, snapshotOf([loops[0]!.id], null, null));
    const s = await startFreeSession(db, { exerciseId: 'ex-019', config: snapshotOf([tubes[0]!.id], null, null) }, true);
    await expect(addFreeExercise(db, s.id, { exerciseId: 'ex-019', config: snapshotOf([tubes[0]!.id], null, null) })).rejects.toMatchObject({ code: 'ALREADY_IN_SESSION' });
    await expect(startFreeSession(db, { exerciseId: 'ex-001', config: null })).rejects.toMatchObject({ code: 'SESSION_OPEN' });
    expect(await db.decisionLog.filter((l) => l.decision === 'SAFETY_CHECK_CONFIRMED').count()).toBe(1);
    expect(() => trainableVersion('ex-999')).toThrow();
  });
  it('rematore in una seduta con altri esercizi: esposizione valutata come nella slice', async () => {
    const { db, tubes } = await kitDb();
    const cfg = snapshotOf([tubes[1]!.id], 'DOOR_MID', 80);
    const s = await startFreeSession(db, { exerciseId: 'ex-001', config: null });
    const row = await addFreeExercise(db, s.id, { exerciseId: 'ex-021', config: cfg }, true);
    expect(row).toMatchObject({ origin: 'ENGINE', prescribedSets: 3, repMin: 8, repMax: 15, targetRir: 2, exerciseVersionId: 'ex-021-v3' });
    for (let i = 1; i <= 3; i++) await recordSet(db, set(s.id, row.id, { setIndex: i, reps: 12, configurationSnapshot: cfg }));
    await closeSession(db, s.id, 'FINISHED_BY_USER');
    expect((await bandRowExposures(db)).map((e) => e.sessionId)).toEqual([s.id]);
    expect((await evaluateBandRowSession(db, s.id)).event!.kind).toBe('MAINTAIN');
  });
  it('configurazione proposta: rematore come nella slice, altri esercizi ultima usata o elastico più morbido', async () => {
    const { db, tubes } = await kitDb();
    expect(await initialConfig(db, 'ex-021')).toEqual((await setupDefaults(db)).config);
    expect(await initialConfig(db, 'ex-019')).toEqual(snapshotOf([tubes[0]!.id], null, null));
    expect(await initialConfig(db, 'ex-018')).toEqual(snapshotOf([tubes[0]!.id], 'DOOR_MID', null));
    expect(await initialConfig(db, 'ex-001')).toBeNull();
    const s = await startFreeSession(db, { exerciseId: 'ex-019', config: snapshotOf([tubes[2]!.id], null, null) }, true);
    const [p] = await db.prescriptions.where('sessionId').equals(s.id).toArray();
    await recordSet(db, set(s.id, p!.id, { configurationSnapshot: snapshotOf([tubes[2]!.id], null, null) }));
    await closeSession(db, s.id, 'FINISHED_BY_USER');
    expect(await initialConfig(db, 'ex-019')).toEqual(snapshotOf([tubes[2]!.id], null, null));
  });
});

describe('F2-BK backup formato corrente', () => {
  const resign = async (b: BackupFile): Promise<BackupFile> => ({ ...b, checksum: await sha256Hex(canonicalStringify(b.tables)) });
  it('export → import identico con classificazione, tappetino e segni «provata»', async () => {
    const { db } = await kitDb();
    await addEquipment(db, { type: 'YOGA_MAT', physicalLabel: null, description: null, color: null, brandModel: null, declaredResistance: null, restLengthCm: null, integrity: null, quantity: 1, notes: null });
    await setTested(db, 'ex-001', true);
    const s = await startFreeSession(db, { exerciseId: 'ex-035', config: null });
    const [p] = await db.prescriptions.where('sessionId').equals(s.id).toArray();
    await recordSet(db, set(s.id, p!.id, { reps: null, durationS: 30, rir: null }));
    await closeSession(db, s.id, 'FINISHED_BY_USER');
    const b = await exportBackup(db, 't');
    expect(b.formatVersion).toBe(BACKUP_FORMAT_VERSION);
    const dst = new FitDb(`f2bk-${Date.now()}`); await dst.open();
    const rep = await validateBackup(JSON.stringify(b));
    expect(rep.errors).toEqual([]);
    await importBackup(dst, rep, { confirmReplace: false });
    expect(await contentHash(dst)).toBe(await contentHash(db));
    expect((await libraryItems(dst)).find((i) => i.entry.id === 'ex-001')!.status).toBe('TESTED');
  });
  it('backup della 0.3.3 (formato 3, solo le schede vecchie): importato e completato con le schede nuove', async () => {
    const db = await freshDb();
    const b = await exportBackup(db, '0.3.3');
    const old = JSON.parse(JSON.stringify(b)) as BackupFile;
    old.formatVersion = 3; old.schemaVersion = 4;
    old.tables.exerciseVersions = old.tables.exerciseVersions.filter((v) => LEGACY_IDS.includes((v as { id: string }).id));
    old.tables.exercises = old.tables.exercises.filter((e) => ['ex-021', 'ex-003', 'ex-035'].includes((e as { id: string }).id));
    delete (old.tables as Record<string, unknown>).domainTrials; // il formato 3 non aveva le prove dei domini
    const { domainTrials: _d, ...oldCounts } = old.counts; void _d;
    old.counts = { ...oldCounts, exerciseVersions: 4, exercises: 3 };
    const rep = await validateBackup(JSON.stringify(await resign(old)));
    expect(rep.errors).toEqual([]);
    const dst = new FitDb(`f2old-${Date.now()}`); await dst.open();
    await importBackup(dst, rep, { confirmReplace: false });
    expect(await dst.exerciseVersions.count()).toBe(KNOWLEDGE_VERSIONS.length);
    expect(await dst.exercises.count()).toBe(53);
  });
  it('classificazione alterata nel file: backup rifiutato', async () => {
    const db = await freshDb();
    const b = JSON.parse(JSON.stringify(await exportBackup(db, 't'))) as BackupFile;
    (b.tables.exerciseVersions.find((v) => (v as { id: string }).id === 'ex-001-v1') as { meta: { setup: string } }).meta.setup = 'TRAMPOLINO';
    const rep = await validateBackup(JSON.stringify(await resign(b)));
    expect(rep.ok).toBe(false);
  });
});
