// Test della versione 0.4.1: recupero (D101), calibrazione (D102), segnalazioni ed esclusioni (D103), ricerca, giornale diagnostico.
import { describe, expect, it } from 'vitest';
import { exportBackup, importBackup, validateBackup, contentHash } from '../src/data/backup';
import { journalCheck } from '../src/data/diagnostics';
import { addStarterKit, listEquipment } from '../src/data/equipmentRepo';
import { isCalibrating, snapshotOf, startFreeSession } from '../src/data/freeSessionRepo';
import { deleteTestData, markSessionAsTest } from '../src/data/historyRepo';
import { journalAppend } from '../src/data/journal';
import { CATALOG } from '../src/data/libraryCatalog';
import { excludedExercises, libraryItems, problemReportText, reportProblem, setExcluded, setTested, withdrawProblem } from '../src/data/libraryRepo';
import { closeSession, recordSet } from '../src/data/repository';
import { FitDb } from '../src/data/schema';
import { calibrationHint } from '../src/domain/calibration';
import { uuidv7 } from '../src/domain/ids';
import { restKind, suggestRest } from '../src/domain/rest';
import { matches, searchText } from '../src/domain/search';
import { freshDb } from './helpers';

const meta = (id: string) => CATALOG.find((c) => c.id === id)!.meta;
const status = async (db: FitDb, id: string) => (await libraryItems(db)).find((i) => i.entry.id === id)!;
const set = (sessionId: string, prescriptionId: string, over: Record<string, unknown> = {}) => ({
  id: uuidv7(), sessionId, prescriptionId, setIndex: 1, side: 'BILATERAL' as const, status: 'PERFORMED' as const, reps: 10, durationS: null,
  rir: 2, rpe: null, techniqueQuality: null, discomfort: false, ...over,
});

describe('F2B-REST recupero suggerito (D101)', () => {
  it('per tipo di esercizio, serie dura, tra i lati', () => {
    expect(suggestRest(meta('ex-001'), { side: 'BILATERAL', rir: 2 }, 'BILATERAL').seconds).toBe(90);  // principale
    expect(suggestRest(meta('ex-001'), { side: 'BILATERAL', rir: 1 }, 'BILATERAL').seconds).toBe(120); // serie molto dura
    expect(suggestRest(meta('ex-001'), { side: 'BILATERAL', rir: null }, 'BILATERAL').seconds).toBe(90); // RIR mancante ≠ 0
    expect(suggestRest(meta('ex-029'), { side: 'BILATERAL', rir: 2 }, 'BILATERAL').seconds).toBe(60);  // curl: complementare
    expect(suggestRest(meta('ex-035'), { side: 'BILATERAL', rir: null }, 'BILATERAL').seconds).toBe(45); // plank: core
    expect(suggestRest(meta('ex-039'), { side: 'LEFT', rir: null }, 'LEFT').seconds).toBe(30);         // mobilità, serie nuova
    expect(suggestRest(meta('ex-003'), { side: 'LEFT', rir: 0 }, 'RIGHT').seconds).toBe(15);           // tra i lati
    expect(suggestRest(meta('ex-033'), { side: 'BILATERAL', rir: 0 }, 'BILATERAL').seconds).toBe(45);  // RIR ignorato se non richiesto
    for (const c of CATALOG) expect(['MAIN', 'COMPLEMENTARY', 'CORE', 'MOBILITY', 'CONDITIONING']).toContain(restKind(c.meta));
  });
  it('dato del recupero salvato con la serie, validato e conservato nel backup', async () => {
    const db = await freshDb();
    const s = await startFreeSession(db, { exerciseId: 'ex-001', config: null });
    const [p] = await db.prescriptions.where('sessionId').equals(s.id).toArray();
    await recordSet(db, set(s.id, p!.id));
    const rest = { suggestedS: 90, addedS: 30, elapsedS: 118, skipped: false };
    const r = await recordSet(db, set(s.id, p!.id, { setIndex: 2, rest }));
    expect(r.set.rest).toEqual(rest);
    await expect(recordSet(db, set(s.id, p!.id, { setIndex: 3, rest: { ...rest, elapsedS: -5 } }))).rejects.toMatchObject({ code: 'INVALID_REST' });
    await closeSession(db, s.id, 'FINISHED_BY_USER');
    const b = await exportBackup(db, 't');
    const dst = new FitDb(`f2b-${Date.now()}`); await dst.open();
    await importBackup(dst, await validateBackup(JSON.stringify(b)), { confirmReplace: false });
    expect(await contentHash(dst)).toBe(await contentHash(db));
    expect((await dst.sets.get(r.set.id))!.rest).toEqual(rest);
  });
});

describe('F2B-CAL calibrazione della prima seduta (D102)', () => {
  const door = meta('ex-018'); const free = meta('ex-019');
  const t = { repMin: 8, repMax: 15 };
  it('suggerimenti: porta (distanza), elastico libero (elastico), nessun suggerimento quando non serve', () => {
    expect(calibrationHint(door, t, { reps: 17, rir: 3, status: 'PERFORMED', discomfort: false })!.text).toMatch(/allontanati/);
    expect(calibrationHint(door, t, { reps: 12, rir: 5, status: 'PERFORMED', discomfort: false })!.direction).toBe('HARDER');
    expect(calibrationHint(door, t, { reps: 6, rir: 1, status: 'PERFORMED', discomfort: false })!.text).toMatch(/avvicinati/);
    expect(calibrationHint(door, t, { reps: 12, rir: 0, status: 'PERFORMED', discomfort: false })!.direction).toBe('EASIER');
    expect(calibrationHint(door, t, { reps: 12, rir: 2, status: 'PERFORMED', discomfort: false })!.direction).toBe('KEEP');
    expect(calibrationHint(door, t, { reps: 12, rir: null, status: 'PERFORMED', discomfort: false })!.direction).toBe('KEEP'); // RIR mancante: nessuna deduzione
    expect(calibrationHint(free, t, { reps: 20, rir: 3, status: 'PERFORMED', discomfort: false })!.text).toMatch(/elastico più duro/);
    expect(calibrationHint(door, t, { reps: 12, rir: 2, status: 'INTERRUPTED', discomfort: false })).toBeNull();
    expect(calibrationHint(door, t, { reps: 20, rir: 5, status: 'PERFORMED', discomfort: true })).toBeNull(); // con fastidio non si suggerisce di aumentare
    expect(calibrationHint(meta('ex-001'), t, { reps: 20, rir: 5, status: 'PERFORMED', discomfort: false })).toBeNull(); // corpo libero
  });
  it('vale solo la prima volta con l\'esercizio', async () => {
    const db = await freshDb();
    await addStarterKit(db);
    const tube = (await listEquipment(db)).find((i) => i.type === 'RESISTANCE_BAND')!;
    const cfg = snapshotOf([tube.id], null, null);
    const s1 = await startFreeSession(db, { exerciseId: 'ex-019', config: cfg }, true);
    expect(await isCalibrating(db, 'ex-019', s1.id)).toBe(true);
    const [p] = await db.prescriptions.where('sessionId').equals(s1.id).toArray();
    await recordSet(db, set(s1.id, p!.id, { configurationSnapshot: cfg }));
    expect(await isCalibrating(db, 'ex-019', s1.id)).toBe(true); // stessa seduta: si continua a calibrare
    await closeSession(db, s1.id, 'FINISHED_BY_USER');
    const s2 = await startFreeSession(db, { exerciseId: 'ex-019', config: cfg }, true);
    expect(await isCalibrating(db, 'ex-019', s2.id)).toBe(false);
  });
});

describe('F2B-FB segnalazioni ed esclusioni (D103)', () => {
  it('problema → «Da rivedere»; ritiro → bozza; testo per Claude', async () => {
    const db = await freshDb();
    await setTested(db, 'ex-003', true);
    await reportProblem(db, 'ex-003', 'UNCLEAR', '  non capisco dove va il piede dietro  ');
    const it3 = await status(db, 'ex-003');
    expect(it3.status).toBe('NEEDS_REVIEW');
    expect(it3.problem).toMatchObject({ reason: 'UNCLEAR', note: 'non capisco dove va il piede dietro', versionId: 'ex-003-v2' });
    const text = (await problemReportText(db, '0.4.1'))!;
    expect(text).toContain('ex-003 Split squat'); expect(text).toContain('non capisco dove va il piede dietro');
    await withdrawProblem(db, 'ex-003');
    expect((await status(db, 'ex-003')).status).toBe('DRAFT');
    expect(await problemReportText(db, '0.4.1')).toBeNull();
    await expect(reportProblem(db, 'ex-012', 'OTHER', null)).rejects.toMatchObject({ code: 'CONTENT_NOT_READY' });
  });
  it('«Non propormelo» e ritorno; anche per schede in arrivo', async () => {
    const db = await freshDb();
    await setExcluded(db, 'ex-017', true);
    await setExcluded(db, 'ex-012', true);
    expect([...(await excludedExercises(db))].sort()).toEqual(['ex-012', 'ex-017']);
    await setExcluded(db, 'ex-017', false);
    expect((await status(db, 'ex-017')).excluded).toBe(false);
    expect((await status(db, 'ex-012')).excluded).toBe(true);
    await expect(setExcluded(db, 'ex-999', true)).rejects.toMatchObject({ code: 'UNKNOWN_EXERCISE' });
  });
});

describe('F2B-SEARCH ricerca', () => {
  const find = (q: string) => CATALOG.filter((c) => matches(q, searchText(c))).map((c) => c.id);
  it('nome, muscolo, attrezzo, senza accenti e maiuscole', () => {
    expect(find('femorali')).toEqual(expect.arrayContaining(['ex-008', 'ex-012', 'ex-053']));
    expect(find('STACCO')).toEqual(['ex-008', 'ex-009']);
    expect(find('mobilita')).toEqual(expect.arrayContaining(['ex-039', 'ex-055']));
    expect(find('fitball')).toEqual(['ex-053']);
    expect(find('pallof')).toEqual(['ex-037']);
    expect(find('row')).toEqual(expect.arrayContaining(['ex-021', 'ex-023']));
    expect(find('plank laterale')).toEqual(['ex-036']);
    expect(find('zzz')).toEqual([]);
  });
});

describe('F2B-DIAG giornale diagnostico', () => {
  it('le serie di prova eliminate non risultano «perse»', async () => {
    const store = new Map<string, string>();
    (globalThis as { localStorage?: unknown }).localStorage = { getItem: (k: string) => store.get(k) ?? null, setItem: (k: string, v: string) => store.set(k, v), removeItem: (k: string) => store.delete(k) };
    const db = await freshDb();
    const s = await startFreeSession(db, { exerciseId: 'ex-001', config: null });
    const [p] = await db.prescriptions.where('sessionId').equals(s.id).toArray();
    const r = await recordSet(db, set(s.id, p!.id));
    journalAppend(r.set.id);
    await closeSession(db, s.id, 'FINISHED_BY_USER');
    await markSessionAsTest(db, s.id);
    await deleteTestData(db);
    expect(await journalCheck(db)).toEqual({ confirmed: 0, found: 0, lost: [] });
    delete (globalThis as { localStorage?: unknown }).localStorage;
  });
});
