// Test della versione 0.4.2: modello dei domini (D105), valutazione in 3 fasi (D097 rivista, D108), schema 5, EX056.
import Dexie from 'dexie';
import { describe, expect, it } from 'vitest';
import { assessmentProgress, bandForStep, getProfile, lastReference, recordGate, recordLadderAttempt, recordRatioH, recordThreshold, startLevel } from '../src/data/assessmentRepo';
import { contentHash, exportBackup, importBackup, validateBackup } from '../src/data/backup';
import { addStarterKit, listEquipment, saveOrdering } from '../src/data/equipmentRepo';
import { CATALOG } from '../src/data/libraryCatalog';
import { FitDb, STORES_V1, STORES_V2, STORES_V3, STORES_V4 } from '../src/data/schema';
import { DOMAINS, LADDERS, LEVEL_DOMAINS, PROBES, THRESHOLDS } from '../src/domain/domains';
import { computeProfile, ladderLevel, passesStep } from '../src/domain/domainProfile';
import { uuidv7 } from '../src/domain/ids';
import type { DomainTrial, Side } from '../src/domain/types';
import { freshDb } from './helpers';

const DAY = 86_400_000;
const NOW = Date.parse('2026-12-20T10:00:00.000Z');
const at = (daysAgo: number) => new Date(NOW - daysAgo * DAY).toISOString();
let n = 0;
const L = (ladderId: string, level: number, passed: boolean, daysAgo: number, side: Side | null = null, over: Partial<DomainTrial> = {}): DomainTrial => {
  const l = LADDERS.find((x) => x.id === ladderId)!;
  return { id: `t${++n}`, runId: null, probeId: null, domainId: l.domain, ladderId, kind: 'LADDER', side, level, passed, reps: 10, seconds: null, valueCm: null,
    mobilityClass: null, rir: 2, technique: 'GOOD', discomfort: false, bandIds: [], pressReps: null, source: 'ASSESSMENT', ruleVersion: 'domains-1', performedAt: at(daysAgo), tzOffsetMin: -60, ...over };
};
const T = (domainId: string, cls: DomainTrial['mobilityClass'], daysAgo: number, side: Side | null, valueCm: number | null = null): DomainTrial =>
  ({ ...L('P-OR', 1, true, daysAgo), domainId, ladderId: null, kind: 'THRESHOLD', level: null, passed: null, reps: null, rir: null, technique: null, side, mobilityClass: cls, valueCm });

describe('F2C-MODEL definizioni coerenti con il documento approvato', () => {
  it('19 domini, 12 a livelli, scale di 5 gradini con esercizi del catalogo, 20 prove in 3 fasi', () => {
    expect(DOMAINS).toHaveLength(19);
    expect(LEVEL_DOMAINS).toHaveLength(12);
    expect(DOMAINS.filter((d) => d.perSide)).toHaveLength(9);
    for (const l of LADDERS) {
      expect(l.steps.map((s) => s.level)).toEqual([1, 2, 3, 4, 5]);
      for (const s of l.steps) {
        expect(CATALOG.some((c) => c.id === s.exerciseId), `${l.id} L${s.level}: ${s.exerciseId}`).toBe(true);
        expect((s.reps ?? 0) > 0 || (s.seconds ?? 0) > 0).toBe(true);
      }
    }
    for (const d of LEVEL_DOMAINS) expect(LADDERS.some((l) => l.domain === d), d).toBe(true);
    expect(THRESHOLDS.map((t) => t.domain).sort()).toEqual(['E-EQ', 'M-ANC', 'M-CAV', 'M-POS', 'M-SPA', 'M-TOR']);
    expect(PROBES).toHaveLength(20);
    expect([1, 2, 3].map((f) => PROBES.filter((p) => p.phase === f).length)).toEqual([6, 7, 7]);
    expect(new Set(PROBES.map((p) => p.id)).size).toBe(20);
    const covered = new Set(PROBES.map((p) => (p.kind === 'LADDER' ? LADDERS.find((l) => l.id === p.ref)!.domain : p.kind === 'THRESHOLD' ? p.ref : 'T-OR')));
    expect([...covered].sort()).toEqual(DOMAINS.filter((d) => d.id !== 'F-FIA').map((d) => d.id).sort()); // fiato escluso (D097)
  });
  it('EX056 nel catalogo con scheda completa', () => {
    expect(CATALOG.find((c) => c.id === 'ex-056')!.meta.primary).toEqual(['ERECTORS']);
  });
});

describe('F2C-RULE criterio, livelli, fiducia, discesa', () => {
  const step = LADDERS.find((l) => l.id === 'P-OR')!.steps[3]!; // piegamenti a terra, 10
  const lad = { useRir: true };
  it('criterio comune: ripetizioni, tecnica, fastidio, RIR 0; RIR mancante non è 0', () => {
    expect(passesStep(step, lad, { reps: 10, seconds: null, rir: 1, technique: 'GOOD', discomfort: false })).toBe(true);
    expect(passesStep(step, lad, { reps: 10, seconds: null, rir: null, technique: 'ACCEPTABLE', discomfort: false })).toBe(true);
    expect(passesStep(step, lad, { reps: 9, seconds: null, rir: 3, technique: 'GOOD', discomfort: false })).toBe(false);
    expect(passesStep(step, lad, { reps: 12, seconds: null, rir: 0, technique: 'GOOD', discomfort: false })).toBe(false);
    expect(passesStep(step, lad, { reps: 12, seconds: null, rir: 2, technique: 'POOR', discomfort: false })).toBe(false);
    expect(passesStep(step, lad, { reps: 12, seconds: null, rir: 2, technique: null, discomfort: false })).toBe(false); // tecnica obbligatoria nelle prove
    expect(passesStep(step, lad, { reps: 12, seconds: null, rir: 2, technique: 'GOOD', discomfort: true })).toBe(false);
  });
  it('fiducia: 1 giorno media, 2 giorni alta, prove vecchie bassa; discesa solo con 2 mancati a ≥7 giorni', () => {
    expect(ladderLevel([L('P-OR', 3, true, 3)], NOW)).toEqual({ level: 3, confidence: 'MEDIUM' });
    expect(ladderLevel([L('P-OR', 3, true, 10), L('P-OR', 3, true, 3)], NOW)).toEqual({ level: 3, confidence: 'HIGH' });
    expect(ladderLevel([L('P-OR', 3, true, 3), L('P-OR', 4, false, 3), L('P-OR', 4, false, 1)], NOW)).toEqual({ level: 3, confidence: 'HIGH' }); // mancato il gradino sopra in altro giorno: conferma
    expect(ladderLevel([L('P-OR', 3, true, 60)], NOW)).toEqual({ level: 3, confidence: 'LOW' });
    expect(ladderLevel([L('P-OR', 3, true, 30), L('P-OR', 3, false, 20), L('P-OR', 3, false, 16)], NOW).level).toBe(3); // 4 giorni di distanza: non basta
    expect(ladderLevel([L('P-OR', 3, true, 30), L('P-OR', 3, false, 20), L('P-OR', 3, false, 10)], NOW).level).toBe(2);
    expect(ladderLevel([L('P-OR', 1, false, 2)], NOW)).toEqual({ level: 0, confidence: 'LOW', estimated: true }); // sotto il primo gradino
    expect(ladderLevel([L('P-OR', 2, false, 2)], NOW)).toEqual({ level: 1, confidence: 'LOW', estimated: true }); // livello 1 non provato: solo stima
  });
});

describe('F2C-PROFILE esempio del documento (D105, Regola di decisione)', () => {
  const trials: DomainTrial[] = [];
  for (const d of [10, 3]) {
    trials.push(L('P-OR', 4, true, d), L('T-OR', 3, true, d), L('G-GIN', 4, true, d), L('G-ANC', 2, true, d), L('G-ANC', 3, false, d), L('C-EST', 3, true, d, null, { reps: null, seconds: 30 }));
    for (const s of ['LEFT', 'RIGHT'] as Side[]) trials.push(L('G-UNI', 3, true, d, s));
    trials.push(L('C-LAT', 3, true, d, 'LEFT', { reps: null, seconds: 25 }), L('C-LAT', 3, true, d, 'RIGHT', { reps: null, seconds: 35 }));
    trials.push(L('C-LAT', 4, false, d, 'LEFT', { reps: null, seconds: 25 }), L('C-LAT', 4, true, d, 'RIGHT', { reps: null, seconds: 35 }));
    trials.push(T('M-CAV', 'LIMITATA', d, 'RIGHT', 7), T('M-CAV', 'ADEGUATA', d, 'LEFT', 11));
  }
  trials.push({ ...L('T-OR', 3, true, 3), kind: 'RATIO_H', ladderId: null, level: null, passed: null, reps: 19, pressReps: 20, valueCm: 90 });
  const p = computeProfile(trials, NOW);
  const d = (id: string) => p.domains.find((x) => x.id === id)!;
  it('mediana 3, priorità anca, caviglia, core laterale con le motivazioni', () => {
    expect(p.median).toBe(3);
    expect(d('G-ANC')).toMatchObject({ level: 2, score: 2, state: 'PRIORITY' });
    expect(d('M-CAV')).toMatchObject({ cls: 'LIMITATA', score: 2, state: 'PRIORITY' });
    expect(d('C-LAT')).toMatchObject({ level: 3, score: 1, state: 'PRIORITY' });
    expect(d('C-LAT').sides).toMatchObject({ LEFT: { level: 3 }, RIGHT: { level: 4 } });
    expect(d('C-LAT').reasons.join(' ')).toMatch(/sinistra più debole del 29%/);
    expect(d('G-ANC').reasons.join(' ')).toMatch(/Livello 2 contro mediana 3/);
    expect(p.priorities).toEqual(['G-ANC', 'M-CAV', 'C-LAT']);
    expect(d('P-OR').state).toBe('AHEAD');
    expect(d('G-GIN').state).toBe('AHEAD');
    expect(d('T-VE').state).toBe('UNKNOWN');
    const h = p.ratios.find((r) => r.id === 'H')!;
    expect(h).toMatchObject({ value: 0.95, outOfBand: false });
    expect(p.ratios.find((r) => r.id === 'PA')).toMatchObject({ value: -2, outOfBand: true, lagging: 'G-ANC' });
  });
  it('con una sola prova i ritardi sono solo «possibili» e non entrano in priorità', () => {
    const one = computeProfile(trials.filter((t) => t.performedAt === at(3)), NOW);
    expect(one.priorities).toEqual([]);
    expect(one.domains.find((x) => x.id === 'G-ANC')!.state).toBe('POSSIBLE');
    expect(one.domains.find((x) => x.id === 'M-CAV')!.state).toBe('POSSIBLE');
  });
  it('mobilità carente: priorità anche con una sola prova? no: serve fiducia alta per entrare, ma il punteggio è +2', () => {
    const c = computeProfile([T('M-SPA', 'CARENTE', 2, null)], NOW);
    expect(c.domains.find((x) => x.id === 'M-SPA')).toMatchObject({ score: 2, state: 'POSSIBLE' });
  });
});

describe('F2C-REPO valutazione nell\'archivio', () => {
  async function kit() {
    const db = await freshDb();
    await addStarterKit(db);
    const all = await listEquipment(db);
    await saveOrdering(db, 'RESISTANCE_BAND', all.filter((i) => i.type === 'RESISTANCE_BAND').map((t) => t.id));
    await saveOrdering(db, 'LOOP_BAND', all.filter((i) => i.type === 'LOOP_BAND').map((t) => t.id));
    return { db, all };
  }
  it('controllo minimo: un «sì» ferma le prove di oggi e resta registrato', async () => {
    const db = await freshDb();
    expect((await recordGate(db, [false, false, false])).allowed).toBe(true);
    expect((await recordGate(db, [false, true, false])).allowed).toBe(false);
    expect(await db.decisionLog.filter((l) => l.decision === 'ASSESSMENT_GATE_STOPPED').count()).toBe(1);
    await expect(recordGate(db, [false])).rejects.toMatchObject({ code: 'INVALID_GATE' });
  });
  it('tentativi: esito calcolato con il criterio; lati, elastici, distanza di riferimento; gradino di partenza', async () => {
    const { db, all } = await kit();
    const e1 = all.find((i) => i.physicalLabel === 'E1')!;
    expect((await bandForStep(db, LADDERS.find((l) => l.id === 'T-OR')!.steps[0]!))!.id).toBe(e1.id);
    expect((await bandForStep(db, LADDERS.find((l) => l.id === 'G-LAT-ABD')!.steps[1]!))!.type).toBe('LOOP_BAND');
    expect(await startLevel(db, 'T-OR', 'BILATERAL')).toBe(2);
    const a = { runId: null, probeId: 'w2-tor', ladderId: 'T-OR', side: 'BILATERAL' as Side, seconds: null, technique: 'GOOD' as const, discomfort: false };
    await expect(recordLadderAttempt(db, { ...a, level: 2, reps: 12, rir: 2, bandIds: [e1.id], referenceCm: null })).rejects.toMatchObject({ code: 'INVALID_DISTANCE' });
    const t1 = await recordLadderAttempt(db, { ...a, level: 2, reps: 12, rir: 2, bandIds: [e1.id], referenceCm: 95 });
    const t2 = await recordLadderAttempt(db, { ...a, level: 3, reps: 8, rir: 0, bandIds: [e1.id], referenceCm: 95 });
    expect([t1.passed, t2.passed]).toEqual([true, false]);
    expect(await lastReference(db, 'T-OR')).toBe(95);
    expect(await startLevel(db, 'T-OR', 'BILATERAL')).toBe(1);
    await expect(recordLadderAttempt(db, { ...a, ladderId: 'G-UNI', level: 2, reps: 8, rir: 2, bandIds: [], referenceCm: null })).rejects.toMatchObject({ code: 'INVALID_SIDE' });
    const p = await getProfile(db);
    expect(p.domains.find((x) => x.id === 'T-OR')).toMatchObject({ level: 2, confidence: 'MEDIUM' });
  });
  it('soglie: classe calcolata dal numero o scelta; avanzamento del piano per lato', async () => {
    const db = await freshDb();
    expect((await recordThreshold(db, { runId: null, probeId: 'w1-cav', domainId: 'M-CAV', side: 'LEFT', value: 9, choice: null, discomfort: false })).mobilityClass).toBe('LIMITATA');
    let prog = await assessmentProgress(db);
    expect(prog.find((x) => x.probe.id === 'w1-cav')!.done).toBe(false); // manca il lato destro
    await recordThreshold(db, { runId: null, probeId: 'w1-cav', domainId: 'M-CAV', side: 'RIGHT', value: 12, choice: null, discomfort: false });
    await recordThreshold(db, { runId: null, probeId: 'w1-spa', domainId: 'M-SPA', side: 'BILATERAL', value: null, choice: 'ADEGUATA', discomfort: false });
    prog = await assessmentProgress(db);
    expect(prog.filter((x) => x.done).map((x) => x.probe.id).sort()).toEqual(['w1-cav', 'w1-spa']);
    await expect(recordThreshold(db, { runId: null, probeId: null, domainId: 'E-EQ', side: 'LEFT', value: 45, choice: null, discomfort: false })).rejects.toMatchObject({ code: 'INVALID_VALUE' });
    await expect(recordThreshold(db, { runId: null, probeId: null, domainId: 'M-SPA', side: 'BILATERAL', value: null, choice: null, discomfort: false })).rejects.toMatchObject({ code: 'INVALID_VALUE' });
  });
  it('rapporto orizzontale e backup formato 6 identico', async () => {
    const { db, all } = await kit();
    await recordRatioH(db, { runId: null, probeId: 'w2-rat', rowReps: 14, pressReps: 12, bandIds: [all.find((i) => i.physicalLabel === 'E2')!.id], distanceCm: 90, discomfort: false });
    expect((await getProfile(db)).ratios.find((r) => r.id === 'H')!.value).toBe(1.17);
    const b = await exportBackup(db, 't');
    expect(b.counts.domainTrials).toBe(1);
    const dst = new FitDb(`f2c-${Date.now()}`); await dst.open();
    await importBackup(dst, await validateBackup(JSON.stringify(b)), { confirmReplace: false });
    expect(await contentHash(dst)).toBe(await contentHash(db));
  });
});

describe('F2C-MIG migrazione 4 → 5', () => {
  it('un archivio della 0.4.1 con seduta aperta si apre nella 0.4.2 senza perdere nulla', async () => {
    const name = `mig5-${Date.now()}`;
    const old = new Dexie(name);
    old.version(1).stores(STORES_V1); old.version(2).stores(STORES_V2); old.version(3).stores(STORES_V3); old.version(4).stores(STORES_V4);
    await old.open();
    await old.table('sessions').add({ id: 's1', sessionType: 'FREE', status: 'IN_PROGRESS', startedAt: at(0), tzOffsetMin: -60, endedAt: null, updatedAt: at(0), closeReason: null });
    await old.table('sets').add({ id: 'x1', sessionId: 's1', prescriptionId: 'p1', exerciseId: 'ex-001', setIndex: 1, side: 'BILATERAL', status: 'PERFORMED', reps: 10, durationS: null, rir: 2, rpe: null, techniqueQuality: null, discomfort: false, configurationSnapshot: null, plausibility: 'OK', performedAt: at(0), tzOffsetMin: -60 });
    old.close();
    const db = new FitDb(name); await db.open();
    expect(db.verno).toBe(5);
    expect(await db.sessions.get('s1')).toMatchObject({ status: 'IN_PROGRESS' });
    expect(await db.sets.count()).toBe(1);
    expect(await db.domainTrials.count()).toBe(0);
    expect(await db.decisionLog.filter((l) => l.decision === 'SCHEMA_MIGRATED_TO_5').count()).toBe(1);
  });
});

describe('F2C-IDS identificativi crescenti (DEF-13)', () => {
  it('UUIDv7 in ordine anche nello stesso millisecondo', () => {
    const ids = Array.from({ length: 5000 }, () => uuidv7(NOW));
    expect([...ids].sort()).toEqual(ids);
    expect(new Set(ids).size).toBe(5000);
  });
});

describe('F2C-FACT lunghezza dei tubi dichiarata (115 cm)', () => {
  it('compila solo i tubi senza lunghezza, una volta sola; il kit nuovo la contiene già', async () => {
    const { fillDeclaredTubeLength } = await import('../src/data/repository');
    const db = await freshDb();
    await addStarterKit(db);
    const tubes = (await listEquipment(db)).filter((i) => i.type === 'RESISTANCE_BAND');
    expect(tubes.every((t) => t.restLengthCm === 115)).toBe(true);           // installazione nuova
    await db.equipmentItems.update(tubes[0]!.id, { restLengthCm: null });   // come un kit creato con la 0.3/0.4.1
    await db.equipmentItems.update(tubes[1]!.id, { restLengthCm: 118 });    // valore inserito dall'utente: non si tocca
    expect(await fillDeclaredTubeLength(db)).toBe(1);
    expect(await fillDeclaredTubeLength(db)).toBe(0);
    const after = new Map((await listEquipment(db)).map((i) => [i.id, i.restLengthCm]));
    expect([after.get(tubes[0]!.id), after.get(tubes[1]!.id)]).toEqual([115, 118]);
    const loops = (await listEquipment(db)).filter((i) => i.type === 'LOOP_BAND');
    expect(loops.every((l) => l.restLengthCm === 60)).toBe(true);
  });
});
