// Test della versione 0.4.3: seconda ondata di schede (D095, OI031), eliminazione delle prove di prova (D110), intervallo reale del recupero.
import { describe, expect, it } from 'vitest';
import { deleteAssessmentTrials, getProfile, recordThreshold } from '../src/data/assessmentRepo';
import { BACKUP_FORMAT_VERSION, contentHash, exportBackup, importBackup, validateBackup } from '../src/data/backup';
import { startFreeSession } from '../src/data/freeSessionRepo';
import { currentVersion, KNOWLEDGE_VERSIONS } from '../src/data/knowledge';
import { CATALOG } from '../src/data/libraryCatalog';
import { SOURCES, WAVE1, WAVE_042, WAVE_043 } from '../src/data/libraryContent';
import { closeSession, recordSet } from '../src/data/repository';
import { FitDb } from '../src/data/schema';
import { LADDERS, THRESHOLDS } from '../src/domain/domains';
import { uuidv7 } from '../src/domain/ids';
import { freshDb } from './helpers';

const ALL = { ...WAVE1, ...WAVE_042, ...WAVE_043 };

describe('F2D-CARDS tutte le schede rispettano le stesse regole', () => {
  it('36 schede complete, nomi coerenti, 2–3 indicazioni, respirazione senza assoluti, fonti esistenti, ancoraggio coerente', () => {
    expect(Object.keys(ALL)).toHaveLength(36);
    for (const [id, { content: c, breathing }] of Object.entries(ALL)) {
      const e = CATALOG.find((x) => x.id === id)!;
      expect(e, id).toBeDefined();
      expect(c.displayName, id).toBe(e.displayName);
      expect(c.cues.length, id).toBeGreaterThanOrEqual(2); expect(c.cues.length, id).toBeLessThanOrEqual(3);
      expect(c.setup.length, id).toBeGreaterThanOrEqual(1);
      expect(c.commonErrors.length, id).toBeGreaterThanOrEqual(2);
      expect((c.stopIf ?? []).length, id).toBeGreaterThanOrEqual(1);
      expect(c.purpose, id).toBeTruthy();
      expect(breathing.toLowerCase(), id).not.toMatch(/non trattenere|\bmai\b|valsalva/);
      for (const s of c.sources ?? []) expect(SOURCES[s], `${id}: ${s}`).toBeDefined();
      if (e.meta.setup === 'TUBE_DOOR') expect(c.defaultAnchor, id).toBe(e.meta.anchor);
      expect(currentVersion(id)!.content, id).toEqual(c);
    }
  });
  it('ogni esercizio usato nella valutazione ha la scheda (OI031)', () => {
    const ids = new Set([...LADDERS.flatMap((l) => l.steps.map((s) => s.exerciseId)), ...THRESHOLDS.map((t) => t.exerciseId)]);
    expect([...ids].filter((i) => !currentVersion(i)?.content)).toEqual([]);
  });
  it('le versioni precedenti restano tutte, immutate nel numero; ogni scheda nuova è una versione nuova', () => {
    expect(KNOWLEDGE_VERSIONS.find((v) => v.id === 'ex-002-v1')!.content).toBeNull(); // la versione 0.4.0 resta com'era
    expect(currentVersion('ex-002')!.id).toBe('ex-002-v2');
    expect(new Set(KNOWLEDGE_VERSIONS.map((v) => v.id)).size).toBe(KNOWLEDGE_VERSIONS.length);
  });
});

describe('F2D-DEL eliminazione delle prove di valutazione di prova (D110)', () => {
  it('elimina tutte le prove, svuota il profilo, lascia le sedute e registra la decisione', async () => {
    const db = await freshDb();
    await recordThreshold(db, { runId: null, probeId: 'w1-spa', domainId: 'M-SPA', side: 'BILATERAL', value: null, choice: 'LIMITATA', discomfort: false });
    const s = await startFreeSession(db, { exerciseId: 'ex-001', config: null });
    expect(await deleteAssessmentTrials(db)).toBe(1);
    expect(await db.domainTrials.count()).toBe(0);
    expect((await getProfile(db)).domains.every((d) => d.state === 'UNKNOWN')).toBe(true);
    expect(await db.sessions.get(s.id)).toBeDefined();
    expect(await db.decisionLog.filter((l) => l.decision === 'ASSESSMENT_TRIALS_DELETED').count()).toBe(1);
  });
});

describe('F2D-REST intervallo reale del recupero', () => {
  it('salvato con la serie, conservato nel backup formato 7; i dati senza intervallo restano validi', async () => {
    const db = await freshDb();
    const s = await startFreeSession(db, { exerciseId: 'ex-001', config: null });
    const [p] = await db.prescriptions.where('sessionId').equals(s.id).toArray();
    const base = { sessionId: s.id, prescriptionId: p!.id, side: 'BILATERAL' as const, status: 'PERFORMED' as const, reps: 10, durationS: null, rir: 2, rpe: null, techniqueQuality: null, discomfort: false };
    await recordSet(db, { ...base, id: uuidv7(), setIndex: 1 });
    const r2 = await recordSet(db, { ...base, id: uuidv7(), setIndex: 2, rest: { suggestedS: 90, addedS: 0, elapsedS: 90, skipped: false, intervalS: 185 } });
    const r3 = await recordSet(db, { ...base, id: uuidv7(), setIndex: 3, rest: { suggestedS: 90, addedS: 30, elapsedS: 120, skipped: false } });
    expect(r2.set.rest!.intervalS).toBe(185); // 95 s oltre la fine del timer (esecuzione della serie compresa)
    expect(r3.set.rest!.intervalS).toBeUndefined();
    await closeSession(db, s.id, 'FINISHED_BY_USER');
    const b = await exportBackup(db, 't');
    expect(b.formatVersion).toBe(BACKUP_FORMAT_VERSION);
    const dst = new FitDb(`f2d-${Date.now()}`); await dst.open();
    await importBackup(dst, await validateBackup(JSON.stringify(b)), { confirmReplace: false });
    expect(await contentHash(dst)).toBe(await contentHash(db));
  });
});

describe('F2D-REST2 recupero reale misurato o stimato (D111)', async () => {
  const { restRecord, estimateSetSeconds } = await import('../src/domain/restRecord');
  it('con il tocco: 30 s impostati, tocco a 50 s → 50 registrati', () => {
    const t0 = Date.parse('2026-11-25T10:00:00Z');
    const r = restRecord({ startedAt: t0, suggestedS: 30, addedS: 0, setStartedAt: t0 + 50_000 }, t0 + 95_000, { reps: 12, durationS: null });
    expect(r).toEqual({ suggestedS: 30, addedS: 0, elapsedS: 50, skipped: false, intervalS: 95, measured: 'TAP' });
  });
  it('tocco prima della fine: serie iniziata in anticipo', () => {
    const t0 = 0;
    expect(restRecord({ startedAt: t0, suggestedS: 90, addedS: 30, setStartedAt: 60_000 }, 100_000, { reps: 10, durationS: null })).toMatchObject({ elapsedS: 60, skipped: true, measured: 'TAP' });
  });
  it('senza tocco: stimato togliendo la durata della serie', () => {
    expect(estimateSetSeconds({ reps: 10, durationS: null })).toBe(35);
    expect(estimateSetSeconds({ reps: null, durationS: 40 })).toBe(45);
    expect(restRecord({ startedAt: 0, suggestedS: 90, addedS: 0, setStartedAt: null }, 150_000, { reps: 10, durationS: null })).toEqual({ suggestedS: 90, addedS: 0, elapsedS: 115, skipped: false, intervalS: 150, measured: 'ESTIMATED' });
    expect(restRecord({ startedAt: 0, suggestedS: 90, addedS: 0, setStartedAt: null }, 10_000, { reps: 10, durationS: null }).elapsedS).toBe(0); // mai negativo
  });
});
