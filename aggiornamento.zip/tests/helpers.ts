import { FitDb } from '../src/data/schema';
import { seedKnowledge, startPocSession } from '../src/data/repository';
import { uuidv7 } from '../src/domain/ids';
import type { RecordSetInput } from '../src/data/repository';

let n = 0;
export async function freshDb(): Promise<FitDb> {
  const db = new FitDb(`test-${Date.now()}-${n++}`);
  await db.open();
  await seedKnowledge(db);
  return db;
}
export async function dbWithSession() {
  const db = await freshDb();
  const session = await startPocSession(db);
  const prescriptions = await db.prescriptions.where('sessionId').equals(session.id).sortBy('order');
  return { db, session, prescriptions };
}
export function setInput(sessionId: string, prescriptionId: string, over: Partial<RecordSetInput> = {}): RecordSetInput {
  return { id: uuidv7(), sessionId, prescriptionId, setIndex: 1, side: 'BILATERAL', status: 'PERFORMED', reps: 10, durationS: null, rir: 2, rpe: null, techniqueQuality: 'GOOD', discomfort: null, ...over };
}
