import { describe, expect, it } from 'vitest';
import { FitDb, FitDbV1, CURRENT_SCHEMA_VERSION } from '../src/data/schema';
import { getOpenSessions, recordSet, resumePoint, getSessionDetail, SEED } from '../src/data/repository';
import { uuidv7 } from '../src/domain/ids';

describe('POC-06 migrazione v1→v2 con seduta IN_PROGRESS', () => {
  it('preserva dati, effettua backfill, la seduta resta riprendibile e accetta nuove serie', async () => {
    const name = `mig-${Date.now()}`;
    const v1 = new FitDbV1(name); await v1.open();
    const t = new Date().toISOString();
    await v1.table('exercises').add({ id: SEED.bandRow.exerciseId, canonicalName: 'Band Row', createdAt: t });
    await v1.table('exerciseVersions').add({ id: SEED.bandRow.versionId, exerciseId: SEED.bandRow.exerciseId, version: 1, unilateral: false, measure: 'REPS', breathing: 'x', createdAt: t });
    await v1.table('sessions').add({ id: 's1', sessionType: 'POC', status: 'IN_PROGRESS', startedAt: t, tzOffsetMin: -60, endedAt: null, updatedAt: t, closeReason: null });
    await v1.table('prescriptions').add({ id: 'p1', sessionId: 's1', exerciseId: SEED.bandRow.exerciseId, exerciseVersionId: SEED.bandRow.versionId, order: 1, origin: 'ENGINE', prescribedSets: 3, repMin: 8, repMax: 15, targetDurationS: null, targetRir: 2, sidesPerSet: ['BILATERAL'], configurationSnapshot: null, createdAt: t });
    await v1.table('sets').add({ id: 'set1', sessionId: 's1', prescriptionId: 'p1', setIndex: 1, side: 'BILATERAL', status: 'PERFORMED', reps: 11, durationS: null, rir: null, rpe: null, techniqueQuality: 'GOOD', discomfort: null, configurationSnapshot: null, plausibility: 'OK', performedAt: t, tzOffsetMin: -60 });
    v1.close();

    const db = new FitDb(name); await db.open();
    expect(db.verno).toBe(CURRENT_SCHEMA_VERSION);
    const set = (await db.sets.get('set1'))!;
    expect(set.exerciseId).toBe(SEED.bandRow.exerciseId);
    expect(set.reps).toBe(11); expect(set.rir).toBeNull();
    expect(await getOpenSessions(db)).toHaveLength(1);
    expect(resumePoint((await getSessionDetail(db, 's1'))!)).toEqual({ prescriptionId: 'p1', setIndex: 2, side: 'BILATERAL' });
    await recordSet(db, { id: uuidv7(), sessionId: 's1', prescriptionId: 'p1', setIndex: 2, side: 'BILATERAL', status: 'PERFORMED', reps: 10, durationS: null, rir: 2, rpe: null, techniqueQuality: null, discomfort: null });
    expect(await db.sets.where('[exerciseId+performedAt]').between([SEED.bandRow.exerciseId, ''], [SEED.bandRow.exerciseId, '\uffff']).count()).toBe(2);
  });
});
