import 'fake-indexeddb/auto';
import { describe, expect, it } from 'vitest';
import { backDepth, popBack, pushBack } from '../src/app/back';
import { addStarterKit, listEquipment } from '../src/data/equipmentRepo';
import { markSessionsAsTest } from '../src/data/historyRepo';
import { closeSession } from '../src/data/repository';
import { snapshotOf, startBandRowSession } from '../src/data/sliceRepo';
import { freshDb } from './helpers';

describe('Tasto indietro (pila delle viste)', () => {
  it('chiama il gestore più recente; senza gestori restituisce false', () => {
    const calls: string[] = [];
    expect(popBack()).toBe(false);
    const offA = pushBack(() => calls.push('lista'));
    const offB = pushBack(() => calls.push('dettaglio'));
    expect(popBack()).toBe(true);
    expect(calls).toEqual(['dettaglio']);
    offB(); // la vista si chiude e toglie il suo gestore
    popBack();
    expect(calls).toEqual(['dettaglio', 'lista']);
    offA();
    expect(backDepth()).toBe(0);
  });
  it('un gestore che non chiude la vista resta attivo (scelta obbligatoria)', () => {
    let n = 0;
    const off = pushBack(() => { n++; });
    popBack(); popBack();
    expect(n).toBe(2); expect(backDepth()).toBe(1);
    off();
  });
});

describe('D085 selezione multipla', () => {
  it('tutto o niente: con un ID non valido nessuna seduta cambia', async () => {
    const db = await freshDb();
    await addStarterKit(db);
    const t = (await listEquipment(db)).find((i) => i.type === 'RESISTANCE_BAND')!;
    const ids: string[] = [];
    for (let i = 0; i < 2; i++) { const s = await startBandRowSession(db, snapshotOf([t.id], 'DOOR_MID', 80), true); await closeSession(db, s.id, 'FINISHED_BY_USER'); ids.push(s.id); }
    await expect(markSessionsAsTest(db, [...ids, 'inesistente'])).rejects.toMatchObject({ code: 'NOT_FOUND' });
    expect((await db.sessions.toArray()).every((s) => s.sessionType === 'FREE')).toBe(true);
    await markSessionsAsTest(db, ids);
    expect((await db.sessions.toArray()).every((s) => s.sessionType === 'POC')).toBe(true);
  });
});
