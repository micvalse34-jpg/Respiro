import { describe, expect, it } from 'vitest';
import { FitDb } from '../src/data/schema';
import { exerciseHistory, generateHistory, percentile } from '../src/data/synthetic';
import { SEED } from '../src/data/repository';
import { contentHash } from '../src/data/backup';

// Indicativo: fake-indexeddb in Node NON rappresenta le prestazioni di Chrome su Android.
// Il valore vincolante è la misura su Pixel 7a (POC-14, protocollo dispositivo).
describe('POC-14 (indicativo, Node) storico sintetico', () => {
  it.each([[5, 2.5, 650], [5, 7.5, 1950]])('%i anni, %f sedute/settimana', async (years, perWeek, expectedSessions) => {
    const db = new FitDb(`perf-${Date.now()}-${perWeek}`); await db.open();
    const t0 = performance.now();
    const gen = await generateHistory(db, years, perWeek);
    const genMs = performance.now() - t0;
    const q: number[] = [];
    for (let i = 0; i < 10; i++) { const t = performance.now(); const h = await exerciseHistory(db, SEED.bandRow.exerciseId, 200); q.push(performance.now() - t); expect(h).toHaveLength(200); }
    const t1 = performance.now(); await contentHash(db); const exportMs = performance.now() - t1;
    const result = { ...gen, generateMs: Math.round(genMs), historyQueryP95Ms: +percentile(q, 95).toFixed(1), exportHashMs: Math.round(exportMs) };
    console.log('PERF_RESULT', JSON.stringify(result));
    expect(gen.sessions).toBe(expectedSessions);
    expect(gen.sets).toBe(expectedSessions * 12); // 3 + 3×2 lati + 3 serie a seduta
  });
});
