import { describe, expect, it } from 'vitest';
import { addUserPrescription, closeSession, getOpenSessions, getSessionDetail, recordSet, resumePoint, SEED } from '../src/data/repository';
import { dbWithSession, setInput } from './helpers';

describe('POC-01 CRUD e relazioni', () => {
  it('crea seduta IN_PROGRESS con prescrizioni ordinate e snapshot di configurazione', async () => {
    const { db, session, prescriptions } = await dbWithSession();
    expect(session.status).toBe('IN_PROGRESS');
    expect(prescriptions.map((p) => p.order)).toEqual([1, 2, 3]);
    // Dalla F1 nessun elastico segnaposto: senza elastici indicati lo snapshot è assente (null), non inventato.
    expect(prescriptions[0]!.configurationSnapshot).toBeNull();
    expect(await getOpenSessions(db)).toHaveLength(1);
  });

  it('registra serie bilaterale, unilaterale per lato e a durata', async () => {
    const { db, session, prescriptions: [row, split, plank] } = await dbWithSession();
    await recordSet(db, setInput(session.id, row!.id));
    await recordSet(db, setInput(session.id, split!.id, { side: 'LEFT', reps: 8 }));
    await recordSet(db, setInput(session.id, split!.id, { side: 'RIGHT', reps: 7 }));
    await recordSet(db, setInput(session.id, plank!.id, { reps: null, durationS: 32, rir: null, rpe: 7 }));
    const d = (await getSessionDetail(db, session.id))!;
    expect(d.sets).toHaveLength(4);
    expect(d.sets.filter((s) => s.prescriptionId === split!.id).map((s) => s.side).sort()).toEqual(['LEFT', 'RIGHT']);
    const p = d.sets.find((s) => s.prescriptionId === plank!.id)!;
    expect(p.durationS).toBe(32); expect(p.reps).toBeNull(); expect(p.rpe).toBe(7);
    expect(d.sets.every((s) => s.exerciseId)).toBe(true);
  });

  it('RIR mancante resta null, distinto da 0', async () => {
    const { db, session, prescriptions: [row] } = await dbWithSession();
    const a = await recordSet(db, setInput(session.id, row!.id, { rir: null }));
    const b = await recordSet(db, setInput(session.id, row!.id, { setIndex: 2, rir: 0 }));
    expect((await db.sets.get(a.set.id))!.rir).toBeNull();
    expect((await db.sets.get(b.set.id))!.rir).toBe(0);
  });

  it('rifiuta serie su prescrizione di un\'altra seduta o seduta chiusa', async () => {
    const { db, session, prescriptions: [row] } = await dbWithSession();
    const other = await dbWithSession();
    await expect(recordSet(db, setInput(session.id, other.prescriptions[0]!.id))).rejects.toMatchObject({ code: 'PRESCRIPTION_MISMATCH' });
    await closeSession(db, session.id, 'FINISHED_BY_USER');
    await expect(recordSet(db, setInput(session.id, row!.id))).rejects.toMatchObject({ code: 'SESSION_NOT_OPEN' });
  });

  it('esercizio fuori programma: prescrizione USER_ADDED, serie collegata', async () => {
    const { db, session } = await dbWithSession();
    const p = await addUserPrescription(db, session.id, SEED.plank.versionId);
    expect(p.origin).toBe('USER_ADDED'); expect(p.prescribedSets).toBe(0);
    await recordSet(db, setInput(session.id, p.id, { reps: null, durationS: 20 }));
    expect(await db.sets.where('prescriptionId').equals(p.id).count()).toBe(1);
  });
});

describe('Idempotenza e plausibilità', () => {
  it('un nuovo tentativo con lo stesso ID non crea duplicati', async () => {
    const { db, session, prescriptions: [row] } = await dbWithSession();
    const input = setInput(session.id, row!.id);
    expect((await recordSet(db, input)).outcome).toBe('saved');
    expect((await recordSet(db, input)).outcome).toBe('already_saved');
    expect(await db.sets.count()).toBe(1);
  });

  it('ADV06: 120 ripetizioni richiedono conferma esplicita e restano marcate', async () => {
    const { db, session, prescriptions: [row] } = await dbWithSession();
    await expect(recordSet(db, setInput(session.id, row!.id, { reps: 120 }))).rejects.toMatchObject({ code: 'IMPLAUSIBLE_VALUE' });
    expect(await db.sets.count()).toBe(0);
    const r = await recordSet(db, setInput(session.id, row!.id, { reps: 120, confirmedImplausible: true }));
    expect(r.set.plausibility).toBe('CONFIRMED_BY_USER');
  });
});

describe('Ripresa e chiusura (D6: nessuna chiusura automatica)', () => {
  it('punto di ripresa: prima serie/lato non registrati', async () => {
    const { db, session, prescriptions: [row, split] } = await dbWithSession();
    for (let i = 1; i <= 3; i++) await recordSet(db, setInput(session.id, row!.id, { setIndex: i }));
    await recordSet(db, setInput(session.id, split!.id, { side: 'LEFT' }));
    const rp = resumePoint((await getSessionDetail(db, session.id))!);
    expect(rp).toEqual({ prescriptionId: split!.id, setIndex: 1, side: 'RIGHT' });
  });

  it('chiusura alla riapertura: osservazioni intatte, NOT_PERFORMED aggiunti, PARTIALLY_COMPLETED', async () => {
    const { db, session, prescriptions: [row] } = await dbWithSession();
    const a = await recordSet(db, setInput(session.id, row!.id));
    const before = await db.sets.get(a.set.id);
    const status = await closeSession(db, session.id, 'CLOSED_ON_REOPEN');
    expect(status).toBe('PARTIALLY_COMPLETED');
    expect(await db.sets.get(a.set.id)).toEqual(before);
    const d = (await getSessionDetail(db, session.id))!;
    // 3+4+2 serie/lati prescritti = 9; 1 eseguita → 8 NOT_PERFORMED
    expect(d.sets.filter((s) => s.status === 'NOT_PERFORMED')).toHaveLength(8);
    expect(d.session.closeReason).toBe('CLOSED_ON_REOPEN');
  });

  it('nessuna serie eseguita → CANCELLED; tutte eseguite → COMPLETED', async () => {
    const x = await dbWithSession();
    expect(await closeSession(x.db, x.session.id, 'FINISHED_BY_USER')).toBe('CANCELLED');
    const y = await dbWithSession();
    const [row, split, plank] = y.prescriptions;
    for (let i = 1; i <= 3; i++) await recordSet(y.db, setInput(y.session.id, row!.id, { setIndex: i }));
    for (let i = 1; i <= 2; i++) for (const side of ['LEFT', 'RIGHT'] as const) await recordSet(y.db, setInput(y.session.id, split!.id, { setIndex: i, side }));
    for (let i = 1; i <= 2; i++) await recordSet(y.db, setInput(y.session.id, plank!.id, { setIndex: i, reps: null, durationS: 30 }));
    expect(await closeSession(y.db, y.session.id, 'FINISHED_BY_USER')).toBe('COMPLETED');
  });

  it('una serie INTERRUPTED è conservata e non diventa COMPLETED', async () => {
    const { db, session, prescriptions: [row] } = await dbWithSession();
    await recordSet(db, setInput(session.id, row!.id, { status: 'INTERRUPTED', reps: 4 }));
    expect(await closeSession(db, session.id, 'FINISHED_BY_USER')).toBe('PARTIALLY_COMPLETED');
    expect(await db.sets.filter((s) => s.status === 'INTERRUPTED').count()).toBe(1);
  });
});
