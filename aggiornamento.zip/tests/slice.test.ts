import 'fake-indexeddb/auto';
import { describe, expect, it } from 'vitest';
import { BACKUP_FORMAT_VERSION, contentHash, exportBackup, importBackup, validateBackup } from '../src/data/backup';
import { addStarterKit, listEquipment, saveOrdering, updateEquipment } from '../src/data/equipmentRepo';
import { closeSession, recordSet } from '../src/data/repository';
import { CURRENT_SCHEMA_VERSION, FitDb, FitDbV3 } from '../src/data/schema';
import {
  BAND_ROW_ID, bandRowExposures, decideProposal, evaluateBandRowSession, pendingProposal, setupDefaults, snapshotOf, startBandRowSession,
} from '../src/data/sliceRepo';
import { compare, exposureConfig } from '../src/domain/comparability';
import { evaluate, unmetConditions, type Exposure, type ProgressionContext } from '../src/domain/progression';
import { uuidv7 } from '../src/domain/ids';
import { freshDb } from './helpers';

const cfg = (bands: string[], anchor: string | null = 'DOOR_MID', d: number | null = 100) => snapshotOf(bands, anchor, d);

describe('D079 comparabilità A/B/C/D', () => {
  it('regole di classe', () => {
    expect(compare(cfg(['a']), cfg(['a'], 'DOOR_MID', 110))).toBe('A');
    expect(compare(cfg(['a']), cfg(['a'], 'DOOR_MID', 111))).toBe('B');
    expect(compare(cfg(['a']), cfg(['a'], 'DOOR_LOW'))).toBe('B');
    expect(compare(cfg(['a', 'b']), cfg(['b', 'a']))).toBe('A');
    expect(compare(cfg(['a']), cfg(['b']))).toBe('C');
    expect(compare(cfg(['a'], 'DOOR_MID', null), cfg(['a']))).toBe('D');
    expect(compare(null, cfg(['a']))).toBe('D');
  });
  it('configurazione cambiata durante la seduta → nessuna configurazione unica', () => {
    expect(exposureConfig([cfg(['a']), cfg(['a'])])).not.toBeNull();
    expect(exposureConfig([cfg(['a']), cfg(['a'], 'DOOR_MID', 105)])).toBeNull();
  });
});

import type { ExposureSet } from '../src/domain/progression';
const good: ExposureSet = { status: 'PERFORMED', reps: 15, rir: 2, techniqueQuality: 'GOOD', discomfort: false };
const exp = (id: string, c = cfg(['E2']), sets: ExposureSet[] = [good, good, good]): Exposure => ({ sessionId: id, endedAt: id, config: c, prescribedSets: 3, repMax: 15, targetRir: 2, sets });
const ctx = (exposures: Exposure[], over: Partial<ProgressionContext> = {}): ProgressionContext => ({
  exposures, orderedTubes: ['E1', 'E2', 'E3', 'E4', 'E5'].map((id) => ({ id, label: id })), rejections: [],
  startDistanceCm: () => 80, labelOf: (id) => id, ...over,
});

describe('D080 regola di proposta (funzione pura)', () => {
  it('una sola seduta all\'obiettivo: mantieni, serve conferma', () => {
    expect(evaluate(ctx([exp('2')]))!.kind).toBe('MAINTAIN');
  });
  it('due sedute consecutive in classe A all\'obiettivo → proposta distanza +10 cm', () => {
    const r = evaluate(ctx([exp('2'), exp('1')]))!;
    expect(r.kind).toBe('INCREASE_DISTANCE'); expect(r.proposedConfig!.distanceCm).toBe(110);
  });
  it('seduta precedente in classe B (distanza +20 cm) → nessuna proposta', () => {
    expect(evaluate(ctx([exp('2'), exp('1', cfg(['E2'], 'DOOR_MID', 120))]))!.kind).toBe('MAINTAIN');
  });
  it('RIR mancante non conta come obiettivo raggiunto (NULL ≠ 0, nessun valore inventato)', () => {
    const e = exp('2', cfg(['E2']), [good, good, { ...good, rir: null }]);
    expect(unmetConditions(e)).toContain('serie 3: RIR non indicato');
    expect(evaluate(ctx([e, exp('1')]))!.kind).toBe('MAINTAIN');
  });
  it('14 ripetizioni, RIR 1, tecnica scarsa o serie interrotta bloccano la proposta', () => {
    for (const bad of [{ reps: 14 }, { rir: 1 }, { techniqueQuality: 'POOR' as const }, { status: 'INTERRUPTED' as const }]) {
      expect(evaluate(ctx([exp('2', cfg(['E2']), [good, good, { ...good, ...bad }]), exp('1')]))!.kind).toBe('MAINTAIN');
    }
  });
  it('D082 fastidio nella seduta → nessuna proposta di aumento', () => {
    expect(evaluate(ctx([exp('2', cfg(['E2']), [good, good, { ...good, discomfort: true }]), exp('1')]))!.kind).toBe('BLOCKED_DISCOMFORT');
  });
  it('D081 senza spazio: elastico successivo alla distanza di partenza; salto rifiutato: nessuna combinazione sotto E5', () => {
    const noSpace = [{ kind: 'INCREASE_DISTANCE' as const, fromConfig: cfg(['E2']), proposedConfig: cfg(['E2'], 'DOOR_MID', 110), reason: 'NO_SPACE' as const }];
    const r = evaluate(ctx([exp('2'), exp('1')], { rejections: noSpace }))!;
    expect(r.kind).toBe('NEXT_BAND'); expect(r.proposedConfig).toMatchObject({ bandIds: ['E3'], distanceCm: 80 });
    const jump = [...noSpace, { kind: 'NEXT_BAND' as const, fromConfig: cfg(['E2']), proposedConfig: cfg(['E3'], 'DOOR_MID', 80), reason: 'JUMP_TOO_BIG' as const }];
    expect(evaluate(ctx([exp('2'), exp('1')], { rejections: jump }))!.kind).toBe('NONE_AVAILABLE');
  });
  it('oltre E5 senza spazio: combinazione con il tubo più morbido', () => {
    const noSpace = [{ kind: 'INCREASE_DISTANCE' as const, fromConfig: cfg(['E5']), proposedConfig: cfg(['E5'], 'DOOR_MID', 110), reason: 'NO_SPACE' as const }];
    const r = evaluate(ctx([exp('2', cfg(['E5'])), exp('1', cfg(['E5']))], { rejections: noSpace }))!;
    expect(r.kind).toBe('ADD_BAND'); expect(r.proposedConfig!.bandIds).toEqual(['E5', 'E1']);
  });
  it('ordine dei tubi mancante: nessuna proposta di cambio elastico', () => {
    const noSpace = [{ kind: 'INCREASE_DISTANCE' as const, fromConfig: cfg(['E2']), proposedConfig: cfg(['E2'], 'DOOR_MID', 110), reason: 'NO_SPACE' as const }];
    expect(evaluate(ctx([exp('2'), exp('1')], { rejections: noSpace, orderedTubes: null }))!.kind).toBe('NONE_AVAILABLE');
  });
});

async function kitDb() {
  const db = await freshDb();
  await addStarterKit(db);
  const tubes = (await listEquipment(db)).filter((i) => i.type === 'RESISTANCE_BAND');
  await saveOrdering(db, 'RESISTANCE_BAND', tubes.map((t) => t.id));
  return { db, tubes };
}
async function doSession(db: FitDb, c: ReturnType<typeof cfg>, reps = [15, 15, 15], extra: Record<string, unknown> = {}) {
  const s = await startBandRowSession(db, c, true);
  const [p] = await db.prescriptions.where('sessionId').equals(s.id).toArray();
  for (let i = 0; i < reps.length; i++) {
    await recordSet(db, { id: uuidv7(), sessionId: s.id, prescriptionId: p!.id, setIndex: i + 1, side: 'BILATERAL', status: 'PERFORMED', reps: reps[i]!, durationS: null, rir: 2, rpe: null, techniqueQuality: 'GOOD', discomfort: false, ...extra });
  }
  await closeSession(db, s.id, 'FINISHED_BY_USER');
  return { session: s, result: await evaluateBandRowSession(db, s.id) };
}

describe('Slice Band Row nel database', () => {
  it('flusso completo: due sedute → proposta → rifiuto per spazio → elastico successivo → accettazione → nuova configurazione proposta all\'avvio', async () => {
    const { db, tubes } = await kitDb();
    const c = cfg([tubes[1]!.id], 'DOOR_MID', 80);
    expect((await doSession(db, c, [12, 13, 15])).result.event!.kind).toBe('MAINTAIN');
    expect((await doSession(db, c)).result.event!.kind).toBe('MAINTAIN'); // prima seduta all'obiettivo
    const third = await doSession(db, cfg([tubes[1]!.id], 'DOOR_MID', 85));
    expect(third.result.event).toMatchObject({ kind: 'INCREASE_DISTANCE', status: 'PROPOSED' });
    expect((await pendingProposal(db))!.id).toBe(third.result.event!.id);
    const alt = (await decideProposal(db, third.result.event!.id, false, 'NO_SPACE'))!;
    expect(alt).toMatchObject({ kind: 'NEXT_BAND', previousEventId: third.result.event!.id });
    expect(alt.proposedConfig).toMatchObject({ bandIds: [tubes[2]!.id], distanceCm: 80 });
    expect(await decideProposal(db, alt.id, true)).toBeNull();
    expect((await setupDefaults(db))).toMatchObject({ source: 'ACCEPTED_PROPOSAL', config: { bandIds: [tubes[2]!.id], distanceCm: 80 } });
    await expect(decideProposal(db, alt.id, false, 'OTHER')).rejects.toMatchObject({ code: 'ALREADY_DECIDED' });
    expect(await evaluateBandRowSession(db, third.session.id)).toMatchObject({ event: { id: alt.id } }); // idempotente
  });
  it('configurazione cambiata a metà seduta → classe D, nessuna proposta', async () => {
    const { db, tubes } = await kitDb();
    const c = cfg([tubes[0]!.id]);
    await doSession(db, c);
    const s = await startBandRowSession(db, c, true);
    const [p] = await db.prescriptions.where('sessionId').equals(s.id).toArray();
    for (let i = 1; i <= 3; i++) await recordSet(db, { id: uuidv7(), sessionId: s.id, prescriptionId: p!.id, setIndex: i, side: 'BILATERAL', status: 'PERFORMED', reps: 15, durationS: null, rir: 3, rpe: null, techniqueQuality: 'GOOD', discomfort: false, configurationSnapshot: i === 3 ? cfg([tubes[0]!.id], 'DOOR_MID', 130) : undefined });
    await closeSession(db, s.id, 'FINISHED_BY_USER');
    expect((await bandRowExposures(db))[0]!.config).toBeNull();
    expect((await evaluateBandRowSession(db, s.id)).event!.kind).toBe('MAINTAIN');
  });
  it('fastidio in 2 delle ultime 3 sedute → segnalazione', async () => {
    const { db, tubes } = await kitDb();
    const c = cfg([tubes[0]!.id]);
    await doSession(db, c, [10, 10, 10], { discomfort: true });
    const r = await doSession(db, c, [10, 10, 10], { discomfort: true });
    expect(r.result).toMatchObject({ repeatedDiscomfort: true, event: { kind: 'BLOCKED_DISCOMFORT' } });
  });
  it('elastico danneggiato o configurazione incompleta: seduta rifiutata', async () => {
    const { db, tubes } = await kitDb();
    await updateEquipment(db, tubes[0]!.id, { integrity: 'DAMAGED' });
    await expect(startBandRowSession(db, cfg([tubes[0]!.id]))).rejects.toMatchObject({ code: 'DAMAGED_BAND' });
    await expect(startBandRowSession(db, cfg([tubes[1]!.id], 'DOOR_MID', null))).rejects.toMatchObject({ code: 'INCOMPLETE_CONFIG' });
    expect(await db.sessions.count()).toBe(0);
  });
  it('contenuto dell\'esercizio: versione 2 in bozza, la versione 1 resta invariata', async () => {
    const db = await freshDb();
    const v2 = (await db.exerciseVersions.get('ex-021-v2'))!;
    expect(v2.content!.status).toBe('DRAFT'); expect(v2.content!.cues).toHaveLength(3);
    expect((await db.exerciseVersions.get('ex-021-v1'))!.content).toBeUndefined();
  });
});

describe('DM07 migrazione v3→v4 e backup formato 3', () => {
  it('migrazione con seduta aperta: nulla toccato, nuova tabella pronta, nuova versione esercizio aggiunta all\'avvio', async () => {
    const name = `mig4-${Date.now()}`;
    const v3 = new FitDbV3(name); await v3.open();
    const t = new Date().toISOString();
    await v3.table('sessions').add({ id: 's', sessionType: 'POC', status: 'IN_PROGRESS', startedAt: t, tzOffsetMin: -60, endedAt: null, updatedAt: t, closeReason: null });
    v3.close();
    const db = new FitDb(name); await db.open();
    expect(db.verno).toBe(CURRENT_SCHEMA_VERSION);
    expect((await db.sessions.get('s'))!.status).toBe('IN_PROGRESS');
    expect(await db.progressionEvents.count()).toBe(0);
  });
  it('export → import identico con proposte; i backup di formato 2 restano importabili', async () => {
    const { db, tubes } = await kitDb();
    const c = cfg([tubes[0]!.id]);
    await doSession(db, c); await doSession(db, c);
    const b = await exportBackup(db, 't');
    expect(b.formatVersion).toBe(BACKUP_FORMAT_VERSION); expect(b.counts.progressionEvents).toBe(2);
    const dst = new FitDb(`d-${Date.now()}`); await dst.open();
    await importBackup(dst, await validateBackup(JSON.stringify(b)), { confirmReplace: false });
    expect(await contentHash(dst)).toBe(await contentHash(db));
  });
  it('un backup di formato 2 (F1, schema 3) si importa: proposte vuote', async () => {
    const { db } = await kitDb();
    const b = await exportBackup(db, 't');
    const { progressionEvents: _omit, domainTrials: _omit2, ...f2tables } = b.tables; void _omit; void _omit2; // il formato 2 non aveva queste tabelle
    const { canonicalStringify, sha256Hex } = await import('../src/data/canonical');
    const counts = Object.fromEntries(Object.entries(b.counts).filter(([k]) => k !== 'progressionEvents' && k !== 'domainTrials'));
    const f2 = { ...b, formatVersion: 2, schemaVersion: 3, tables: f2tables, counts, checksum: await sha256Hex(canonicalStringify(f2tables)) };
    const rep = await validateBackup(JSON.stringify(f2));
    expect(rep.errors).toEqual([]);
    const dst = new FitDb(`d2-${Date.now()}`); await dst.open();
    await importBackup(dst, rep, { confirmReplace: false });
    expect(await dst.progressionEvents.count()).toBe(0);
    expect(await dst.equipmentItems.count()).toBe(22);
    expect((await validateBackup(JSON.stringify({ ...f2, schemaVersion: 4 }))).ok).toBe(false); // formato 2 con schema 4: incoerente
  });
  it('esercizio Band Row presente nella libreria', () => { expect(BAND_ROW_ID).toBe('ex-021'); });
});

describe('D086 controllo di sicurezza settimanale e D085 sedute segnate come prova', () => {
  it('richiesto alla prima seduta, non nei 7 giorni successivi con lo stesso elastico, di nuovo con un elastico nuovo o dopo 7 giorni', async () => {
    const { safetyCheckRequired } = await import('../src/data/sliceRepo');
    const { db, tubes } = await kitDb();
    const c = cfg([tubes[0]!.id]);
    expect(await safetyCheckRequired(db, c.bandIds)).toBe(true);
    await expect(startBandRowSession(db, c)).rejects.toMatchObject({ code: 'SAFETY_CHECK_REQUIRED' });
    await doSession(db, c);
    expect(await safetyCheckRequired(db, c.bandIds)).toBe(false);
    const s = await startBandRowSession(db, c); // senza spunta: consentito
    await closeSession(db, s.id, 'FINISHED_BY_USER');
    expect(await safetyCheckRequired(db, [tubes[1]!.id])).toBe(true);
    expect(await safetyCheckRequired(db, c.bandIds, Date.now() + 8 * 86_400_000)).toBe(true);
  });
  it('una seduta segnata come prova esce dalla progressione ed è eliminabile; le sue proposte non restano in attesa', async () => {
    const { markSessionAsTest, deleteTestData, countSessions } = await import('../src/data/historyRepo');
    const { db, tubes } = await kitDb();
    const c = cfg([tubes[0]!.id]);
    const a = await doSession(db, c);
    const b = await doSession(db, c);
    expect(b.result.event!.status).toBe('PROPOSED');
    await markSessionAsTest(db, b.session.id);
    expect(await pendingProposal(db)).toBeNull();
    expect((await bandRowExposures(db)).map((e) => e.sessionId)).toEqual([a.session.id]);
    expect(await db.sets.where('sessionId').equals(b.session.id).count()).toBe(3); // osservazioni invariate
    const r = await deleteTestData(db);
    expect(r.sessions).toBe(1);
    expect(await countSessions(db)).toEqual({ real: 1, test: 0 });
    expect(await db.progressionEvents.where('sessionId').equals(b.session.id).count()).toBe(0);
    await expect(markSessionAsTest(db, 'nessuna')).rejects.toMatchObject({ code: 'NOT_FOUND' });
  });
});
