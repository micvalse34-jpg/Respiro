// Controllo dei file caricati su GitHub (eseguito dalla costruzione automatica prima dei test).
// Confronta ogni file del programma con l'impronta registrata in tests/files-manifest.json: se un file manca,
// è vecchio o è finito nella cartella sbagliata, la costruzione si ferma e indica quale file correggere.
// Uso: node tests/verify-files.mjs            → verifica
//      node tests/verify-files.mjs --write    → rigenera l'elenco (lo usa Claude prima di ogni consegna)
//      node tests/verify-files.mjs --clean    → cancella i file fuori posto nella cartella principale (dopo aggiornamento.zip)
import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { join, relative, sep } from 'node:path';

const ROOT = process.cwd();
const MANIFEST = 'tests/files-manifest.json';
// La documentazione (docs/, README.md) non influisce sull'app: non viene verificata.
const SKIP_DIRS = new Set(['node_modules', 'dist', 'dev-dist', '.git', 'out']);
// File che la costruzione Android rigenera da sola: non vanno confrontati.
const SKIP_FILES = new Set([MANIFEST, 'android/capacitor.settings.gradle', 'android/app/capacitor.build.gradle']);
const ROOT_ALLOWED = new Set(['.github', 'android', 'docs', 'public', 'src', 'tests', 'README.md', 'capacitor.config.ts',
  'index.html', 'package-lock.json', 'package.json', 'tsconfig.json', 'vite.config.ts', '.gitignore']);

const norm = (p) => p.split(sep).join('/');
function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) { if (!SKIP_DIRS.has(name)) walk(full, out); }
    else out.push(norm(relative(ROOT, full)));
  }
  return out;
}
const hash = (f) => createHash('sha256').update(readFileSync(join(ROOT, f))).digest('hex');
// I file in .github non si possono aggiornare con aggiornamento.zip (si cambiano a mano) e li controlla GitHub stesso.
const tracked = (f) => !SKIP_FILES.has(f) && !f.startsWith('docs/') && !f.startsWith('.github/') && f !== 'README.md' && !f.startsWith('android/app/src/main/assets/') && !f.startsWith('android/capacitor-cordova-android-plugins/')
  && f !== 'android/app/src/main/res/xml/config.xml' && !f.startsWith('android/app/build/') && !f.startsWith('android/build/') && !f.startsWith('android/.gradle/');

if (process.argv.includes('--write')) {
  const files = Object.fromEntries(walk(ROOT).filter(tracked).sort().map((f) => [f, hash(f)]));
  writeFileSync(join(ROOT, MANIFEST), JSON.stringify({ version: JSON.parse(readFileSync('package.json', 'utf8')).version, files }, null, 1) + '\n');
  console.log(`Elenco aggiornato: ${Object.keys(files).length} file.`);
  process.exit(0);
}

const m = JSON.parse(readFileSync(join(ROOT, MANIFEST), 'utf8'));
const present = new Set(walk(ROOT));
const missing = [], stale = [];
for (const [f, h] of Object.entries(m.files)) {
  if (!present.has(f)) missing.push(f);
  else if (hash(f) !== h) stale.push(f);
}
const strays = readdirSync(ROOT).filter((n) => !ROOT_ALLOWED.has(n) && !SKIP_DIRS.has(n));
if (process.argv.includes('--clean')) {
  for (const n of strays) rmSync(join(ROOT, n), { recursive: true, force: true });
  console.log(strays.length ? `Cancellati ${strays.length} file fuori posto: ${strays.join(', ')}` : 'Nessun file fuori posto.');
  process.exit(0);
}
if (strays.length) console.log(`Attenzione, file fuori posto nella cartella principale (innocui, eliminabili da GitHub): ${strays.join(', ')}`);
if (missing.length || stale.length) {
  if (missing.length) console.log(`File mancanti (forse caricati nella cartella sbagliata):\n  ${missing.join('\n  ')}`);
  if (stale.length) console.log(`File non aggiornati (va caricata la versione nuova):\n  ${stale.join('\n  ')}`);
  console.log(`\nCARICAMENTO INCOMPLETO per la versione ${m.version}: nessun APK verrà prodotto. Ricarica i file indicati nella loro cartella.`);
  process.exit(1);
}
console.log(`Tutti i ${Object.keys(m.files).length} file della versione ${m.version} sono al loro posto.`);
