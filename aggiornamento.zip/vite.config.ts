import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import pkg from './package.json';

// BUILD_LABEL distingue due deploy successivi nel test di aggiornamento (POC-07).
// TARGET=app: build per l'app Android. Il service worker (aggiornamenti del browser) è disattivato:
// nell'app i file sono locali e gli aggiornamenti arrivano installando un nuovo APK.
const isApp = process.env.TARGET === 'app';
const buildLabel = process.env.BUILD_LABEL ?? process.env.CF_PAGES_COMMIT_SHA?.slice(0, 7) ?? 'local';
const base = isApp ? './' : '/';

export default defineConfig({
  base,
  define: {
    __APP_VERSION__: JSON.stringify(pkg.version),
    __BUILD_LABEL__: JSON.stringify(buildLabel),
    __BUILD_TIME__: JSON.stringify(new Date().toISOString()),
  },
  plugins: [
    react(),
    VitePWA({
      disable: isApp,
      // 'prompt': il nuovo service worker resta in attesa; l'attivazione è proposta solo senza sedute aperte.
      registerType: 'prompt',
      injectRegister: false,
      // Il manifest viene richiesto con credenziali: necessario se l'URL è protetto da Cloudflare Access (da verificare su dispositivo).
      useCredentials: true,
      includeAssets: ['icon.svg'],
      manifest: {
        name: 'FitPRO',
        short_name: 'FitPRO',
        lang: 'it',
        start_url: '.',
        scope: '.',
        display: 'standalone',
        background_color: '#f2f4ef',
        theme_color: '#1f3b2d',
        icons: [
          { src: 'icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,svg,png}'],
        navigateFallback: 'index.html',
        cleanupOutdatedCaches: true,
      },
    }),
  ],
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    setupFiles: ['tests/setup.ts'],
    testTimeout: 60000,
  },
});
